"use strict";

// require("dotenv").config({ path: "../.env" });

const userData = require("../../data/admin-masters/admin");
const sendResponse = require("../../shared/sendResponse");
//const jwt = require("../shared/jwtAuth");

/**
 * @description     Users Crud Contollers
 */

const UsersList = async (req, res) => {
  try {
    const allUserData = await userData.UsersList();
    // console.log(allUserData);
    if (!!allUserData && allUserData.length > 0) {
      sendResponse(res, 200, "Users list found successfully", allUserData);
    } else {
      sendResponse(res, 201, "No Users list Found");
    }
  } catch (error) {
    console.log(error);
  }
};

const UsersWithID = async (req, res) => {
  try {
    const UsersWithID = await userData.UsersWithID(req.body);
    if (!!UsersWithID && UsersWithID.length > 0) {
      sendResponse(res, 200, "User found successfully", UsersWithID);
    } else {
      sendResponse(res, 201, "Failed to find user");
    }
  } catch (error) {
    console.log(error);
  }
};

const toggleUserState = async (req, res) => {
  try {
    const deactivate = await userData.toggleUserState(req.body);
    if (deactivate === 1) {
      sendResponse(res, 200, "Users Deactivated Successfully");
    } else {
      sendResponse(res, 201, "User not found");
    }
  } catch (error) {
    console.log(error);
  }
};

const createUser = async (req, res) => {
  try {
    const checkUserExist = await userData.checkUserExist(req.body);
    if (checkUserExist && checkUserExist.length > 0) {
      sendResponse(res, 201, "User Already Exists, try another username");
    } else {
      const newUser = await userData.createUser(req.body);
      if (newUser === 1) {
        sendResponse(res, 200, "User created Successfully");
      } else {
        sendResponse(res, 201, "Failed To Create User");
      }
    }
  } catch (error) {
    console.log(error);
  }
};

const modifyUser = async (req, res) => {
  try {
    const newUser = await userData.modifyUser(req.body);
    if (newUser === 1) {
      sendResponse(res, 200, "User Modified Successfully");
    } else {
      sendResponse(res, 201, "Failed To Modify User");
    }
  } catch (error) {
    console.log(error);
  }
};

// @Helper Functions
const getUserTypes = async (req, res) => {
  try {
    const userTypes = await userData.getUserTypes();
    if (!!userTypes && userTypes.length > 0) {
      sendResponse(res, 200, "User Types Fetched Successfully", userTypes);
    } else {
      sendResponse(res, 201, "No User Types Fetched");
    }
  } catch (error) {
    console.log(error);
  }
};

const searchUserLike = async (req, res) => {
  try {
    const UsersWithName = await userData.searchUserLike(req.body);
    console.log(UsersWithName);
    if (!!UsersWithName && UsersWithName.length > 0) {
      sendResponse(res, 200, "User found successfully", UsersWithName);
    } else {
      sendResponse(res, 201, "Failed to find user");
    }
  } catch (error) {
    console.log(error);
  }
};

module.exports = {
  UsersList,
  UsersWithID,
  createUser,
  modifyUser,
  toggleUserState,
  getUserTypes,
  searchUserLike,
};
