"use strict";

// require("dotenv").config({ path: "../.env" });

const userData = require("../../data/admin-masters/applications");
const sendResponse = require("../../shared/sendResponse");

const getApplicationList = async (req, res) => {
  try {
    const ApplicationList = await userData.getApplicationList();
    if (!!ApplicationList && ApplicationList.length > 0) {
      sendResponse(
        res,
        200,
        "Application list found successfully",
        ApplicationList
      );
    } else {
      sendResponse(res, 201, "Failed to fetch application list");
    }
  } catch (error) {
    console.log(error);
  }
};

const getApplicationWithID = async (req, res) => {
  try {
    const UsersWithID = await userData.getApplicationWithID(req.params);
    if (!!UsersWithID && UsersWithID.length > 0) {
      sendResponse(res, 200, "Application was found successfully", UsersWithID);
    } else {
      sendResponse(res, 201, "Failed to find application");
    }
  } catch (error) {
    console.log(error);
  }
};

const toggleAppState = async (req, res) => {
  try {
    const deactivate = await userData.toggleApplicationState(req.body);
    if (deactivate === 1) {
      sendResponse(res, 200, "Application state successfully switched");
    } else {
      sendResponse(res, 201, "Failed to switch application state");
    }
  } catch (error) {
    console.log(error);
  }
};

const createNewApplication = async (req, res) => {
  try {
    const checkApplicationExist = await userData.checkApplicationExist(
      req.body
    );
    if (checkApplicationExist && checkApplicationExist.length > 0) {
      sendResponse(
        res,
        201,
        `Application with same code already exists, please use another name`
      );
    } else {
      const newApp = await userData.createNewApplication(req.body);
      // console.log(newApp);
      if (newApp === 1) {
        sendResponse(res, 200, "New application added successfully");
      } else {
        sendResponse(res, 201, "Failed to create new application");
      }
    }
  } catch (error) {
    console.log(error);
  }
};

const modifyApplication = async (req, res) => {
  try {
    const modifyApplication = await userData.modifyApplication(req.body);
    if (modifyApplication === 1) {
      sendResponse(res, 200, "Application modified successfully");
    } else {
      sendResponse(res, 201, "Failed To modify application");
    }
  } catch (error) {
    console.log(error);
  }
};

module.exports = {
  createNewApplication,
  getApplicationList,
  toggleAppState,
  getApplicationWithID,
  modifyApplication,
};
