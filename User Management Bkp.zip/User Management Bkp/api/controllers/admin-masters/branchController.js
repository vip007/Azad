"use strict";

// require("dotenv").config({ path: "../.env" });

const branchData = require("../../data/admin-masters/branch");
const sendResponse = require("../../shared/sendResponse");

const getBranchList = async (req, res) => {
  try {
    const BranchList = await branchData.getBranchList();
    if (!!BranchList && BranchList.length > 0) {
      sendResponse(res, 200, "List of branches found successfully", BranchList);
    } else {
      sendResponse(res, 201, "No Branch list Found");
    }
  } catch (error) {
    console.log(error);
  }
};

const createNewBranch = async (req, res) => {
  try {
    const checkBranchExist = await branchData.checkBranchExist(req.body);
    if (checkBranchExist && checkBranchExist.length > 0) {
      sendResponse(res, 201, "Branch Already Exists, try another Branch Name");
    } else {
      const newApp = await branchData.createNewBranch(req.body);
      // console.log(newApp);
      if (newApp === 1) {
        sendResponse(res, 200, "Branch created Successfully");
      } else {
        sendResponse(res, 201, "Failed To Create Branch");
      }
    }
  } catch (error) {
    console.log(error);
  }
};

const getBranchWithID = async (req, res) => {
  try {
    const branch = await branchData.getBranchWithID(req.params);
    if (!!branch && branch.length > 0) {
      sendResponse(res, 200, "Branch found successfully", branch);
    } else {
      sendResponse(res, 201, "Failed to find Branch");
    }
  } catch (error) {
    console.log(error);
  }
};

const modifyBranch = async (req, res) => {
  try {
    const branch = await branchData.modifyBranch(req.body);
    // console.log(branch);
    if (branch === 1) {
      sendResponse(res, 200, "Branch Modified Successfully");
    } else {
      sendResponse(res, 201, "Failed To Modify Branch");
    }
  } catch (error) {
    console.log(error);
  }
};

module.exports = {
  createNewBranch,
  getBranchList,
  getBranchWithID,
  modifyBranch,
};
