"use strict";

const DepartmentData = require("../../data/admin-masters/department");
const sendResponse = require("../../shared/sendResponse");

const getDepartmentList = async (req, res) => {
  try {
    const DepartmentList = await DepartmentData.getDepartmentList();
    if (!!DepartmentList && DepartmentList.length > 0) {
      sendResponse(
        res,
        200,
        "Department list found successfully",
        DepartmentList
      );
    } else {
      sendResponse(res, 201, "No Department list Found");
    }
  } catch (error) {
    console.log(error);
  }
};

const getDepartmentWithID = async (req, res) => {
  try {
    const Department = await DepartmentData.getDepartmentWithID(req.params);
    if (!!Department && Department.length > 0) {
      sendResponse(res, 200, "Department found successfully", Department);
    } else {
      sendResponse(res, 201, "Failed to find Department");
    }
  } catch (error) {
    console.log(error);
  }
};

const toggleDepartmentState = async (req, res) => {
  try {
    const deactivate = await DepartmentData.toggleDepartmentState(req.body);
    if (deactivate === 1) {
      sendResponse(res, 200, "Department Deactivated Successfully");
    } else {
      sendResponse(res, 201, "Department not found");
    }
  } catch (error) {
    console.log(error);
  }
};

const createNewDepartment = async (req, res) => {
  try {
    const checkDepartmentExist = await DepartmentData.checkDepartmentExist(
      req.body
    );
    if (checkDepartmentExist && checkDepartmentExist.length > 0) {
      sendResponse(
        res,
        201,
        "Department Already Exists, try another Department Name"
      );
    } else {
      const newApp = await DepartmentData.createNewDepartment(req.body);
      if (newApp === 1) {
        sendResponse(res, 200, "Department created Successfully");
      } else {
        sendResponse(res, 201, "Failed To Create Department");
      }
    }
  } catch (error) {
    console.log(error);
  }
};

const modifyDepartment = async (req, res) => {
  try {
    const modifyDepartment = await DepartmentData.modifyDepartment(req.body);
    if (modifyDepartment === 1) {
      sendResponse(res, 200, "Department Modified Successfully");
    } else {
      sendResponse(res, 201, "Failed To Modify Department");
    }
  } catch (error) {
    console.log(error);
  }
};

module.exports = {
  createNewDepartment,
  getDepartmentWithID,
  getDepartmentList,
  toggleDepartmentState,
  modifyDepartment,
};
