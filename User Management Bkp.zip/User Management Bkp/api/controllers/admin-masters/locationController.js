"use strict";

const locationData = require("../../data/admin-masters/location");
const sendResponse = require("../../shared/sendResponse");

const getLocationList = async (req, res) => {
  try {
    const LocationList = await locationData.getLocationList();
    if (!!LocationList && LocationList.length > 0) {
      sendResponse(res, 200, "Location list found successfully", LocationList);
    } else {
      sendResponse(res, 201, "No Location list Found");
    }
  } catch (error) {
    console.log(error);
  }
};

const getLocationWithID = async (req, res) => {
  try {
    const location = await locationData.getLocationWithID(req.params);
    if (!!location && location.length > 0) {
      sendResponse(res, 200, "Location found successfully", location);
    } else {
      sendResponse(res, 201, "Failed to find location");
    }
  } catch (error) {
    console.log(error);
  }
};

const toggleLocationState = async (req, res) => {
  try {
    const deactivate = await locationData.toggleLocationState(req.body);
    if (deactivate === 1) {
      sendResponse(res, 200, "Location Deactivated Successfully");
    } else {
      sendResponse(res, 201, "Location not found");
    }
  } catch (error) {
    console.log(error);
  }
};

const createNewLocation = async (req, res) => {
  try {
    const checkLocationExist = await locationData.checkLocationExist(req.body);
    if (checkLocationExist && checkLocationExist.length > 0) {
      sendResponse(
        res,
        201,
        "Location Already Exists, try another Location Name"
      );
    } else {
      const newApp = await locationData.createNewLocation(req.body);
      if (newApp === 1) {
        sendResponse(res, 200, "Location created Successfully");
      } else {
        sendResponse(res, 201, "Failed To Create Location");
      }
    }
  } catch (error) {
    console.log(error);
  }
};

const modifyLocation = async (req, res) => {
  try {
    const modifyLocation = await locationData.modifyLocation(req.body);
    if (modifyLocation === 1) {
      sendResponse(res, 200, "Location Modified Successfully");
    } else {
      sendResponse(res, 201, "Failed To Modify Location");
    }
  } catch (error) {
    console.log(error);
  }
};

module.exports = {
  createNewLocation,
  getLocationWithID,
  getLocationList,
  toggleLocationState,
  modifyLocation,
};
