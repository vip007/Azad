"use strict";

const menuData = require("../../data/admin-masters/menu");
const sendResponse = require("../../shared/sendResponse");

const getMenuList = async (req, res) => {
  try {
    const MenuList = await menuData.getMenuList();
    if (!!MenuList && MenuList.length > 0) {
      sendResponse(res, 200, "Menu list found successfully", MenuList);
    } else {
      sendResponse(res, 201, "No Menu list Found");
    }
  } catch (error) {
    console.log(error);
  }
};

const getMenuWithID = async (req, res) => {
  try {
    const Menu = await menuData.getMenuWithID(req.params);
    if (!!Menu && Menu.length > 0) {
      sendResponse(res, 200, "Menu found successfully", Menu);
    } else {
      sendResponse(res, 201, "Failed to find Menu");
    }
  } catch (error) {
    console.log(error);
  }
};

const toggleMenuState = async (req, res) => {
  try {
    const deactivate = await menuData.toggleMenuState(req.body);
    if (deactivate === 1) {
      sendResponse(res, 200, "Menu Deactivated Successfully");
    } else {
      sendResponse(res, 201, "Menu not found");
    }
  } catch (error) {
    console.log(error);
  }
};

const createNewMenu = async (req, res) => {
  try {
    const checkMenuExist = await menuData.checkMenuExist(req.body);
    if (checkMenuExist && checkMenuExist.length > 0) {
      sendResponse(res, 201, "Menu Already Exists, try another Menu Name");
    } else {
      const newApp = await menuData.createNewMenu(req.body);
      console.log(newApp);
      if (newApp === 1) {
        sendResponse(res, 200, "Menu created Successfully");
      } else {
        sendResponse(res, 201, "Failed To Create Menu");
      }
    }
  } catch (error) {
    console.log(error);
  }
};

const modifyMenu = async (req, res) => {
  try {
    const modifyMenu = await menuData.modifyMenu(req.body);
    if (modifyMenu === 1) {
      sendResponse(res, 200, "Menu Modified Successfully");
    } else {
      sendResponse(res, 201, "Failed To Modify Menu");
    }
  } catch (error) {
    console.log(error);
  }
};

module.exports = {
  createNewMenu,
  getMenuWithID,
  getMenuList,
  toggleMenuState,
  modifyMenu,
};
