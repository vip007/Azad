"use strict";

// require("dotenv").config({ path: "../.env" });

const userData = require("../../data/admin-masters/menuevent");
const sendResponse = require("../../shared/sendResponse");

const MenuEventList = async (req, res) => {
  try {
    const MenuEvent = await userData.MenuEventList();
    if (!!MenuEvent && MenuEvent.length > 0) {
      sendResponse(res, 200, "Menu Event list found successfully", MenuEvent);
    } else {
      sendResponse(res, 201, "No Menu Event list Found");
    }
  } catch (error) {
    console.log(error);
  }
};

const MenuEventWithID = async (req, res) => {
  try {
    const MenuEventID = await userData.MenuEventWithID(req.body);
    if (!!MenuEventID && MenuEventID.length > 0) {
      sendResponse(
        res,
        200,
        "Menu Event with ID found successfully",
        MenuEventID
      );
    } else {
      sendResponse(
        res,
        201,
        "No menu event assigned to menu master, Assign menu event first"
      );
    }
  } catch (error) {
    console.log(error);
  }
};

const MenuEventRemove = async (req, res) => {
  try {
    const deactivate = await userData.MenuEventRemove(req.body);
    if (deactivate === 1) {
      sendResponse(res, 200, "MenuEvent Deactivated Successfully");
    } else {
      sendResponse(res, 201, "MenuEvent not found");
    }
  } catch (error) {
    console.log(error);
  }
};

const createNewMenuEvent = async (req, res) => {
  try {
    const checkMenuEventExist = await userData.checkMenuEventExist(req.body);
    if (checkMenuEventExist && checkMenuEventExist.length > 0) {
      sendResponse(
        res,
        201,
        "Menu Event Already Exists, try another Menu Event Name"
      );
    } else {
      const newApp = await userData.createNewMenuEvent(req.body);
      if (newApp === 1) {
        sendResponse(res, 200, "Menu Event created Successfully");
      } else {
        sendResponse(res, 201, "Failed To Create Menu Event");
      }
    }
  } catch (error) {
    console.log(error);
  }
};

const modifyMenuEvent = async (req, res) => {
  try {
    const modifyMenuEvent = await userData.modifyMenuEvent(req.body);
    if (modifyMenuEvent === 1) {
      sendResponse(res, 200, "MenuEvent Modified Successfully");
    } else {
      sendResponse(res, 201, "Failed To Modify MenuEvent");
    }
  } catch (error) {
    console.log(error);
  }
};

module.exports = {
  MenuEventList,
  MenuEventRemove,
  createNewMenuEvent,
  modifyMenuEvent,
  MenuEventWithID,
};
