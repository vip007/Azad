"use strict";

// require("dotenv").config({ path: "../.env" });

const userData = require("../../data/admin-masters/product");
const sendResponse = require("../../shared/sendResponse");

const ProductList = async (req, res) => {
  try {
    const Products = await userData.ProductList();
    if (!!Products && Products.length > 0) {
      sendResponse(res, 200, "Product list found successfully", Products);
    } else {
      sendResponse(res, 201, "No Product list Found");
    }
  } catch (error) {
    console.log(error);
  }
};

const ProductWithID = async (req, res) => {
  try {
    const ProductWithID = await userData.ProductWithID(req.params);
    if (!!ProductWithID && ProductWithID.length > 0) {
      sendResponse(res, 200, "Product found successfully", ProductWithID);
    } else {
      sendResponse(res, 201, "Failed to find Product");
    }
  } catch (error) {
    console.log(error);
  }
};

const ProductState = async (req, res) => {
  try {
    const deactivate = await userData.toggleProductState(req.body);
    if (deactivate === 1) {
      sendResponse(res, 200, "Product Deactivated Successfully");
    } else {
      sendResponse(res, 201, "Product not found");
    }
  } catch (error) {
    console.log(error);
  }
};

const createNewProduct = async (req, res) => {
  try {
    const checkProductExist = await userData.checkProductExist(req.body);
    if (checkProductExist && checkProductExist.length > 0) {
      sendResponse(
        res,
        201,
        "Product Already Exists, try another Product Name"
      );
    } else {
      const newApp = await userData.createNewProduct(req.body);
      if (newApp === 1) {
        sendResponse(res, 200, "Product created Successfully");
      } else {
        sendResponse(res, 201, "Failed To Create Product");
      }
    }
  } catch (error) {
    console.log(error);
  }
};

const modifyProduct = async (req, res) => {
  try {
    const modifyProduct = await userData.modifyProduct(req.body);
    if (modifyProduct === 1) {
      sendResponse(res, 200, "Product Modified Successfully");
    } else {
      sendResponse(res, 201, "Failed To Modify Product");
    }
  } catch (error) {
    console.log(error);
  }
};

module.exports = {
  ProductList,
  ProductState,
  createNewProduct,
  modifyProduct,
  ProductWithID,
};
