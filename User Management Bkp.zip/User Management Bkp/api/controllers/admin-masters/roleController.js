"use strict";

// require("dotenv").config({ path: "../.env" });

const roleData = require("../../data/admin-masters/role");
const sendResponse = require("../../shared/sendResponse");

const getRoleList = async (req, res) => {
  try {
    const RoleList = await roleData.getRoleList();
    if (!!RoleList && RoleList.length > 0) {
      sendResponse(res, 200, "Role list found successfully", RoleList);
    } else {
      sendResponse(res, 201, "No Role list Found");
    }
  } catch (error) {
    console.log(error);
  }
};

const toggleRoleState = async (req, res) => {
  try {
    const deactivate = await roleData.toggleRoleState(req.body);
    if (deactivate === 1) {
      sendResponse(res, 200, "Role Deactivated Successfully");
    } else {
      sendResponse(res, 201, "Role not found");
    }
  } catch (error) {
    console.log(error);
  }
};

const getRoleWithID = async (req, res) => {
  try {
    const roleId = await roleData.getRoleWithID(req.params);
    if (!!roleId && roleId.length > 0) {
      sendResponse(res, 200, "Role found successfully", roleId);
    } else {
      sendResponse(res, 201, "Failed to find Role");
    }
  } catch (error) {
    console.log(error);
  }
};

const createNewRole = async (req, res) => {
  try {
    const checkRoleExist = await roleData.checkRoleExist(req.body);
    if (checkRoleExist && checkRoleExist.length > 0) {
      sendResponse(res, 201, "Role Already Exists, try another Role Name");
    } else {
      const newApp = await roleData.createNewRole(req.body);
      if (newApp === 1) {
        sendResponse(res, 200, "Role created Successfully");
      } else {
        sendResponse(res, 201, "Failed To Create Role");
      }
    }
  } catch (error) {
    console.log(error);
  }
};

const modifyRole = async (req, res) => {
  try {
    const modifyRole = await roleData.modifyRole(req.body);
    if (modifyRole === 1) {
      sendResponse(res, 200, "Role Modified Successfully");
    } else {
      sendResponse(res, 201, "Failed To Modify Role");
    }
  } catch (error) {
    console.log(error);
  }
};

module.exports = {
  createNewRole,
  getRoleList,
  getRoleWithID,
  toggleRoleState,
  modifyRole,
};
