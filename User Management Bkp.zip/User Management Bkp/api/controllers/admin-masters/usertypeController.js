"use strict";

// require("dotenv").config({ path: "../.env" });

const userData = require("../../data/admin-masters/usertype");
const sendResponse = require("../../shared/sendResponse");
//const jwt = require("../shared/jwtAuth");

const getUsersTypeList = async (req, res) => {
  try {
    const allUserData = await userData.getUsersTypeList();
    if (!!allUserData && allUserData.length > 0) {
      sendResponse(res, 200, "UsersType list found successfully", allUserData);
    } else {
      sendResponse(res, 201, "No UsersType list Found");
    }
  } catch (error) {
    console.log(error);
  }
};

const getUsersTypeWithID = async (req, res) => {
  try {
    const UsersWithID = await userData.getUsersTypeWithID(req.params);
    if (!!UsersWithID && UsersWithID.length > 0) {
      sendResponse(res, 200, "UsersType found successfully", UsersWithID);
    } else {
      sendResponse(res, 201, "Failed to find UsersType");
    }
  } catch (error) {
    console.log(error);
  }
};

const deactivateUserType = async (req, res) => {
  try {
    const deactivate = await userData.deactivateUserType(req.body);
    if (deactivate === 1) {
      sendResponse(res, 200, "UsersType Deactivated Successfully");
    } else {
      sendResponse(res, 201, "UsersType not found");
    }
  } catch (error) {
    console.log(error);
  }
};

const createUserType = async (req, res) => {
  try {
    const checkUserTypeExists = await userData.CheckIfUserTypeExists(req.body);
    if (checkUserTypeExists && checkUserTypeExists.length > 0) {
      sendResponse(
        res,
        201,
        "UsersType name already exists, please try another name"
      );
    } else {
      const newUser = await userData.createUserType(req.body);
      if (newUser === 1) {
        sendResponse(res, 200, "UsersType created Successfully");
      } else {
        sendResponse(res, 201, "Failed To Create UsersType");
      }
    }
  } catch (error) {
    console.log(error);
  }
};

const modifyUserType = async (req, res) => {
  try {
    const checkUserTypeExists = await userData.CheckIfUserTypeExists(req.body);
    if (checkUserTypeExists && checkUserTypeExists.length > 0) {
      sendResponse(
        res,
        201,
        "Usersytpe with same name already exists, please try another name"
      );
    } else {
      const newUser = await userData.modifyUserType(req.body);
      if (newUser === 1) {
        sendResponse(res, 200, "UsersType Modified Successfully");
      } else {
        sendResponse(res, 201, "Failed To Modify UsersType");
      }
    }
  } catch (error) {
    console.log(error);
  }
};

// @Helper Functions

module.exports = {
  getUsersTypeList,
  getUsersTypeWithID,
  createUserType,
  modifyUserType,
  deactivateUserType,
};
