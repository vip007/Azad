const sendResponse = require("../../shared/sendResponse");
const userData = require("../../data/mappings/branchDepartmentAccess");

const BranchDepartmentList = async (req, res) => {
  try {
    const AllUsersAccessRights = await userData.BranchDepartmentList();
    if (!!AllUsersAccessRights && AllUsersAccessRights.length > 0) {
      sendResponse(
        res,
        200,
        "Branch Department Mappings found successfully",
        AllUsersAccessRights
      );
    } else {
      sendResponse(res, 201, "No Branch Department Mappings Found");
    }
  } catch (error) {
    console.log(error);
  }
};

const grantNewBranchDepartment = async (req, res) => {
  try {
    const CheckIfBranchDepartmentExists =
      await userData.CheckIfBranchDepartmentExists(req.body);
    if (
      !!CheckIfBranchDepartmentExists &&
      CheckIfBranchDepartmentExists.length > 0
    ) {
      sendResponse(res, 201, "This access already exists");
    } else {
      const newUsersAccessRights = await userData.grantNewBranchDepartment(
        req.body
      );
      if (newUsersAccessRights === 1) {
        sendResponse(res, 200, "Successfully Mapped the required parameters");
      } else {
        sendResponse(res, 201, "Failed to Map the required parameters");
      }
    }
  } catch (error) {
    console.log(error);
  }
};

const revokeBranchDepartment = async (req, res) => {
  try {
    const revokeRights = await userData.revokeBranchDepartment(req.body);
    if (revokeRights === 1) {
      sendResponse(res, 200, "Right to the menus are now revoked for the user");
    } else {
      sendResponse(res, 201, "Failed to Grant New User Access Rights");
    }
  } catch (error) {
    console.log(error);
  }
};

module.exports = {
  BranchDepartmentList,
  grantNewBranchDepartment,
  revokeBranchDepartment,
};
