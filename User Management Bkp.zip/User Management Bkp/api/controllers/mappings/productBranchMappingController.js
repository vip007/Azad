const sendResponse = require("../../shared/sendResponse");
const userData = require("../../data/mappings/productBranchMapping");

const productBranchList = async (req, res) => {
  try {
    const productBranchList = await userData.productBranchList();
    if (!!productBranchList && productBranchList.length > 0) {
      sendResponse(
        res,
        200,
        "Product branch mapping list found Successfully",
        productBranchList
      );
    } else {
      sendResponse(res, 201, "Failed to fetch product branch mapping list");
    }
  } catch (error) {
    console.log(error);
  }
};

const revokeproductBranchMap = async (req, res) => {
  try {
    const revokeRights = await userData.revokeproductBranchMap(req.body);
    if (revokeRights === 1) {
      sendResponse(res, 200, "Right to the menus are now revoked for the user");
    } else {
      sendResponse(res, 201, "Failed to Grant New User Access Rights");
    }
  } catch (error) {
    console.log(error);
  }
};

const grantproductBranchMap = async (req, res) => {
  try {
    const CheckIfUsersAccessRightsExists = await userData.checkIfExists(
      req.body
    );
    if (
      !!CheckIfUsersAccessRightsExists &&
      CheckIfUsersAccessRightsExists.length > 0
    ) {
      sendResponse(res, 201, "This access already exists");
    } else {
      const newUsersAccessRights = await userData.grantproductBranchMap(
        req.body
      );
      if (newUsersAccessRights === 1) {
        sendResponse(res, 200, "User now has access to the assigned menus");
      } else {
        sendResponse(res, 201, "Failed to Grant New User Access Rights");
      }
    }
  } catch (error) {
    console.log(error);
  }
};

const getProducts = async (req, res) => {
  try {
    const Products = await userData.getProducts(req.body);
    if (!!Products && Products.length > 0) {
      sendResponse(
        res,
        200,
        "Product branch mapping list found Successfully",
        Products
      );
    } else {
      sendResponse(res, 201, "Failed to fetch product branch mapping list");
    }
  } catch (error) {
    console.log(error);
  }
};

module.exports = {
  productBranchList,
  revokeproductBranchMap,
  grantproductBranchMap,
  getProducts,
};
