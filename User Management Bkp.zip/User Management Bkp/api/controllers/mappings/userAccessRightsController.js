const sendResponse = require("../../shared/sendResponse");
const userData = require("../../data/mappings/userAccessRights");

const UsersAccessRightsList = async (req, res) => {
  try {
    const AllUsersAccessRights = await userData.UsersAccessRightsList();

    if (!!AllUsersAccessRights && AllUsersAccessRights.length > 0) {
      sendResponse(
        res,
        200,
        "Users Access Rights Mappings found successfully",
        AllUsersAccessRights
      );
    } else {
      sendResponse(res, 201, "No Users Access Rights Mappings Found");
    }
  } catch (error) {
    console.log(error);
  }
};

const grantNewUserAccessRight = async (req, res) => {
  try {
    const CheckIfUsersAccessRightsExists =
      await userData.CheckIfUsersAccessRightsExists(req.body);
    if (
      !!CheckIfUsersAccessRightsExists &&
      CheckIfUsersAccessRightsExists.length > 0
    ) {
      sendResponse(res, 201, "This access already exists");
    } else {
      const newUsersAccessRights = await userData.grantNewUserAccessRight(
        req.body
      );
      if (newUsersAccessRights === 1) {
        sendResponse(res, 200, "User now has access to the assigned menus");
      } else {
        sendResponse(res, 201, "Failed to Grant New User Access Rights");
      }
    }
  } catch (error) {
    console.log(error);
  }
};

const revokeUserAccessRight = async (req, res) => {
  try {
    const revokeRights = await userData.revokeUserAccessRight(req.body);
    if (revokeRights === 1) {
      sendResponse(res, 200, "Right to the menus are now revoked for the user");
    } else {
      sendResponse(res, 201, "Failed to Grant New User Access Rights");
    }
  } catch (error) {
    console.log(error);
  }
};

module.exports = {
  UsersAccessRightsList,
  grantNewUserAccessRight,
  revokeUserAccessRight,
};
