const sendResponse = require("../../shared/sendResponse");
const userData = require("../../data/mappings/userBranchDepartment");

const branchDeptUserList = async (req, res) => {
  try {
    const allbranchDeptUser = await userData.branchDeptUserList();
    if (!!allbranchDeptUser && allbranchDeptUser.length > 0) {
      sendResponse(
        res,
        200,
        "Users Access Rights Mappings found successfully",
        allbranchDeptUser
      );
    } else {
      sendResponse(res, 201, "No Users Access Rights Mappings Found");
    }
  } catch (error) {
    console.log(error);
  }
};

const mapNewUserBranchDept = async (req, res) => {
  try {
    const CheckIfUserBranchDeptExists =
      await userData.CheckIfUserBranchDeptExists(req.body);
    if (CheckIfUserBranchDeptExists && CheckIfUserBranchDeptExists.length > 0) {
      sendResponse(res, 201, "This access already exists");
    } else {
      const newUsersAccessRights = await userData.mapNewUserBranchDept(
        req.body
      );
      if (newUsersAccessRights === 1) {
        sendResponse(res, 200, "User now has access to the assigned menus");
      } else {
        sendResponse(res, 201, "Failed to Grant New User Access Rights");
      }
    }
  } catch (error) {
    console.log(error);
  }
};

const revokeNewUserBranchDept = async (req, res) => {
  try {
    const revokeRights = await userData.revokeNewUserBranchDept(req.body);
    if (revokeRights === 1) {
      sendResponse(res, 200, "Right to the menus are now revoked for the user");
    } else {
      sendResponse(res, 201, "Failed to Map the required access");
    }
  } catch (error) {
    console.log(error);
  }
};

const getBranchAndDept = async (req, res) => {
  try {
    const BranchAndDept = await userData.getBranchAndDept();
    if (!!BranchAndDept && BranchAndDept.length > 0) {
      sendResponse(
        res,
        200,
        "Users Access Rights Mappings found successfully",
        BranchAndDept
      );
    } else {
      sendResponse(res, 201, "No Users Access Rights Mappings Found");
    }
  } catch (error) {
    console.log(error);
  }
};

module.exports = {
  branchDeptUserList,
  mapNewUserBranchDept,
  revokeNewUserBranchDept,
  getBranchAndDept,
};
