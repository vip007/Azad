const sendResponse = require("../../shared/sendResponse");
const userData = require("../../data/mappings/userProductBranchMapping");

const userProductBranchList = async (req, res) => {
  try {
    const productBranchList = await userData.userProductBranchList();
    if (!!productBranchList && productBranchList.length > 0) {
      sendResponse(
        res,
        200,
        "User product branch mapping list found Successfully",
        productBranchList
      );
    } else {
      sendResponse(res, 201, "Failed to fetch product branch mapping list");
    }
  } catch (error) {
    console.log(error);
  }
};

const ProductBranchID = async (req, res) => {
  try {
    const ProductBranchID = await userData.ProductBranchID();
    console.log(ProductBranchID);
    if (!!ProductBranchID && ProductBranchID.length > 0) {
      sendResponse(
        res,
        200,
        "Product and Branch found Successfully",
        ProductBranchID
      );
    } else {
      sendResponse(res, 201, "Failed to fetch product branch mapping list");
    }
  } catch (error) {
    console.log(error);
  }
};

const grantUserProductBranchMap = async (req, res) => {
  try {
    const CheckIfUsersAccessRightsExists = await userData.CheckIfExists(
      req.body
    );
    if (
      !!CheckIfUsersAccessRightsExists &&
      CheckIfUsersAccessRightsExists.length > 0
    ) {
      sendResponse(res, 201, "This access already exists");
    } else {
      const newMapping = await userData.grantUserProductBranchMap(req.body);
      if (newMapping === 1) {
        sendResponse(res, 200, "User now has access to the assigned menus");
      } else {
        sendResponse(res, 201, "Failed to Grant New User Access Rights");
      }
    }
  } catch (error) {
    console.log(error);
  }
};

const revokeUserProductBranchMap = async (req, res) => {
  try {
    const revokeRights = await userData.revokeUserProductBranchMap(req.body);
    if (revokeRights === 1) {
      sendResponse(res, 200, "Right to the menus are now revoked for the user");
    } else {
      sendResponse(res, 201, "Failed to Grant New User Access Rights");
    }
  } catch (error) {
    console.log(error);
  }
};

module.exports = {
  userProductBranchList,
  grantUserProductBranchMap,
  ProductBranchID,
  revokeUserProductBranchMap,
};
