const sendResponse = require("../../shared/sendResponse");
const userData = require("../../data/mappings/UserRoleMapping");

const UserRoleMappingList = async (req, res) => {
  try {
    const UserRoleMapping = await userData.UserRoleMappingList();
    if (!!UserRoleMapping && UserRoleMapping.length > 0) {
      sendResponse(
        res,
        200,
        "User Role Mapping Successfully Added",
        UserRoleMapping
      );
    } else {
      sendResponse(res, 201, "Failed to add User Role Mapping");
    }
  } catch (error) {
    console.log(error);
  }
};

const InsertRoleMapping = async (req, res) => {
  try {
    const CheckRoleMappingExists = await userData.CheckRoleMappingExists(
      req.body
    );
    if (CheckRoleMappingExists && CheckRoleMappingExists.length > 0) {
      sendResponse(res, 201, "This access already exists");
    } else {
      const RoleMapping = await userData.InsertRoleMapping(req.body);
      if (RoleMapping === 1) {
        sendResponse(res, 200, "User Role Mapping Successful");
      } else {
        sendResponse(res, 201, "Failed to Map User Role");
      }
    }
  } catch (error) {
    console.log(error);
  }
};

const revokeRoleMapping = async (req, res) => {
  try {
    const revokeRights = await userData.revokeRoleMapping(req.body);
    if (revokeRights === 1) {
      sendResponse(res, 200, "User Role Mapping Revoked Successfully");
    } else {
      sendResponse(res, 201, "Failed to Revoke User Role Mapping");
    }
  } catch (error) {
    console.log(error);
  }
};

module.exports = {
  UserRoleMappingList,
  InsertRoleMapping,
  revokeRoleMapping,
};
