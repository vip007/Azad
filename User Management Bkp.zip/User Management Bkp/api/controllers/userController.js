"use strict";

require("dotenv").config({ path: "../.env" });

const userData = require("../data/users");
const sendResponse = require("../shared/sendResponse");
const jwt = require("../shared/jwtAuth");

const signInUser = async (req, res, next) => {
  try {
    const user = await userData.getUserDetails(req.body);
    if (!!user && user.length > 0) {
      const applicationAccess = await userData.checkUserHasApplicationsAccess(
        user[0].ID_User
      );
      console.log("application access ::",applicationAccess);
      if (!!applicationAccess && applicationAccess.length > 0) {
        const branchmapping = await userData.getBranchMappingStatus(
          user[0].ID_User
        );
        if (branchmapping && branchmapping.length > 0) {
          const userAccess = await userData.getUserRightAccess(user[0].ID_User);
          if (userAccess && userAccess.length > 0) {
            let newArr = [];
            userAccess.forEach((item, i) => {
              let element = {};

              const index = newArr.findIndex(
                (e) => e.MenuName == item.MenuName
              );
              if (index !== -1) {
                newArr[index]["MenuEventName"].push(item.MenuEventName);
              } else {
                element["ID_User"] = item.ID_User;
                element["UserName"] = item.UserName;
                element["MenuName"] = item.MenuName;
                element["Code"] = item.Code;
                element["ID_UserType"] = item.ID_UserType;
                element["ID_Application"] = item.ID_Application;
                element["ID_Menu"] = item.ID_Menu;
                element["MenuEventName"] = [item.MenuEventName];
                element["ID_UserType"] = item.ID_UserType;
                element["ID_Application"] = item.ID_Application;
                element["ApplicationCode"] = item.ApplicationCode;
                newArr.push(element);
              }
            });
            const accessToken = jwt.generateAccessToken(user[0]);
            let finalData = {
              userdata: newArr,
              accessToken: accessToken,
              branch: branchmapping,
            };
            sendResponse(res, 200, "User LoggedIn Successfully", finalData);
          } else {
            sendResponse(res, 201, "User doesn't have menu rights");
          }
        } else {
          sendResponse(res, 201, "User doesn't have a active Branch");
        }
      } else {
        sendResponse(res, 201, "User doesn't have Application Access");
      }
    } else {
      sendResponse(
        res,
        201,
        "Invalid Credentials, Please Check UserId and Password"
      );
    }
  } catch (error) {
    sendResponse(res, 500, "Error Occured");
  }
};

async function loanProduct(req, res, next) {
  try {
    const loanProduct = await userData.getLoanProduct(req.body);

    if (!!loanProduct && loanProduct.length > 0) {
      sendResponse(res, 200, "Loan Product Found Successfully", loanProduct);
    } else {
      sendResponse(res, 201, "No Loan Product Found");
    }
  } catch (error) {
    console.log(error);
  }
}

module.exports = {
  signInUser,
  loanProduct,
};
