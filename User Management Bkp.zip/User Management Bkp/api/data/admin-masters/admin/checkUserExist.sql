SELECT *
FROM [dbo].[User]
WHERE [UserName]=@userName 