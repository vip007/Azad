Select [User].*,
[UserType].[UserType] as ID_UserType
from 
[dbo].[User] 
INNER JOIN [dbo].[UserType] ON [dbo].[UserType].[ID_UserType] = [dbo].[User].[ID_UserType]
ORDER BY
[User].[UserName]