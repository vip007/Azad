SELECT [ID_UserType],[UserType],[IsActive]
FROM [DEMOLOS_DB].[dbo].[UserType]