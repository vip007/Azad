Select [User].[ID_User],[User].[UserName],[User].[Code],[User].[UserPass],[User].[ID_UserType],[User].[IsActive],[User].[CreatedOn],[User].[IsMaker],[User].[IsChecker]
FROM [dbo].[User]
where [User].[ID_User] = @ID_User