"use strict";
const utils = require("../../utils");
const config = require("../../../config");
const sql = require("mssql");
let mssql = require("../../../mssql-connection-pooling");

/**
 * @description         List of All Users in the Database
 * @route               /api/admin/users
 * @Type                GET
 */
const UsersList = async () => {
  try {
    let pool = await mssql.GetCreateIfNotExistPool(config.sql);
    const sqlQueries = await utils.loadSqlQueries("admin-masters/admin");
    const event = await pool.request().query(sqlQueries.getAllUsersDetails);
    return event.recordset;
  } catch (error) {
    return error.message;
  }
};

/**
 * @description         Gets a single Users in the Database
 * @route               /api/admin/users
 * @Type                GET
 */
const UsersWithID = async (body) => {
  try {
    let pool = await mssql.GetCreateIfNotExistPool(config.sql);
    const sqlQueries = await utils.loadSqlQueries("admin-masters/admin");
    const event = await pool
      .request()
      .input("ID_User", sql.Int, body.userid)
      .query(sqlQueries.getUserWithID);
    return event.recordset;
  } catch (error) {
    return error.message;
  }
};

/**
 * @description         Deactives a User
 * @route               /api/admin/toggle-user-state
 * @Type                POST
 */
const toggleUserState = async (body) => {
  try {
    let pool = await mssql.GetCreateIfNotExistPool(config.sql);
    const sqlQueries = await utils.loadSqlQueries("admin-masters/admin");
    const event = await pool
      .request()
      .input("ID_User", sql.Int, body.userid)
      .input("IsActive", sql.Int, body.isActive)
      .query(sqlQueries.toggleUserState);
    return event.rowsAffected[0];
  } catch (error) {
    return error.message;
  }
};

/**
 * @description         Create a User
 * @route               /api/admin/create-user
 * @Type                POST
 */
const createUser = async (body) => {
  try {
    let pool = await mssql.GetCreateIfNotExistPool(config.sql);
    const sqlQueries = await utils.loadSqlQueries("admin-masters/admin");
    const event = await pool
      .request()
      .input("Username", sql.VarChar, body.username)
      .input("Password", sql.VarChar, body.password)
      .input("Code", sql.VarChar, body.code)
      .input("ID_UserType", sql.VarChar, body.usertype)
      .input("isChecker", sql.VarChar, body.isChecker)
      .input("isMaker", sql.VarChar, body.isMaker)
      .input("CreatedOn", sql.Date, body.createdOn)
      .input("CreatedBy", sql.VarChar, body.createdby)
      .query(sqlQueries.createUser);
    return event.rowsAffected[0];
  } catch (error) {
    return error.message;
  }
};

/**
 * @description         Modify a User
 * @route               /api/admin/modify-user
 * @Type                POST
 */
const modifyUser = async (body) => {
  try {
    let pool = await mssql.GetCreateIfNotExistPool(config.sql);
    const sqlQueries = await utils.loadSqlQueries("admin-masters/admin");
    const event = await pool
      .request()
      .input("ID_User", sql.Int, body.userid)
      .input("Username", sql.VarChar, body.username)
      .input("UserPass", sql.VarChar, body.password)
      .input("ID_UserType", sql.VarChar, body.usertype)
      .input("isChecker", sql.VarChar, body.isChecker)
      .input("isMaker", sql.VarChar, body.isMaker)
      .input("Code", sql.VarChar, body.code)
      .input("ModifiedOn", sql.Date, body.modifiedOn)
      .input("Modifiedby", sql.VarChar, body.modifiedBy)
      .query(sqlQueries.modifyUser);
    return event.rowsAffected[0];
  } catch (error) {
    return error.message;
  }
};

// @Helper Functions
const getUserTypes = async () => {
  try {
    let pool = await mssql.GetCreateIfNotExistPool(config.sql);
    const sqlQueries = await utils.loadSqlQueries("admin-masters/admin");
    const event = await pool.request().query(sqlQueries.getUserTypes);
    return event.recordset;
  } catch (error) {
    return error.message;
  }
};

const checkUserExist = async (body) => {
  try {
    let pool = await mssql.GetCreateIfNotExistPool(config.sql);
    const sqlQueries = await utils.loadSqlQueries("admin-masters/admin");
    const event = await pool
      .request()
      .input("userName", sql.VarChar, body.username)
      .query(sqlQueries.checkUserExist);
    return event.recordset;
  } catch (error) {
    return error.message;
  }
};

const searchUserLike = async (body) => {
  try {
    // console.log(body);
    let pool = await mssql.GetCreateIfNotExistPool(config.sql);
    const sqlQueries = await utils.loadSqlQueries("admin-masters/admin");
    const event = await pool
      .request()
      .input("Username", sql.VarChar, body.Username + "%")
      .query(sqlQueries.searchUserLike);
    console.log(event);
    return event.recordset;
  } catch (error) {
    return error.message;
  }
};

module.exports = {
  UsersList,
  UsersWithID,
  createUser,
  modifyUser,
  toggleUserState,
  getUserTypes,
  checkUserExist,
  searchUserLike,
};
