UPDATE [dbo].[User]
SET	[UserName]=@Username, [UserPass]=@UserPass, [Code]=@Code, [ID_UserType]=@ID_UserType , [IsChecker]=@isChecker,[IsMaker]=@isMaker, [ModifiedOn]=@ModifiedOn , [ModifiedBy]=@Modifiedby
Where [User].[ID_User] = @ID_User;
