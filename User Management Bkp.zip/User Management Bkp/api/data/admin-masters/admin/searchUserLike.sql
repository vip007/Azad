SELECT *
  FROM [dbo].[User]

  Where [User].[UserName] LIKE @Username