UPDATE [dbo].[User]
SET	IsActive = @IsActive
Where [User].[ID_User] = @ID_User;