SELECT *
FROM [dbo].[Application]
WHERE [ApplicationCode] = @ApplicationCode