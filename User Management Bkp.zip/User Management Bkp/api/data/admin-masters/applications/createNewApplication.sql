INSERT INTO [dbo].[Application]([ApplicationCode],[ApplicationName],[Description],[IsActive],[CreatedBy],[CreatedOn])
Values (@ApplicationCode, @ApplicationName,@Description,1,@createdby,@createdOn);