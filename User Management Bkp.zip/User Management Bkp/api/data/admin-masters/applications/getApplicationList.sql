
SELECT * FROM [dbo].[Application]