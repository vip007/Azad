"use strict";

const utils = require("../../utils");
const config = require("../../../config");
const sql = require("mssql");
let mssql = require("../../../mssql-connection-pooling");

const getApplicationList = async () => {
  try {
    let pool = await mssql.GetCreateIfNotExistPool(config.sql);
    const sqlQueries = await utils.loadSqlQueries("admin-masters/applications");
    const event = await pool.request().query(sqlQueries.getApplicationList);
    return event.recordset;
  } catch (error) {
    return error.message;
  }
};

const toggleApplicationState = async (body) => {
  try {
    let pool = await mssql.GetCreateIfNotExistPool(config.sql);
    const sqlQueries = await utils.loadSqlQueries("admin-masters/applications");
    const event = await pool
      .request()
      .input("ID_Application", sql.Int, body.ID_Application)
      .input("IsActive", sql.Int, body.IsActive)
      .query(sqlQueries.toggleApplicationState);
    return event.rowsAffected[0];
  } catch (error) {
    return error.message;
  }
};

const getApplicationWithID = async (params) => {
  try {
    let pool = await mssql.GetCreateIfNotExistPool(config.sql);
    const sqlQueries = await utils.loadSqlQueries("admin-masters/applications");
    const event = await pool
      .request()
      .input("ID_Application", sql.Int, params.id)
      .query(sqlQueries.getApplicationWithID);
    return event.recordset;
  } catch (error) {
    return error.message;
  }
};

const checkApplicationExist = async (body) => {
  try {
    let pool = await mssql.GetCreateIfNotExistPool(config.sql);
    const sqlQueries = await utils.loadSqlQueries("admin-masters/applications");
    const event = await pool
      .request()
      .input("ApplicationCode", sql.VarChar, body.ApplicationCode)
      .query(sqlQueries.checkApplicationExist);
    return event.recordset;
  } catch (error) {
    return error.message;
  }
};

const createNewApplication = async (body) => {
  try {
    let pool = await mssql.GetCreateIfNotExistPool(config.sql);
    const sqlQueries = await utils.loadSqlQueries("admin-masters/applications");
    const event = await pool
      .request()
      .input("ApplicationCode", sql.VarChar, body.ApplicationCode)
      .input("ApplicationName", sql.VarChar, body.ApplicationName)
      .input("Description", sql.VarChar, body.Description)
      .input("createdOn", sql.VarChar, body.createdOn)
      .input("createdby", sql.VarChar, body.createdby)
      .query(sqlQueries.createNewApplication);
    return event.rowsAffected[0];
  } catch (error) {
    return error.message;
  }
};

const modifyApplication = async (body) => {
  try {
    let pool = await mssql.GetCreateIfNotExistPool(config.sql);
    const sqlQueries = await utils.loadSqlQueries("admin-masters/applications");
    const event = await pool
      .request()
      .input("ID_Application", sql.Int, body.ID_Application)
      .input("ApplicationCode", sql.VarChar, body.ApplicationCode)
      .input("ApplicationName", sql.VarChar, body.ApplicationName)
      .input("Description", sql.VarChar, body.Description)
      .input("ModifiedBy", sql.VarChar, body.ModifiedBy)
      .input("ModifiedOn", sql.Date, body.ModifiedOn)
      .query(sqlQueries.modifyApplication);
    return event.rowsAffected[0];
  } catch (error) {
    return error.message;
  }
};

module.exports = {
  checkApplicationExist,
  createNewApplication,
  getApplicationList,
  toggleApplicationState,
  getApplicationWithID,
  modifyApplication,
};
