UPDATE [dbo].[Application]
SET	[ApplicationCode]=@ApplicationCode, [ApplicationName]=@ApplicationName, [Description]=@Description, [ModifiedBy]=@ModifiedBy, [ModifiedOn]=@ModifiedOn
Where [Application].[ID_Application] = @ID_Application;
