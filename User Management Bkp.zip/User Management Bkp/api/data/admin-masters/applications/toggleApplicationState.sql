UPDATE [dbo].[Application]
SET	IsActive = @IsActive
Where [Application].[ID_Application] = @ID_Application;