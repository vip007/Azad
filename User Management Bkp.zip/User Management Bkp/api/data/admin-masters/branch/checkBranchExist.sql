SELECT *
FROM [dbo].[Branch]
WHERE [Code] = @Code