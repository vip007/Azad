SELECT * FROM [dbo].[Branch]
Where [Branch].[ID_Branch] = @ID_Branch