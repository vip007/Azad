"use strict";

const utils = require("../../utils");
const config = require("../../../config");
const sql = require("mssql");
let mssql = require("../../../mssql-connection-pooling");

const getBranchList = async () => {
  try {
    let pool = await mssql.GetCreateIfNotExistPool(config.sql);
    const sqlQueries = await utils.loadSqlQueries("admin-masters/branch");
    const event = await pool.request().query(sqlQueries.getBranchList);
    return event.recordset;
  } catch (error) {
    return error.message;
  }
};

const toggleBranchState = async (body) => {
  try {
    let pool = await mssql.GetCreateIfNotExistPool(config.sql);
    const sqlQueries = await utils.loadSqlQueries("admin-masters/branch");
    const event = await pool
      .request()
      .input("ID_Branch", sql.Int, body.ID_Branch)
      .input("IsActive", sql.Int, body.IsActive)
      .query(sqlQueries.toggleBranchState);
    return event.rowsAffected[0];
  } catch (error) {
    return error.message;
  }
};

const checkBranchExist = async (body) => {
  try {
    //config.sql.database = "UATMoneyWiseFin"
    let pool = await mssql.GetCreateIfNotExistPool(config.sql);
    const sqlQueries = await utils.loadSqlQueries("admin-masters/branch");
    const event = await pool
      .request()
      .input("Code", sql.VarChar, body.Code)
      .query(sqlQueries.checkBranchExist);
    return event.recordset;
  } catch (error) {
    return error.message;
  }
};

const createNewBranch = async (body) => {
  try {
    let pool = await mssql.GetCreateIfNotExistPool(config.sql);
    const sqlQueries = await utils.loadSqlQueries("admin-masters/branch");

    const event = await pool
      .request()
      .input("Code", sql.VarChar, body.Code)
      .input("Name", sql.VarChar, body.Name)
      .input("ID_Location", sql.VarChar, body.ID_Location)
      .input("Address1", sql.VarChar, body.Address1)
      .input("City", sql.VarChar, body.City)
      .input("PinCode", sql.VarChar, body.PinCode)
      .input("ID_States", sql.VarChar, body.ID_States)
      .input("Mobile", sql.VarChar, body.Mobile)
      .input("STD", sql.VarChar, body.STD)
      .input("Branch_LandLine", sql.VarChar, body.Branch_LandLine)
      .input("Branch_EmailID", sql.VarChar, body.Branch_EmailID)
      .input("Contact_Person", sql.VarChar, body.Contact_Person)
      .input("Opening_Date", sql.VarChar, body.Opening_Date)
      .input("Closing_Date", sql.VarChar, body.Closing_Date)
      .input("Parent_BranchID", sql.VarChar, body.Parent_BranchID)
      .input("createdOn", sql.VarChar, body.createdOn)
      .input("createdby", sql.VarChar, body.createdby)
      .query(sqlQueries.createNewBranch);
    return event.rowsAffected[0];
  } catch (error) {
    return error.message;
  }
};

const modifyBranch = async (body) => {
  try {
    let pool = await mssql.GetCreateIfNotExistPool(config.sql);
    const sqlQueries = await utils.loadSqlQueries("admin-masters/branch");
    const event = await pool
      .request()
      .input("ID_Branch", sql.Int, body.ID_Branch)
      .input("Code", sql.VarChar, body.Code)
      .input("Name", sql.VarChar, body.Name)
      .input("ID_Location", sql.VarChar, body.ID_Location)
      .input("Address1", sql.VarChar, body.Address1)
      .input("City", sql.VarChar, body.City)
      .input("PinCode", sql.VarChar, body.PinCode)
      .input("ID_States", sql.VarChar, body.ID_States)
      .input("Mobile", sql.VarChar, body.Mobile)
      .input("STD", sql.VarChar, body.STD)
      .input("Branch_LandLine", sql.VarChar, body.Branch_LandLine)
      .input("Branch_EmailID", sql.VarChar, body.Branch_EmailID)
      .input("Contact_Person", sql.VarChar, body.Contact_Person)
      .input("Opening_Date", sql.VarChar, body.Opening_Date)
      .input("Closing_Date", sql.VarChar, body.Closing_Date)
      .input("Parent_BranchID", sql.VarChar, body.Parent_BranchID)
      .input("ModifiedBy", sql.VarChar, body.ModifiedBy)
      .input("ModifiedOn", sql.Date, body.ModifiedOn)
      .query(sqlQueries.modifyBranch);
    return event.rowsAffected[0];
  } catch (error) {
    return error.message;
  }
};

const getBranchWithID = async (params) => {
  try {
    let pool = await mssql.GetCreateIfNotExistPool(config.sql);
    const sqlQueries = await utils.loadSqlQueries("admin-masters/branch");
    const event = await pool
      .request()
      .input("ID_Branch", sql.Int, params.id)
      .query(sqlQueries.getBranchWithID);
    return event.recordset;
  } catch (error) {
    return error.message;
  }
};

module.exports = {
  checkBranchExist,
  createNewBranch,
  getBranchList,
  toggleBranchState,
  getBranchWithID,
  modifyBranch,
};
