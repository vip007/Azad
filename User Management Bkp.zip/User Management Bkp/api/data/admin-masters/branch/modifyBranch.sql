UPDATE [dbo].[Branch]
SET	
     [Code]=@Code
    ,[Name]=@Name
    ,[ID_Location]=@ID_Location
    ,[Address1]=@Address1
    ,[City]=@City
    ,[PinCode]=@PinCode
    ,[ID_States]=@ID_States
    ,[Mobile]=@Mobile
    ,[STD]=@STD
    ,[Branch_LandLine]=@Branch_LandLine
    ,[Branch_EmailID]=@Branch_EmailID
    ,[Contact_Person]=@Contact_Person
    ,[Opening_Date]=@Opening_Date
    ,[Closing_Date]=@Closing_Date
    ,[Parent_BranchID]=@Parent_BranchID
    ,[ModifiedBy]=@ModifiedBy
    ,[ModifiedOn]=@ModifiedOn

Where [Branch].[ID_Branch] = @ID_Branch;