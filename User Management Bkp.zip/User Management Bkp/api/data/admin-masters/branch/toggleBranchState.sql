UPDATE [dbo].[Branch]
SET	IsActive = @IsActive
Where [Branch].[ID_Branch] = @ID_Branch;