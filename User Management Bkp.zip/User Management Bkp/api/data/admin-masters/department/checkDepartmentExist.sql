SELECT *
FROM [dbo].[Department]
WHERE [Code] = @Code