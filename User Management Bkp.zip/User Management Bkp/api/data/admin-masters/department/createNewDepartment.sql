INSERT INTO [dbo].[Department]([Code],[Name],[IsActive],[CreatedBy],[CreatedOn])
Values (@Code, @Name,1,@createdby,@createdOn);