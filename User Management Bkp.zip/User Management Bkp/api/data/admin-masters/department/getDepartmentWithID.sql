SELECT * FROM [dbo].[Department]
Where [Department].[ID_Departmet] = @ID_Department