"use strict";

const utils = require("../../utils");
const config = require("../../../config");
const sql = require("mssql");
let mssql = require("../../../mssql-connection-pooling");

const getDepartmentList = async () => {
  try {
    let pool = await mssql.GetCreateIfNotExistPool(config.sql);
    const sqlQueries = await utils.loadSqlQueries("admin-masters/department");
    const event = await pool.request().query(sqlQueries.getDepartmentList);
    return event.recordset;
  } catch (error) {
    return error.message;
  }
};

const toggleDepartmentState = async (body) => {
  try {
    let pool = await mssql.GetCreateIfNotExistPool(config.sql);
    const sqlQueries = await utils.loadSqlQueries("admin-masters/department");
    const event = await pool
      .request()
      .input("ID_Department", sql.Int, body.ID_Department)
      .input("IsActive", sql.Int, body.IsActive)
      .query(sqlQueries.toggleDepartmentState);
    return event.rowsAffected[0];
  } catch (error) {
    return error.message;
  }
};

const getDepartmentWithID = async (params) => {
  try {
    let pool = await mssql.GetCreateIfNotExistPool(config.sql);
    const sqlQueries = await utils.loadSqlQueries("admin-masters/department");
    const event = await pool
      .request()
      .input("ID_Department", sql.Int, params.id)
      .query(sqlQueries.getDepartmentWithID);
    return event.recordset;
  } catch (error) {
    return error.message;
  }
};

const checkDepartmentExist = async (body) => {
  try {
    //config.sql.database = "UATMoneyWiseFin"
    let pool = await mssql.GetCreateIfNotExistPool(config.sql);
    const sqlQueries = await utils.loadSqlQueries("admin-masters/department");
    const event = await pool
      .request()
      .input("Code", sql.VarChar, body.Code)
      .query(sqlQueries.checkDepartmentExist);
    return event.recordset;
  } catch (error) {
    return error.message;
  }
};

const createNewDepartment = async (body) => {
  try {
    let pool = await mssql.GetCreateIfNotExistPool(config.sql);
    const sqlQueries = await utils.loadSqlQueries("admin-masters/department");
    const event = await pool
      .request()
      .input("Code", sql.VarChar, body.Code)
      .input("Name", sql.VarChar, body.Name)
      .input("createdOn", sql.VarChar, body.createdOn)
      .input("createdby", sql.VarChar, body.createdby)
      .query(sqlQueries.createNewDepartment);
    return event.rowsAffected[0];
  } catch (error) {
    return error.message;
  }
};

const modifyDepartment = async (body) => {
  try {
    let pool = await mssql.GetCreateIfNotExistPool(config.sql);
    const sqlQueries = await utils.loadSqlQueries("admin-masters/department");
    const event = await pool
      .request()
      .input("ID_Department", sql.Int, body.ID_Department)
      .input("Code", sql.VarChar, body.Code)
      .input("Name", sql.VarChar, body.Name)
      .input("ModifiedBy", sql.VarChar, body.ModifiedBy)
      .input("ModifiedOn", sql.Date, body.ModifiedOn)
      .query(sqlQueries.modifyDepartment);
    return event.rowsAffected[0];
  } catch (error) {
    return error.message;
  }
};

module.exports = {
  getDepartmentList,
  checkDepartmentExist,
  toggleDepartmentState,
  createNewDepartment,
  getDepartmentWithID,
  modifyDepartment,
};
