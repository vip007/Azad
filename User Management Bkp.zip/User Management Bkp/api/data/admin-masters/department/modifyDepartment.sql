UPDATE [dbo].[Department]
SET	[Code]=@Code, 
    [Name]=@Name,
    [ModifiedBy]=@ModifiedBy, 
    [ModifiedOn]=@ModifiedOn
Where [Department].[ID_Departmet] = @ID_Department;