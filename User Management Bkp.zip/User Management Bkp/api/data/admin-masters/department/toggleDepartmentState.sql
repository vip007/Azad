UPDATE [dbo].[Department]
SET	IsActive = @IsActive
Where [Department].[ID_Departmet] = @ID_Department;