SELECT *
FROM [dbo].[Location]
WHERE [LocationCode] = @LocationCode