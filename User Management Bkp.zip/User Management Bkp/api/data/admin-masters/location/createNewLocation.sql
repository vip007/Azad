INSERT INTO [dbo].[Location]([LocationCode],[LocationName],[LoctionDescription],[IsActive],[CreatedBy],[CreatedOn])
Values (@LocationCode, @LocationName, @LoctionDescription,1,@createdby,@createdOn);