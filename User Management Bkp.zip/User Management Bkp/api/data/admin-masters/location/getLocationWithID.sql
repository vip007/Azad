SELECT * FROM [dbo].[Location]
Where [Location].[ID_Location] = @ID_Location