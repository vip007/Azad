"use strict";

const utils = require("../../utils");
const config = require("../../../config");
const sql = require("mssql");
let mssql = require("../../../mssql-connection-pooling");

const getLocationList = async () => {
  try {
    let pool = await mssql.GetCreateIfNotExistPool(config.sql);
    const sqlQueries = await utils.loadSqlQueries("admin-masters/location");
    const event = await pool.request().query(sqlQueries.getLocationList);
    return event.recordset;
  } catch (error) {
    return error.message;
  }
};

const toggleLocationState = async (body) => {
  try {
    let pool = await mssql.GetCreateIfNotExistPool(config.sql);
    const sqlQueries = await utils.loadSqlQueries("admin-masters/location");
    const event = await pool
      .request()
      .input("ID_Location", sql.Int, body.ID_Location)
      .input("IsActive", sql.Int, body.IsActive)
      .query(sqlQueries.toggleLocationState);
    return event.rowsAffected[0];
  } catch (error) {
    return error.message;
  }
};

const getLocationWithID = async (params) => {
  try {
    let pool = await mssql.GetCreateIfNotExistPool(config.sql);
    const sqlQueries = await utils.loadSqlQueries("admin-masters/location");
    const event = await pool
      .request()
      .input("ID_Location", sql.Int, params.id)
      .query(sqlQueries.getLocationWithID);
    return event.recordset;
  } catch (error) {
    return error.message;
  }
};

const checkLocationExist = async (body) => {
  try {
    //config.sql.database = "UATMoneyWiseFin"
    let pool = await mssql.GetCreateIfNotExistPool(config.sql);
    const sqlQueries = await utils.loadSqlQueries("admin-masters/location");
    const event = await pool
      .request()
      .input("LocationCode", sql.VarChar, body.LocationCode)
      .query(sqlQueries.checkLocationExist);
    return event.recordset;
  } catch (error) {
    return error.message;
  }
};

const createNewLocation = async (body) => {
  try {
    let pool = await mssql.GetCreateIfNotExistPool(config.sql);
    const sqlQueries = await utils.loadSqlQueries("admin-masters/location");
    const event = await pool
      .request()
      .input("LocationCode", sql.VarChar, body.LocationCode)
      .input("LocationName", sql.VarChar, body.LocationName)
      .input("LoctionDescription", sql.VarChar, body.LoctionDescription)
      .input("createdOn", sql.VarChar, body.createdOn)
      .input("createdby", sql.VarChar, body.createdby)
      .query(sqlQueries.createNewLocation);
    return event.rowsAffected[0];
  } catch (error) {
    return error.message;
  }
};

const modifyLocation = async (body) => {
  try {
    let pool = await mssql.GetCreateIfNotExistPool(config.sql);
    const sqlQueries = await utils.loadSqlQueries("admin-masters/location");
    const event = await pool
      .request()
      .input("ID_Location", sql.Int, body.ID_Location)
      .input("LocationCode", sql.VarChar, body.LocationCode)
      .input("LocationName", sql.VarChar, body.LocationName)
      .input("LoctionDescription", sql.VarChar, body.LoctionDescription)
      .input("ModifiedBy", sql.VarChar, body.ModifiedBy)
      .input("ModifiedOn", sql.Date, body.ModifiedOn)
      .query(sqlQueries.modifyLocation);
    return event.rowsAffected[0];
  } catch (error) {
    return error.message;
  }
};

module.exports = {
  getLocationList,
  checkLocationExist,
  toggleLocationState,
  createNewLocation,
  getLocationWithID,
  modifyLocation,
};
