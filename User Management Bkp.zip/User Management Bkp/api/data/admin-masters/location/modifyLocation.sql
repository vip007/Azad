UPDATE [dbo].[Location]
SET	[LocationCode]=@LocationCode, 
    [LocationName]=@LocationName, 
    [LoctionDescription]=@LoctionDescription, 
    [ModifiedBy]=@ModifiedBy, 
    [ModifiedOn]=@ModifiedOn
Where [Location].[ID_Location] = @ID_Location;