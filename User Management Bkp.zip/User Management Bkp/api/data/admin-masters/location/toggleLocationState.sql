UPDATE [dbo].[Location]
SET	IsActive = @IsActive
Where [Location].[ID_Location] = @ID_Location;