SELECT *
FROM [dbo].[Menu]
WHERE [MenuCode] = @MenuCode