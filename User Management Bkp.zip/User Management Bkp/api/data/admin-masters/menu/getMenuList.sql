-- SELECT [Menu].*, [Menu].[ID_Menu_Parent] FROM [dbo].[Menu]
-- INNER JOIN [dbo].[Menu] ON [dbo].[Menu].[ID_Menu] = [dbo].[Menu].[ID_Menu_Parent]

SELECT cm.[ID_Menu] 
      ,cm.[MenuCode]
      ,cm.[MenuName]
      ,cm.[Description]
      ,app.[ApplicationCode] as [ID_Application]
      ,cm.[IsActive]
      ,cm.[CreatedBy]
      ,cm.[CreatedOn]
      ,cm.[ModifiedBy]
      ,cm.[ModifiedOn]

, pm.MenuCode as ID_Menu_Parent FROM Menu as cm
Left join Menu as pm on cm.ID_Menu_Parent = pm.ID_Menu
INNER JOIN Application as app on app.ID_Application = cm.ID_Application

ORDER BY cm.ID_Menu_Parent
