SELECT * FROM [dbo].[Menu]
Where [Menu].[ID_menu] = @ID_Menu