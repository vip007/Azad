"use strict";

const utils = require("../../utils");
const config = require("../../../config");
const sql = require("mssql");
let mssql = require("../../../mssql-connection-pooling");

const getMenuList = async () => {
  try {
    let pool = await mssql.GetCreateIfNotExistPool(config.sql);
    const sqlQueries = await utils.loadSqlQueries("admin-masters/menu");
    const event = await pool.request().query(sqlQueries.getMenuList);
    return event.recordset;
  } catch (error) {
    return error.message;
  }
};

const toggleMenuState = async (body) => {
  try {
    let pool = await mssql.GetCreateIfNotExistPool(config.sql);
    const sqlQueries = await utils.loadSqlQueries("admin-masters/menu");
    const event = await pool
      .request()
      .input("ID_Menu", sql.Int, body.ID_Menu)
      .input("IsActive", sql.Int, body.IsActive)
      .query(sqlQueries.toggleMenuState);
    return event.rowsAffected[0];
  } catch (error) {
    return error.message;
  }
};

const getMenuWithID = async (params) => {
  try {
    let pool = await mssql.GetCreateIfNotExistPool(config.sql);
    const sqlQueries = await utils.loadSqlQueries("admin-masters/menu");
    const event = await pool
      .request()
      .input("ID_Menu", sql.Int, params.id)
      .query(sqlQueries.getMenuWithID);
    return event.recordset;
  } catch (error) {
    return error.message;
  }
};

const checkMenuExist = async (body) => {
  try {
    //config.sql.database = "UATMoneyWiseFin"
    let pool = await mssql.GetCreateIfNotExistPool(config.sql);
    const sqlQueries = await utils.loadSqlQueries("admin-masters/menu");
    const event = await pool
      .request()
      .input("MenuCode", sql.VarChar, body.MenuCode)
      .query(sqlQueries.checkMenuExist);
    return event.recordset;
  } catch (error) {
    return error.message;
  }
};

const createNewMenu = async (body) => {
  try {
    let pool = await mssql.GetCreateIfNotExistPool(config.sql);
    const sqlQueries = await utils.loadSqlQueries("admin-masters/menu");
    const event = await pool
      .request()
      .input("MenuCode", sql.VarChar, body.MenuCode)
      .input("MenuName", sql.VarChar, body.MenuName)
      .input("Description", sql.VarChar, body.Description)
      .input("ID_Menu_Parent", sql.VarChar, body.ID_Menu_Parent)
      .input("ID_Application", sql.VarChar, body.ID_Application)
      .input("createdOn", sql.VarChar, body.createdOn)
      .input("createdby", sql.VarChar, body.createdby)
      .query(sqlQueries.createNewMenu);
    return event.rowsAffected[0];
  } catch (error) {
    return error.message;
  }
};

const modifyMenu = async (body) => {
  try {
    let pool = await mssql.GetCreateIfNotExistPool(config.sql);
    const sqlQueries = await utils.loadSqlQueries("admin-masters/menu");
    const event = await pool
      .request()
      .input("ID_Menu", sql.Int, body.ID_Menu)
      .input("MenuCode", sql.VarChar, body.MenuCode)
      .input("MenuName", sql.VarChar, body.MenuName)
      .input("Description", sql.VarChar, body.Description)
      .input("ID_Menu_Parent", sql.VarChar, body.ID_Menu_Parent)
      .input("ID_Application", sql.VarChar, body.ID_Application)
      .input("ModifiedBy", sql.VarChar, body.ModifiedBy)
      .input("ModifiedOn", sql.Date, body.ModifiedOn)
      .query(sqlQueries.modifyMenu);
    return event.rowsAffected[0];
  } catch (error) {
    return error.message;
  }
};

module.exports = {
  getMenuList,
  checkMenuExist,
  toggleMenuState,
  createNewMenu,
  getMenuWithID,
  modifyMenu,
};
