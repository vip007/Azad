UPDATE [dbo].[Menu]
SET	[MenuCode]=@MenuCode, 
    [MenuName]=@MenuName, 
    [Description]=@Description, 
    [ID_Menu_Parent]=@ID_Menu_Parent,
    [ID_Application]=@ID_Application,
    [ModifiedBy]=@ModifiedBy, 
    [ModifiedOn]=@ModifiedOn
Where [Menu].[ID_Menu] = @ID_Menu;