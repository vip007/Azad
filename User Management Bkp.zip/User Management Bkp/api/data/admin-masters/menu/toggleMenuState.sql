UPDATE [dbo].[Menu]
SET	IsActive = @IsActive
Where [Menu].[ID_Menu] = @ID_Menu;