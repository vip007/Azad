SELECT [MenuEvent].[ID_MenuEvent]
      ,[MenuEvent].[MenuEventCode]
      ,[MenuEvent].[MenuEventName]
      ,[MenuEvent].[Description]
      ,[Menu].[MenuCode] as MenuCode
      ,[Menu].[ID_Menu] as ID_Menu

      ,[MenuEvent].[CreatedBy]
      ,[MenuEvent].[CreatedOn]
      ,[MenuEvent].[ModifiedBy]
      ,[MenuEvent].[ModifiedOn]
  FROM [dbo].[MenuEvent]
  INNER JOIN [dbo].[Menu] ON [dbo].[Menu].[ID_Menu] = [dbo].[MenuEvent].[ID_Menu]
  Where [dbo].[MenuEvent].[ID_Menu] = @ID_Menu