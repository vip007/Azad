INSERT INTO [dbo].[MenuEvent]([MenuEventCode],[ID_Menu],[MenuEventName],[Description],[CreatedBy],[CreatedOn])
Values (@MenuEventCode,@ID_Menu, @MenuEventName,@Description,@createdby,@createdOn);