"use strict";

const utils = require("../../utils");
const config = require("../../../config");
const sql = require("mssql");
let mssql = require("../../../mssql-connection-pooling");

const MenuEventList = async () => {
  try {
    let pool = await mssql.GetCreateIfNotExistPool(config.sql);
    const sqlQueries = await utils.loadSqlQueries("admin-masters/menuevent");
    const event = await pool.request().query(sqlQueries.MenuEventList);
    return event.recordset;
  } catch (error) {
    return error.message;
  }
};

const MenuEventRemove = async (body) => {
  try {
    let pool = await mssql.GetCreateIfNotExistPool(config.sql);
    const sqlQueries = await utils.loadSqlQueries("admin-masters/menuevent");
    const event = await pool
      .request()
      .input("ID_MenuEvent", sql.Int, body.ID_MenuEvent)
      .query(sqlQueries.MenuEventRemove);
    return event.rowsAffected[0];
  } catch (error) {
    return error.message;
  }
};

const MenuEventWithID = async (body) => {
  try {
    let pool = await mssql.GetCreateIfNotExistPool(config.sql);
    const sqlQueries = await utils.loadSqlQueries("admin-masters/menuevent");
    const event = await pool
      .request()
      .input("ID_Menu", sql.Int, body.ID_MenuEvent)
      .query(sqlQueries.MenuEventWithID);
    return event.recordset;
  } catch (error) {
    return error.message;
  }
};

const checkMenuEventExist = async (body) => {
  try {
    let pool = await mssql.GetCreateIfNotExistPool(config.sql);
    const sqlQueries = await utils.loadSqlQueries("admin-masters/menuevent");
    const event = await pool
      .request()
      .input("ID_Menu", sql.Int, body.ID_Menu)
      .input("MenuEventCode", sql.VarChar, body.MenuEventCode);
    return event.recordset;
  } catch (error) {
    return error.message;
  }
};

const createNewMenuEvent = async (body) => {
  try {
    let pool = await mssql.GetCreateIfNotExistPool(config.sql);
    const sqlQueries = await utils.loadSqlQueries("admin-masters/menuevent");
    const event = await pool
      .request()
      .input("ID_Menu", sql.Int, body.ID_Menu)
      .input("MenuEventCode", sql.VarChar, body.MenuEventCode)
      .input("MenuEventName", sql.VarChar, body.MenuEventName)
      .input("Description", sql.VarChar, body.Description)
      .input("createdOn", sql.VarChar, body.createdOn)
      .input("createdby", sql.VarChar, body.createdby)
      .query(sqlQueries.createNewMenuEvent);
    return event.rowsAffected[0];
  } catch (error) {
    return error.message;
  }
};

const modifyMenuEvent = async (body) => {
  try {
    let pool = await mssql.GetCreateIfNotExistPool(config.sql);
    const sqlQueries = await utils.loadSqlQueries("admin-masters/menuevent");
    const event = await pool
      .request()
      .input("ID_Menu", sql.Int, body.ID_Menu)
      .input("ID_MenuEvent", sql.Int, body.ID_MenuEvent)
      .input("MenuEventCode", sql.VarChar, body.MenuEventCode)
      .input("MenuEventName", sql.VarChar, body.MenuEventName)
      .input("Description", sql.VarChar, body.Description)
      .input("ModifiedBy", sql.VarChar, body.ModifiedBy)
      .input("ModifiedOn", sql.Date, body.ModifiedOn)
      .query(sqlQueries.modifyMenuEvent);
    return event.rowsAffected[0];
  } catch (error) {
    return error.message;
  }
};

module.exports = {
  MenuEventList,
  MenuEventRemove,
  createNewMenuEvent,
  checkMenuEventExist,
  modifyMenuEvent,
  MenuEventWithID,
};
