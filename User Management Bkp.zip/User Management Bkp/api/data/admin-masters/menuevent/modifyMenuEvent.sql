UPDATE [dbo].[MenuEvent]
SET	[MenuEventCode]=@MenuEventCode, [MenuEventName]=@MenuEventName,[ID_Menu]=@ID_Menu, [Description]=@Description, [ModifiedBy]=@ModifiedBy, [ModifiedOn]=@ModifiedOn
Where [MenuEvent].[ID_MenuEvent] = @ID_MenuEvent;