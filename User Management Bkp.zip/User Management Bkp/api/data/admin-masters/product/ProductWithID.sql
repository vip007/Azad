SELECT * FROM [dbo].[Product]
Where [Product].[ID_Product] = @ID_Product