"use strict";

const utils = require("../../utils");
const config = require("../../../config");
const sql = require("mssql");
let mssql = require("../../../mssql-connection-pooling");

const ProductList = async () => {
  try {
    let pool = await mssql.GetCreateIfNotExistPool(config.sql);
    const sqlQueries = await utils.loadSqlQueries("admin-masters/product");
    const event = await pool.request().query(sqlQueries.ProductList);
    return event.recordset;
  } catch (error) {
    return error.message;
  }
};

const toggleProductState = async (body) => {
  try {
    let pool = await mssql.GetCreateIfNotExistPool(config.sql);
    const sqlQueries = await utils.loadSqlQueries("admin-masters/product");
    const event = await pool
      .request()
      .input("ID_Product", sql.Int, body.ID_Product)
      .input("IsActive", sql.Int, body.IsActive)
      .query(sqlQueries.toggleProductState);
    return event.rowsAffected[0];
  } catch (error) {
    return error.message;
  }
};

const ProductWithID = async (params) => {
  try {
    let pool = await mssql.GetCreateIfNotExistPool(config.sql);
    const sqlQueries = await utils.loadSqlQueries("admin-masters/product");
    const event = await pool
      .request()
      .input("ID_Product", sql.Int, params.id)
      .query(sqlQueries.ProductWithID);
    return event.recordset;
  } catch (error) {
    return error.message;
  }
};

const checkProductExist = async (body) => {
  try {
    //config.sql.database = "UATMoneyWiseFin"
    let pool = await mssql.GetCreateIfNotExistPool(config.sql);
    const sqlQueries = await utils.loadSqlQueries("admin-masters/product");
    const event = await pool
      .request()
      .input("ProductCode", sql.VarChar, body.ProductCode)
      .query(sqlQueries.checkProductExist);
    return event.recordset;
  } catch (error) {
    return error.message;
  }
};

const createNewProduct = async (body) => {
  try {
    let pool = await mssql.GetCreateIfNotExistPool(config.sql);
    const sqlQueries = await utils.loadSqlQueries("admin-masters/product");
    const event = await pool
      .request()
      .input("ProductCode", sql.VarChar, body.ProductCode)
      .input("ID_Application", sql.VarChar, body.ID_Application)
      .input("ProductName", sql.VarChar, body.ProductName)
      .input("Description", sql.VarChar, body.Description)
      .input("createdOn", sql.VarChar, body.createdOn)
      .input("createdby", sql.VarChar, body.createdby)
      .query(sqlQueries.createNewProduct);
    return event.rowsAffected[0];
  } catch (error) {
    return error.message;
  }
};

const modifyProduct = async (body) => {
  try {
    let pool = await mssql.GetCreateIfNotExistPool(config.sql);
    const sqlQueries = await utils.loadSqlQueries("admin-masters/product");
    const event = await pool
      .request()
      .input("ID_Product", sql.Int, body.ID_Product)
      .input("ID_Application", sql.Int, body.ID_Application)
      .input("ProductCode", sql.VarChar, body.ProductCode)
      .input("ProductName", sql.VarChar, body.ProductName)
      .input("Description", sql.VarChar, body.Description)
      .input("ModifiedBy", sql.VarChar, body.ModifiedBy)
      .input("ModifiedOn", sql.Date, body.ModifiedOn)
      .query(sqlQueries.modifyProduct);
    return event.rowsAffected[0];
  } catch (error) {
    return error.message;
  }
};

module.exports = {
  ProductList,
  toggleProductState,
  createNewProduct,
  checkProductExist,
  modifyProduct,
  ProductWithID,
};
