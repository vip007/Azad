UPDATE [dbo].[Product]
SET	[ProductCode]=@ProductCode, [ProductName]=@ProductName,[ID_Application]=@ID_Application, [Description]=@Description, [ModifiedBy]=@ModifiedBy, [ModifiedOn]=@ModifiedOn
Where [Product].[ID_Product] = @ID_Product;