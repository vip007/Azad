UPDATE [dbo].[Product]
SET	IsActive = @IsActive
Where [Product].[ID_Product] = @ID_Product;