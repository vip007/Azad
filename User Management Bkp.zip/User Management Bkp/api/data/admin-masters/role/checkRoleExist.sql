SELECT *
FROM [dbo].[Role]
WHERE [Code] = @Code