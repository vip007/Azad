INSERT INTO [dbo].[Role]([Code],[Name],[Description],[IsActive],[CreatedBy],[CreatedOn])
Values (@Code, @Name,@Description,1,@createdby,@createdOn);