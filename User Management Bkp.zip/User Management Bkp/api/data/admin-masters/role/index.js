"use strict";

const utils = require("../../utils");
const config = require("../../../config");
const sql = require("mssql");
let mssql = require("../../../mssql-connection-pooling");

const getRoleList = async () => {
  try {
    let pool = await mssql.GetCreateIfNotExistPool(config.sql);
    const sqlQueries = await utils.loadSqlQueries("admin-masters/role");
    const event = await pool.request().query(sqlQueries.getRoleList);
    return event.recordset;
  } catch (error) {
    return error.message;
  }
};

const toggleRoleState = async (body) => {
  try {
    let pool = await mssql.GetCreateIfNotExistPool(config.sql);
    const sqlQueries = await utils.loadSqlQueries("admin-masters/role");
    const event = await pool
      .request()
      .input("ID_Role", sql.Int, body.ID_Role)
      .input("IsActive", sql.Int, body.IsActive)
      .query(sqlQueries.toggleRoleState);
    return event.rowsAffected[0];
  } catch (error) {
    return error.message;
  }
};

const checkRoleExist = async (body) => {
  try {
    //config.sql.database = "UATMoneyWiseFin"
    let pool = await mssql.GetCreateIfNotExistPool(config.sql);
    const sqlQueries = await utils.loadSqlQueries("admin-masters/role");
    const event = await pool
      .request()
      .input("Code", sql.VarChar, body.Code)
      .query(sqlQueries.checkRoleExist);
    return event.recordset;
  } catch (error) {
    return error.message;
  }
};

const createNewRole = async (body) => {
  try {
    let pool = await mssql.GetCreateIfNotExistPool(config.sql);
    const sqlQueries = await utils.loadSqlQueries("admin-masters/role");
    const event = await pool
      .request()
      .input("Code", sql.VarChar, body.Code)
      .input("Name", sql.VarChar, body.Name)
      .input("Description", sql.VarChar, body.Description)
      .input("createdOn", sql.VarChar, body.createdOn)
      .input("createdby", sql.VarChar, body.createdby)
      .query(sqlQueries.createNewRole);
    return event.rowsAffected[0];
  } catch (error) {
    return error.message;
  }
};

const modifyRole = async (body) => {
  try {
    let pool = await mssql.GetCreateIfNotExistPool(config.sql);
    const sqlQueries = await utils.loadSqlQueries("admin-masters/role");
    const event = await pool
      .request()
      .input("ID_Role", sql.Int, body.ID_Role)
      .input("Code", sql.VarChar, body.Code)
      .input("Name", sql.VarChar, body.Name)
      .input("Description", sql.VarChar, body.Description)
      .input("ModifiedBy", sql.VarChar, body.ModifiedBy)
      .input("ModifiedOn", sql.Date, body.ModifiedOn)
      .query(sqlQueries.modifyRole);
    return event.rowsAffected[0];
  } catch (error) {
    return error.message;
  }
};

const getRoleWithID = async (params) => {
  try {
    let pool = await mssql.GetCreateIfNotExistPool(config.sql);
    const sqlQueries = await utils.loadSqlQueries("admin-masters/role");
    const event = await pool
      .request()
      .input("ID_Role", sql.Int, params.id)
      .query(sqlQueries.getRoleWithID);
    return event.recordset;
  } catch (error) {
    return error.message;
  }
};

module.exports = {
  checkRoleExist,
  createNewRole,
  getRoleList,
  toggleRoleState,
  modifyRole,
  getRoleWithID,
};
