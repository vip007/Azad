UPDATE [dbo].[Role]
SET	[Code]=@Code, 
    [Name]=@Name, 
    [Description]=@Description, 
    [ModifiedBy]=@ModifiedBy, 
    [ModifiedOn]=@ModifiedOn
Where [Role].[ID_Role] = @ID_Role;