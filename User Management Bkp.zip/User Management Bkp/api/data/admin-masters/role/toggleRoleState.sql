UPDATE [dbo].[Role]
SET	IsActive = @IsActive
Where [Role].[ID_Role] = @ID_Role;