SELECT [ID_UserType]
      ,[UserType]
      ,[IsActive]
      ,[CreatedBy]
      ,[CreatedOn]
      ,[ModifiedBy]
      ,[ModifiedOn]
  FROM [DEMOLOS_DB].[dbo].[UserType]
  WHERE [UserType] = @UserType