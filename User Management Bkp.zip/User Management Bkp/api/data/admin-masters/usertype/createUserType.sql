INSERT INTO [dbo].[UserType]([UserType],[IsActive],[CreatedBy],[CreatedOn])
Values (@UserType,1,@CreatedBy,@CreatedOn);