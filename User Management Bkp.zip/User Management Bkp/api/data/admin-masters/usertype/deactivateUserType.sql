UPDATE [dbo].[UserType]
SET	IsActive = @IsActive
Where [UserType].[ID_UserType] = @ID_UserType