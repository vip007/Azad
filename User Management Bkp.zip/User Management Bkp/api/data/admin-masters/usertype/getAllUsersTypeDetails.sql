Select [UserType].*
from 
[dbo].[UserType] 




