Select *
FROM [dbo].[UserType]
where [UserType].[ID_UserType] = @ID_UserType

