"use strict";
const utils = require("../../utils");
const config = require("../../../config");
const sql = require("mssql");
let mssql = require("../../../mssql-connection-pooling");

/**
 * @description         List of All Users in the Database
 * @route               /api/admin/users
 * @Type                GET
 */
const getUsersTypeList = async () => {
  try {
    let pool = await mssql.GetCreateIfNotExistPool(config.sql);
    const sqlQueries = await utils.loadSqlQueries("admin-masters/usertype");
    const event = await pool.request().query(sqlQueries.getAllUsersTypeDetails);
    return event.recordset;
  } catch (error) {
    return error.message;
  }
};

/**
 * @description         Gets a single Users in the Database
 * @route               /api/admin/users
 * @Type                GET
 */
const getUsersTypeWithID = async (params) => {
  try {
    let pool = await mssql.GetCreateIfNotExistPool(config.sql);
    const sqlQueries = await utils.loadSqlQueries("admin-masters/usertype");
    const event = await pool
      .request()
      .input("ID_UserType", sql.Int, params.id)
      .query(sqlQueries.getUsersTypeWithID);
    return event.recordset;
  } catch (error) {
    return error.message;
  }
};

/**
 * @description         Deactives a User
 * @route               /api/admin/deactivate-user
 * @Type                POST
 */
const deactivateUserType = async (body) => {
  try {
    let pool = await mssql.GetCreateIfNotExistPool(config.sql);
    const sqlQueries = await utils.loadSqlQueries("admin-masters/usertype");
    const event = await pool
      .request()
      .input("ID_UserType", sql.Int, body.ID_UserType)
      .input("IsActive", sql.Int, body.IsActive)
      .query(sqlQueries.deactivateUserType);
    return event.rowsAffected[0];
  } catch (error) {
    return error.message;
  }
};

/**
 * @description         Create a User
 * @route               /api/admin/create-user
 * @Type                POST
 */
const createUserType = async (body) => {
  try {
    let pool = await mssql.GetCreateIfNotExistPool(config.sql);
    const sqlQueries = await utils.loadSqlQueries("admin-masters/usertype");
    const event = await pool
      .request()
      .input("UserType", sql.VarChar, body.UserType)
      .input("CreatedOn", sql.Date, body.CreatedOn)
      .input("CreatedBy", sql.VarChar, body.CreatedBy)
      .query(sqlQueries.createUserType);
    return event.rowsAffected[0];
  } catch (error) {
    return error.message;
  }
};

/**
 * @description         Modify a User
 * @route               /api/admin/modify-user
 * @Type                POST
 */
const modifyUserType = async (body) => {
  try {
    let pool = await mssql.GetCreateIfNotExistPool(config.sql);
    const sqlQueries = await utils.loadSqlQueries("admin-masters/usertype");
    const event = await pool
      .request()
      .input("ID_UserType", sql.Int, body.ID_UserType)
      .input("UserType", sql.VarChar, body.UserType)
      .input("ModifiedOn", sql.VarChar, body.ModifiedOn)
      .input("Modifiedby", sql.VarChar, body.ModifiedBy)
      .query(sqlQueries.modifyUserType);
    return event.rowsAffected[0];
  } catch (error) {
    return error.message;
  }
};

// @Helper Functions
const CheckIfUserTypeExists = async (body) => {
  try {
    let pool = await mssql.GetCreateIfNotExistPool(config.sql);
    const sqlQueries = await utils.loadSqlQueries("admin-masters/usertype");
    const event = await pool
      .request()
      .input("UserType", sql.VarChar, body.UserType)
      .query(sqlQueries.CheckIfUserTypeExists);
    return event.recordset;
  } catch (error) {
    return error.message;
  }
};

module.exports = {
  getUsersTypeList,
  getUsersTypeWithID,
  createUserType,
  modifyUserType,
  deactivateUserType,
  CheckIfUserTypeExists,
};
