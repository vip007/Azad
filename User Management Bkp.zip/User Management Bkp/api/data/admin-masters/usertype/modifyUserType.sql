UPDATE [dbo].[UserType]
SET	[UserType]=@UserType, [ModifiedOn]=@ModifiedOn , [ModifiedBy]=@Modifiedby
Where [UserType].[ID_UserType] = @ID_UserType;