SELECT ID_UserRoleMapping, ID_User, ID_Role, CreatedBy, CreatedOn, ModifiedBy, ModifiedOn
FROM dbo.UserRoleMapping
Where ID_User=@ID_User and ID_Role =@ID_Role