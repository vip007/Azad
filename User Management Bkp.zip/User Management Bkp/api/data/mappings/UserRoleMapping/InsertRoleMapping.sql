INSERT INTO dbo.UserRoleMapping
(ID_User, ID_Role, CreatedBy, CreatedOn)
VALUES(@ID_User, @ID_Role, @CreatedBy, @CreatedOn);