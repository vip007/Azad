SELECT [ID_UserRoleMapping], [User].[UserName], [Role].[Name] as RoleName, [UserRoleMapping].[CreatedBy], [UserRoleMapping].[CreatedOn], [UserRoleMapping].[ModifiedBy], [UserRoleMapping].[ModifiedOn]
FROM [dbo].[UserRoleMapping]
INNER JOIN dbo.[User] ON dbo.[User].[ID_User] = dbo.[UserRoleMapping].[ID_User]
INNER JOIN dbo.[Role] ON dbo.[Role].[ID_Role] = dbo.[UserRoleMapping].[ID_Role]