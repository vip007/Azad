"use strict";

const utils = require("../../utils");
const config = require("../../../config");
const sql = require("mssql");
let mssql = require("../../../mssql-connection-pooling");

const UserRoleMappingList = async () => {
  try {
    let pool = await mssql.GetCreateIfNotExistPool(config.sql);
    const sqlQueries = await utils.loadSqlQueries("mappings/UserRoleMapping");
    const event = await pool.request().query(sqlQueries.UserRoleMappingList);
    return event.recordset;
  } catch (error) {
    return error.message;
  }
};

const CheckRoleMappingExists = async (body) => {
  try {
    let pool = await mssql.GetCreateIfNotExistPool(config.sql);
    const sqlQueries = await utils.loadSqlQueries("mappings/UserRoleMapping");
    const event = await pool
      .request()
      .input("ID_User", sql.Int, body.ID_User)
      .input("ID_Role", sql.Int, body.ID_Role)
      .query(sqlQueries.CheckRoleMappingExists);
    return event.recordset;
  } catch (error) {
    return error.message;
  }
};

const InsertRoleMapping = async (body) => {
  try {
    let pool = await mssql.GetCreateIfNotExistPool(config.sql);
    const sqlQueries = await utils.loadSqlQueries("mappings/UserRoleMapping");
    const event = await pool
      .request()
      .input("ID_User", sql.Int, body.ID_User)
      .input("ID_Role", sql.Int, body.ID_Role)
      .input("CreatedBy", sql.VarChar, body.CreatedBy)
      .input("CreatedOn", sql.Date, body.CreatedOn)
      .query(sqlQueries.InsertRoleMapping);
    return event.rowsAffected[0];
  } catch (error) {
    return error.message;
  }
};

const revokeRoleMapping = async (body) => {
  try {
    let pool = await mssql.GetCreateIfNotExistPool(config.sql);
    const sqlQueries = await utils.loadSqlQueries("mappings/UserRoleMapping");
    const event = await pool
      .request()
      .input("ID_UserRoleMapping", sql.Int, body.ID_UserRoleMapping)
      .query(sqlQueries.revokeRoleMapping);
    return event.rowsAffected[0];
  } catch (error) {
    return error.message;
  }
};

module.exports = {
  UserRoleMappingList,
  InsertRoleMapping,
  CheckRoleMappingExists,
  revokeRoleMapping,
};
