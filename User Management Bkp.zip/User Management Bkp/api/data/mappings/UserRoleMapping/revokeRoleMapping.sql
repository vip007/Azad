DELETE dbo.UserRoleMapping
WHERE ID_UserRoleMapping=@ID_UserRoleMapping;
