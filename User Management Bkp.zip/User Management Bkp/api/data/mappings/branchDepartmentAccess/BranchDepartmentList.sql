  SELECT [dbo].[BranchDepartmentMapping].*,
  [dbo].[Department].Name as DeptName,
  [dbo].[Branch].Name as BranchName
  FROM [dbo].[BranchDepartmentMapping]
  inner join [dbo].[Department] on [dbo].[BranchDepartmentMapping].ID_Department = [dbo].[Department].[ID_Departmet]
  inner join [dbo].[Branch] on [dbo].[BranchDepartmentMapping].ID_SMCBranch = [dbo].[Branch].ID_Branch

  Order by [dbo].[Department].Name