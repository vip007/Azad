SELECT [ID_BranchDepartmentMapping]
      ,[ID_SMCBranch]
      ,[ID_Department]
      ,[IsActive]
      ,[CreatedBy]
      ,[CreatedOn]
      ,[ModifiedBy]
      ,[modifiedOn]
  FROM [dbo].[BranchDepartmentMapping]
  where ID_SMCBranch = @ID_SMCBranch 
  and ID_Department =  @ID_Department