INSERT INTO [dbo].[BranchDepartmentMapping]([ID_SMCBranch],[ID_Department],[IsActive],[CreatedBy],[CreatedOn])
VALUES (@ID_SMCBranch, @ID_Department, 1, @CreatedBy, @CreatedOn)