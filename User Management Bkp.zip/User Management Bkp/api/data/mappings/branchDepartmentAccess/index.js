"use strict";

const utils = require("../../utils");
const config = require("../../../config");
const sql = require("mssql");
let mssql = require("../../../mssql-connection-pooling");

const BranchDepartmentList = async () => {
  try {
    let pool = await mssql.GetCreateIfNotExistPool(config.sql);
    const sqlQueries = await utils.loadSqlQueries(
      "mappings/branchDepartmentAccess"
    );
    const event = await pool.request().query(sqlQueries.BranchDepartmentList);
    return event.recordset;
  } catch (error) {
    return error.message;
  }
};

const CheckIfBranchDepartmentExists = async (body) => {
  try {
    let pool = await mssql.GetCreateIfNotExistPool(config.sql);
    const sqlQueries = await utils.loadSqlQueries(
      "mappings/branchDepartmentAccess"
    );
    const event = await pool
      .request()
      .input("ID_SMCBranch", sql.Int, body.ID_SMCBranch)
      .input("ID_Department", sql.Int, body.ID_Department)
      .query(sqlQueries.CheckIfBranchDepartmentExists);
    return event.recordset;
  } catch (error) {
    return error.message;
  }
};

const grantNewBranchDepartment = async (body) => {
  try {
    let pool = await mssql.GetCreateIfNotExistPool(config.sql);
    const sqlQueries = await utils.loadSqlQueries(
      "mappings/branchDepartmentAccess"
    );
    const event = await pool
      .request()
      .input("ID_SMCBranch", sql.Int, body.ID_SMCBranch)
      .input("ID_Department", sql.Int, body.ID_Department)
      .input("CreatedBy", sql.VarChar, body.CreatedBy)
      .input("CreatedOn", sql.Date, body.CreatedOn)
      .query(sqlQueries.grantNewBranchDepartment);
    return event.rowsAffected[0];
  } catch (error) {
    return error.message;
  }
};

const revokeBranchDepartment = async (body) => {
  try {
    let pool = await mssql.GetCreateIfNotExistPool(config.sql);
    const sqlQueries = await utils.loadSqlQueries(
      "mappings/branchDepartmentAccess"
    );
    const event = await pool
      .request()
      .input(
        "ID_BranchDepartmentMapping",
        sql.Int,
        body.ID_BranchDepartmentMapping
      )
      .query(sqlQueries.revokeBranchDepartment);
    return event.rowsAffected[0];
  } catch (error) {
    return error.message;
  }
};

module.exports = {
  BranchDepartmentList,
  CheckIfBranchDepartmentExists,
  grantNewBranchDepartment,
  revokeBranchDepartment,
};
