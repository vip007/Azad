DELETE From [dbo].[BranchDepartmentMapping]
Where [BranchDepartmentMapping].[ID_BranchDepartmentMapping] = @ID_BranchDepartmentMapping