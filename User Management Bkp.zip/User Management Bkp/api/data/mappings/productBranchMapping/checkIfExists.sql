SELECT *
FROM ProductBranchMapping
WHERE ID_Branch = @ID_Branch and ID_Product = @ID_Product