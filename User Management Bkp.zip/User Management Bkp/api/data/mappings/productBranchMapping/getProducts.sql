Select distinct Product.ID_product, Product.ProductCode, Product.ProductName

from 
UserProductBranchMapping

INNER JOIN ProductBranchMapping on ProductBranchMapping.ID_ProductBranchMapping = UserProductBranchMapping.ID_ProductBranchMapping
INNER JOIN Product on Product.ID_Product = ProductBranchMapping.ID_Product

WHERE ID_User=@ID_User