INSERT INTO dbo.ProductBranchMapping
(ID_Product, ID_Branch, IsActive, CreatedBy, CreatedOn)
VALUES(@ID_Product, @ID_Branch, 1, @CreatedBy, @CreatedOn);
