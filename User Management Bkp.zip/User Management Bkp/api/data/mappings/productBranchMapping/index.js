"use strict";

const utils = require("../../utils");
const config = require("../../../config");
const sql = require("mssql");
let mssql = require("../../../mssql-connection-pooling");

const productBranchList = async () => {
  try {
    let pool = await mssql.GetCreateIfNotExistPool(config.sql);
    const sqlQueries = await utils.loadSqlQueries(
      "mappings/productBranchMapping"
    );
    const event = await pool.request().query(sqlQueries.productBranchList);
    return event.recordset;
  } catch (error) {
    return error.message;
  }
};

const revokeproductBranchMap = async (body) => {
  try {
    let pool = await mssql.GetCreateIfNotExistPool(config.sql);
    const sqlQueries = await utils.loadSqlQueries(
      "mappings/productBranchMapping"
    );
    const event = await pool
      .request()
      .input("ID_ProductBranchMapping", sql.Int, body.ID_ProductBranchMapping)
      .query(sqlQueries.revokeproductBranchMap);

    return event.rowsAffected[0];
  } catch (error) {
    return error.message;
  }
};

const grantproductBranchMap = async (body) => {
  try {
    let pool = await mssql.GetCreateIfNotExistPool(config.sql);
    const sqlQueries = await utils.loadSqlQueries(
      "mappings/productBranchMapping"
    );
    const event = await pool
      .request()
      .input("ID_Branch", sql.Int, body.ID_Branch)
      .input("ID_Product", sql.Int, body.ID_Product)
      .input("CreatedBy", sql.VarChar, body.CreatedBy)
      .input("CreatedOn", sql.Date, body.CreatedOn)
      .query(sqlQueries.grantproductBranchMap);
    return event.rowsAffected[0];
  } catch (error) {
    return error.message;
  }
};

const checkIfExists = async (body) => {
  try {
    let pool = await mssql.GetCreateIfNotExistPool(config.sql);
    const sqlQueries = await utils.loadSqlQueries(
      "mappings/productBranchMapping"
    );
    const event = await pool
      .request()
      .input("ID_Branch", sql.Int, body.ID_Branch)
      .input("ID_Product", sql.Int, body.ID_Product)
      .query(sqlQueries.checkIfExists);
    return event.recordset;
  } catch (error) {
    return error.message;
  }
};

const getProducts = async (body) => {
  try {
    let pool = await mssql.GetCreateIfNotExistPool(config.sql);
    const sqlQueries = await utils.loadSqlQueries(
      "mappings/productBranchMapping"
    );
    const event = await pool
      .request()
      .input("ID_User", sql.Int, body.ID_User)
      .query(sqlQueries.getProducts);
    return event.recordset;
  } catch (error) {
    return error.message;
  }
};

module.exports = {
  productBranchList,
  revokeproductBranchMap,
  grantproductBranchMap,
  getProducts,
  checkIfExists,
};
