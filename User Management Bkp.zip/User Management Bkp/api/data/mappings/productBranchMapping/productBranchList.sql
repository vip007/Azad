-- SELECT ID_ProductBranchMapping, ID_Product, ID_Branch, IsActive, CreatedBy, CreatedOn, ModifiedBy, ModifiedOn
-- FROM dbo.ProductBranchMapping;

SELECT [ProductBranchMapping].[ID_ProductBranchMapping]
      ,[Product].[ProductName]
      ,[Branch].[Name] as BranchName
      ,[ProductBranchMapping].[IsActive]
      ,[ProductBranchMapping].[CreatedBy]
      ,[ProductBranchMapping].[CreatedOn]
      ,[ProductBranchMapping].[ModifiedBy]
      ,[ProductBranchMapping].[ModifiedOn]
FROM [dbo].[ProductBranchMapping]
INNER JOIN [dbo].[Product] ON [dbo].[Product].[ID_Product] = [dbo].[ProductBranchMapping].[ID_Product]
INNER JOIN [dbo].[Branch] ON [dbo].[Branch].[ID_Branch] = [dbo].[ProductBranchMapping].[ID_Branch]

ORDER BY [Product].[ProductName],[Branch].[Name]