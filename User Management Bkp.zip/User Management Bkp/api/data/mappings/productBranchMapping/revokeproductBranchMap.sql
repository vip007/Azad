-- DELETE FROM dbo.ProductBranchMapping
-- WHERE ID_ProductBranchMapping=@ID_ProductBranchMapping;

UPDATE DEMOLOS_DB.dbo.ProductBranchMapping
SET IsActive=0
WHERE ID_ProductBranchMapping=@ID_ProductBranchMapping;
