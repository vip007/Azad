--Check if it exists
SELECT [UserAccess].*,
[User].[UserName],
[Menu].[MenuCode],
[MenuEvent].[MenuEventCode]
FROM [dbo].[UserAccess]
INNER JOIN [dbo].[User] ON [dbo].[User].[ID_User] = [dbo].[UserAccess].ID_User
INNER JOIN [dbo].[Menu] ON [dbo].[Menu].ID_Menu = [dbo].[UserAccess].[ID_Menu]
INNER JOIN [dbo].[MenuEvent] ON [dbo].[MenuEvent].[ID_MenuEvent] = [dbo].[UserAccess].[ID_MenuEvent]
WHERE [UserAccess].[ID_User] = @ID_User AND [UserAccess].[ID_Menu] =@ID_Menu AND [UserAccess].[ID_MenuEvent]=@ID_MenuEvent