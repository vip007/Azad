SELECT [UserAccess].[ID_UserAccessRights],
[User].[UserName],
[Menu].[MenuCode],
[MenuEvent].[MenuEventCode],
[Application].[ApplicationName],
[UserAccess].[CreatedBy],
[UserAccess].[CreatedOn]

FROM [dbo].[UserAccess]
INNER JOIN [dbo].[User] ON [dbo].[User].[ID_User] = [dbo].[UserAccess].ID_User
INNER JOIN [dbo].[Menu] ON [dbo].[Menu].ID_Menu = [dbo].[UserAccess].[ID_Menu]
INNER JOIN [dbo].[MenuEvent] ON [dbo].[MenuEvent].[ID_MenuEvent] = [dbo].[UserAccess].[ID_MenuEvent]
INNER JOIN [dbo].[Application] on [dbo].[Application].ID_Application = [dbo].[Menu].[ID_Application]

ORDER BY [User].[UserName],[Menu].[MenuCode],[MenuEvent].[MenuEventCode],[Application].[ApplicationName]