--Create 
INSERT INTO [dbo].[UserAccess]([ID_User],[ID_Menu],[ID_MenuEvent],[CreatedBy],[CreatedOn])
VALUES (@ID_User, @ID_Menu, @ID_MenuEvent, @CreatedBy, @CreatedOn)