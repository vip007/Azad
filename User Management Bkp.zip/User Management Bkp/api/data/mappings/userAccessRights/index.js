"use strict";

const utils = require("../../utils");
const config = require("../../../config");
const sql = require("mssql");
let mssql = require("../../../mssql-connection-pooling");

const UsersAccessRightsList = async () => {
  try {
    let pool = await mssql.GetCreateIfNotExistPool(config.sql);
    const sqlQueries = await utils.loadSqlQueries("mappings/userAccessRights");
    const event = await pool.request().query(sqlQueries.UsersAccessRightsList);
    return event.recordset;
  } catch (error) {
    return error.message;
  }
};

const CheckIfUsersAccessRightsExists = async (body) => {
  try {
    let pool = await mssql.GetCreateIfNotExistPool(config.sql);
    const sqlQueries = await utils.loadSqlQueries("mappings/userAccessRights");
    const event = await pool
      .request()
      .input("ID_User", sql.Int, body.ID_User)
      .input("ID_Menu", sql.Int, body.ID_Menu)
      .input("ID_MenuEvent", sql.Int, body.ID_MenuEvent)
      .query(sqlQueries.CheckIfUsersAccessRightsExists);
    return event.recordset;
  } catch (error) {
    return error.message;
  }
};

const grantNewUserAccessRight = async (body) => {
  try {
    let pool = await mssql.GetCreateIfNotExistPool(config.sql);
    const sqlQueries = await utils.loadSqlQueries("mappings/userAccessRights");
    const event = await pool
      .request()
      .input("ID_User", sql.Int, body.ID_User)
      .input("ID_Menu", sql.Int, body.ID_Menu)
      .input("ID_MenuEvent", sql.Int, body.ID_MenuEvent)
      .input("CreatedBy", sql.VarChar, body.CreatedBy)
      .input("CreatedOn", sql.Date, body.CreatedOn)
      .query(sqlQueries.grantNewUserAccessRight);
    return event.rowsAffected[0];
  } catch (error) {
    return error.message;
  }
};

const revokeUserAccessRight = async (body) => {
  try {
    let pool = await mssql.GetCreateIfNotExistPool(config.sql);
    const sqlQueries = await utils.loadSqlQueries("mappings/userAccessRights");
    const event = await pool
      .request()
      .input("ID_UserAccessRights", sql.Int, body.ID_UserAccessRights)
      .query(sqlQueries.revokeUserAccessRight);
    return event.rowsAffected[0];
  } catch (error) {
    return error.message;
  }
};

module.exports = {
  UsersAccessRightsList,
  CheckIfUsersAccessRightsExists,
  grantNewUserAccessRight,
  revokeUserAccessRight,
};
