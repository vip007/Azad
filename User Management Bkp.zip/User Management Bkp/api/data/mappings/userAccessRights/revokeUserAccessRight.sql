DELETE From [dbo].[UserAccess] 
Where [UserAccess].[ID_UserAccessRights] = @ID_UserAccessRights