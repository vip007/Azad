SELECT *
FROM [dbo].[UserBranchDepartment]
 where [ID_UserID] =@ID_UserID and [ID_BranchDepartmentMapping] = @ID_BranchDepartmentMapping