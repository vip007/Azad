SELECT  [dbo].[UserBranchDepartment].[ID_UserBranchDepartment],
  [dbo].[Branch].[Name] as BranchName,
  [dbo].[Department].[Name] as DeptName,
  [dbo].[User].UserName,
  [UserBranchDepartment].CreatedBy,[UserBranchDepartment].CreatedOn

  FROM [dbo].[UserBranchDepartment]
  inner join [dbo].[User] on [dbo].[User].[ID_User] = [dbo].[UserBranchDepartment].[ID_UserID]
  inner join [dbo].[BranchDepartmentMapping] on [dbo].[BranchDepartmentMapping].[ID_BranchDepartmentMapping] = 
  [dbo].[UserBranchDepartment].[ID_BranchDepartmentMapping]
  inner join [dbo].[Branch] on [dbo].[Branch].[ID_Branch] = [dbo].[BranchDepartmentMapping].ID_SMCBranch
  inner join [dbo].[Department] on [dbo].[Department].[ID_Departmet] = [dbo].[BranchDepartmentMapping].[ID_Department]