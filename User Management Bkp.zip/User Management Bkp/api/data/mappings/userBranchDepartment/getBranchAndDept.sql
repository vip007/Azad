SELECT [ID_BranchDepartmentMapping]
      ,[Branch].[Name] as BranchName
      ,[Department].[Name] as DeptName
	  ,[Location].[LocationName]
  FROM [BranchDepartmentMapping]
  inner join [dbo].[Branch] on [dbo].[Branch].[ID_Branch] = [dbo].[BranchDepartmentMapping].ID_SMCBranch
  inner join [dbo].[Department] on [dbo].[Department].[ID_Departmet] = [dbo].[BranchDepartmentMapping].[ID_Department]
  inner join [dbo].[Location] on [dbo].[Location].[ID_Location] = [dbo].[Branch].[ID_Location]