"use strict";

const utils = require("../../utils");
const config = require("../../../config");
const sql = require("mssql");
let mssql = require("../../../mssql-connection-pooling");

const branchDeptUserList = async () => {
  try {
    let pool = await mssql.GetCreateIfNotExistPool(config.sql);
    const sqlQueries = await utils.loadSqlQueries(
      "mappings/userBranchDepartment"
    );
    const event = await pool.request().query(sqlQueries.branchDeptUserList);
    return event.recordset;
  } catch (error) {
    return error.message;
  }
};

const CheckIfUserBranchDeptExists = async (body) => {
  try {
    let pool = await mssql.GetCreateIfNotExistPool(config.sql);
    const sqlQueries = await utils.loadSqlQueries(
      "mappings/userBranchDepartment"
    );
    const event = await pool
      .request()
      .input("ID_UserID", sql.Int, body.ID_UserID)
      .input(
        "ID_BranchDepartmentMapping",
        sql.Int,
        body.ID_BranchDepartmentMapping
      )
      .query(sqlQueries.CheckIfUserBranchDeptExists);
    return event.recordset;
  } catch (error) {
    return error.message;
  }
};

const mapNewUserBranchDept = async (body) => {
  try {
    let pool = await mssql.GetCreateIfNotExistPool(config.sql);
    const sqlQueries = await utils.loadSqlQueries(
      "mappings/userBranchDepartment"
    );
    const event = await pool
      .request()
      .input("ID_User", sql.Int, body.ID_User)
      .input(
        "ID_BranchDepartmentMapping",
        sql.Int,
        body.ID_BranchDepartmentMapping
      )
      .input("CreatedOn", sql.Date, body.CreatedOn)
      .input("CreatedBy", sql.VarChar, body.CreatedBy)
      .query(sqlQueries.mapNewUserBranchDept);
    return event.rowsAffected[0];
  } catch (error) {
    return error.message;
  }
};

const revokeNewUserBranchDept = async (body) => {
  try {
    let pool = await mssql.GetCreateIfNotExistPool(config.sql);
    const sqlQueries = await utils.loadSqlQueries(
      "mappings/userBranchDepartment"
    );
    const event = await pool
      .request()
      .input("ID_UserBranchDepartment", sql.Int, body.ID_UserBranchDepartment)
      .query(sqlQueries.revokeNewUserBranchDept);
    return event.rowsAffected[0];
  } catch (error) {
    return error.message;
  }
};

const getBranchAndDept = async () => {
  try {
    let pool = await mssql.GetCreateIfNotExistPool(config.sql);
    const sqlQueries = await utils.loadSqlQueries(
      "mappings/userBranchDepartment"
    );
    const event = await pool.request().query(sqlQueries.getBranchAndDept);
    return event.recordset;
  } catch (error) {
    return error.message;
  }
};

module.exports = {
  branchDeptUserList,
  mapNewUserBranchDept,
  revokeNewUserBranchDept,
  CheckIfUserBranchDeptExists,
  getBranchAndDept,
};
