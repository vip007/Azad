INSERT INTO [dbo].[UserBranchDepartment] ([ID_UserID],[ID_BranchDepartmentMapping],[IsActive],[CreatedOn],[CreatedBy])
VALUES (@ID_User,@ID_BranchDepartmentMapping,1,@CreatedOn,@CreatedBy)