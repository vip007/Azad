DELETE FROM [dbo].[UserBranchDepartment] 
WHERE
[ID_UserBranchDepartment] = @ID_UserBranchDepartment