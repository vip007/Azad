SELECT *
FROM UserProductBranchMapping
WHERE ID_User = @ID_User AND ID_ProductBranchMapping = @ID_ProductBranchMapping