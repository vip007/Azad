SELECT [ID_ProductBranchMapping]
      ,[Product].[ProductName]
      ,[Branch].[Name] as BranchName
      ,[ProductBranchMapping].[IsActive]
  FROM [dbo].[ProductBranchMapping]
  INNER JOIN [dbo].[Product] on [dbo].[Product].[ID_Product] = [dbo].[ProductBranchMapping].[ID_Product]
   INNER JOIN [dbo].[Branch] on [dbo].[Branch].[ID_Branch] = [dbo].[ProductBranchMapping].[ID_Branch]