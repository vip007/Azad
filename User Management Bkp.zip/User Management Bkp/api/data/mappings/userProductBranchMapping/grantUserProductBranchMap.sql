INSERT INTO [dbo].[UserProductBranchMapping]
(ID_User, ID_ProductBranchMapping, IsActive, CreatedBy, CreatedOn )
VALUES(@ID_User, @ID_ProductBranchMapping, 1, @CreatedBy, @CreatedOn);