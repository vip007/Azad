"use strict";

const utils = require("../../utils");
const config = require("../../../config");
const sql = require("mssql");
let mssql = require("../../../mssql-connection-pooling");

const userProductBranchList = async () => {
  try {
    let pool = await mssql.GetCreateIfNotExistPool(config.sql);
    const sqlQueries = await utils.loadSqlQueries(
      "mappings/userProductBranchMapping"
    );
    const event = await pool.request().query(sqlQueries.userProductBranchList);
    return event.recordset;
  } catch (error) {
    return error.message;
  }
};

const ProductBranchID = async () => {
  try {
    let pool = await mssql.GetCreateIfNotExistPool(config.sql);
    const sqlQueries = await utils.loadSqlQueries(
      "mappings/userProductBranchMapping"
    );
    const event = await pool.request().query(sqlQueries.ProductBranchID);
    return event.recordset;
  } catch (error) {
    return error.message;
  }
};

const grantUserProductBranchMap = async (body) => {
  try {
    let pool = await mssql.GetCreateIfNotExistPool(config.sql);
    const sqlQueries = await utils.loadSqlQueries(
      "mappings/userProductBranchMapping"
    );
    const event = await pool
      .request()
      .input("ID_User", sql.Int, body.ID_User)
      .input("ID_ProductBranchMapping", sql.Int, body.ID_ProductBranchMapping)
      .input("CreatedBy", sql.VarChar, body.CreatedBy)
      .input("CreatedOn", sql.Date, body.CreatedOn)
      .query(sqlQueries.grantUserProductBranchMap);
    console.dir("Event: Grant Access", event);
    return event.rowsAffected[0];
  } catch (error) {
    return error.message;
  }
};

const CheckIfExists = async (body) => {
  try {
    let pool = await mssql.GetCreateIfNotExistPool(config.sql);
    const sqlQueries = await utils.loadSqlQueries(
      "mappings/userProductBranchMapping"
    );
    const event = await pool
      .request()
      .input("ID_User", sql.Int, body.ID_User)
      .input("ID_ProductBranchMapping", sql.Int, body.ID_ProductBranchMapping)
      .query(sqlQueries.CheckIfExists);
    return event.recordset;
  } catch (error) {
    return error.message;
  }
};

const revokeUserProductBranchMap = async (body) => {
  try {
    let pool = await mssql.GetCreateIfNotExistPool(config.sql);
    const sqlQueries = await utils.loadSqlQueries(
      "mappings/userProductBranchMapping"
    );
    const event = await pool
      .request()
      .input(
        "ID_UserProductBranchMapping",
        sql.Int,
        body.ID_UserProductBranchMapping
      )
      .query(sqlQueries.revokeUserProductBranchMap);
    return event.rowsAffected[0];
  } catch (error) {
    return error.message;
  }
};

module.exports = {
  userProductBranchList,
  revokeUserProductBranchMap,
  grantUserProductBranchMap,
  ProductBranchID,
  CheckIfExists,
};
