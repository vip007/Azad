DELETE FROM dbo.UserProductBranchMapping
WHERE [ID_UserProductBranchMapping] = @ID_UserProductBranchMapping;
