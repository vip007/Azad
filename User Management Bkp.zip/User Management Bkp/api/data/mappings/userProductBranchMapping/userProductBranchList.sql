SELECT [UserProductBranchMapping].[ID_UserProductBranchMapping]
      ,[User].[UserName]
	  ,[Branch].[Name] as BranchName
	  ,[Product].ProductName
      ,[UserProductBranchMapping].[IsActive]
      ,[UserProductBranchMapping].[CreatedBy]
      ,[UserProductBranchMapping].[CreatedOn]
      ,[UserProductBranchMapping].[ModifiedBy]
      ,[UserProductBranchMapping].[ModifiedOn]
FROM [dbo].[UserProductBranchMapping]
INNER JOIN [dbo].[User] ON [dbo].[User].[ID_User] = [dbo].[UserProductBranchMapping].[ID_User]
INNER JOIN [dbo].[ProductBranchMapping] ON [dbo].[ProductBranchMapping].[ID_ProductBranchMapping] = [dbo].[UserProductBranchMapping].[ID_ProductBranchMapping]
INNER JOIN [dbo].[Product] ON [dbo].[Product].[ID_Product] = [dbo].[ProductBranchMapping].[ID_Product]
INNER JOIN [dbo].[Branch] ON [dbo].[Branch].[ID_Branch] = [dbo].[ProductBranchMapping].[ID_Branch]

ORDER BY [dbo].[User].[UserName], [Branch].[Name]