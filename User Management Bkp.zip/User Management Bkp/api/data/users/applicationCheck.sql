Select * from
[dbo].[UserAccess] 
INNER JOIN [dbo].[Menu] ON  [dbo].[Menu].[ID_Menu] = [dbo].[UserAccess].[ID_Menu]
WHERE [UserAccess].[ID_User] = @ID_User 