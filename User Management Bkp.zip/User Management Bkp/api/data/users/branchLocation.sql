-- select Distinct [UserBranchDepartmentMapping].[ID_Branch],
-- [Branch].[Name],
-- [Location].[IsActive],[Location].[LocationName]
-- from
-- [dbo].[UserBranchDepartmentMapping] 
-- INNER JOIN [dbo].[Branch] ON [dbo].[Branch].[ID_Branch] = [dbo].[UserBranchDepartmentMapping].[ID_Branch]
-- INNER JOIN [dbo].[Location] ON [dbo].[Location].[ID_Location] = [dbo].[Branch].[ID_Location]

-- where 

-- [UserBranchDepartmentMapping].[ID_User] = @ID_User and [Location].[IsActive] = 1


select Distinct 
[Branch].[ID_Branch],[Branch].[Name], 
[Location].[IsActive],
[Location].[LocationName]


From [UserProductBranchMapping]

INNER JOIN [ProductBranchMapping] ON [ProductBranchMapping].[ID_ProductBranchMapping] = [UserProductBranchMapping].[ID_ProductBranchMapping]
INNER JOIN [Branch] ON [Branch].[ID_Branch] = [ProductBranchMapping].[ID_Branch]
INNER JOIN [Location] ON [Location].[ID_Location] = [Branch].[ID_Location]

WHERE [ID_User] = @ID_User AND [Location].[IsActive] = 1