"use strict";
const utils = require("../utils");
const config = require("../../config");
const sql = require("mssql");
let mssql = require("../../mssql-connection-pooling");

const getUserDetails = async (body) => {
  try {
    //config.sql.database = "UATMoneyWiseFin"
    let pool = await mssql.GetCreateIfNotExistPool(config.sql);
    const sqlQueries = await utils.loadSqlQueries("users");
    const event = await pool
      .request()
      .input("userName", sql.VarChar, body.username)
      .input("password", sql.VarChar, body.password)
      .query(sqlQueries.userDetail);
    return event.recordset;
  } catch (error) {
    return error.message;
  }
};

const getUserMacAddress = async (body) => {
  try {
    //config.sql.database = "UATMoneyWiseFin";
    let pool = await mssql.GetCreateIfNotExistPool(config.sql);
    const sqlQueries = await utils.loadSqlQueries("users");
    const event = await pool
      .request()
      .input("userId", sql.Int, body.userId)
      .input("macAddress", sql.NVarChar, body.macAddress)
      .query(sqlQueries.macAddressDetail);
    return event.recordset;
  } catch (error) {
    return error.message;
    // return 0;
  }
};

const getUserRightAccess = async (ID_User) => {
  try {
    let pool = await mssql.GetCreateIfNotExistPool(config.sql);
    const sqlQueries = await utils.loadSqlQueries("users");
    const event = await pool
      .request()
      .input("ID_User", sql.Int, ID_User)
      //.input("Application", sql.VarChar, Application)
      .query(sqlQueries.userRightAccess);
    return event.recordset;
  } catch (error) {
    return error.message;
    // return 0;
  }
};

const getLoanProduct = async (body) => {
  try {
    let pool = await mssql.GetCreateIfNotExistPool(config.sql);
    const sqlQueries = await utils.loadSqlQueries("users");
    const event = await pool
      .request()
      .input("ID_Branch", sql.Int, body.ID_Branch)
      .query(sqlQueries.loanProduct);

    return event.recordset;
  } catch (error) {
    return error.message;
  }
};

const getBranchMappingStatus = async (ID_User) => {
  try {
    let pool = await mssql.GetCreateIfNotExistPool(config.sql);
    const sqlQueries = await utils.loadSqlQueries("users");
    const event = await pool
      .request()
      .input("ID_User", sql.Int, ID_User)
      .query(sqlQueries.branchLocation);
    return event.recordset;
  } catch (error) {}
};

const checkUserHasApplicationsAccess = async (ID_User) => {
  try {
    let pool = await mssql.GetCreateIfNotExistPool(config.sql);
    const sqlQueries = await utils.loadSqlQueries("users");
    const event = await pool
      .request()
      .input("ID_User", sql.Int, ID_User)
      .query(sqlQueries.applicationCheck);
    return event.recordset;
  } catch (error) {}
};

module.exports = {
  getUserDetails,
  getUserMacAddress,
  getUserRightAccess,
  getLoanProduct,
  getBranchMappingStatus,
  checkUserHasApplicationsAccess,
};
