-- Select [UserBranchDepartmentMapping].[ID_User],
-- [Product].[ID_Product],[Product].[ProductCode],[Product].[ProductName]
-- FROM [dbo].[UserBranchDepartmentMapping] 
-- INNER JOIN [dbo].[Product] on [dbo].[Product].[ID_Product] = [dbo].[UserBranchDepartmentMapping].[ID_Product]
-- Where [dbo].[UserBranchDepartmentMapping].[ID_User]= @ID_User


select
[Product].[ID_Product],[Product].[ProductCode],[Product].[ProductName]

from [ProductBranchMapping]
INNER JOIN [Product] ON [Product].ID_Product = [ProductBranchMapping].[ID_Product]

WHERE [ID_Branch] = @ID_Branch