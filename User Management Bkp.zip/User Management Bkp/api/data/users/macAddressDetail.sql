
SELECT * 
FROM UserMacAddress 
WHERE UserId = @userId 
AND MacAddress = @macAddress