SELECT *
FROM [dbo].[User]
WHERE [UserName]=@userName AND [UserPass]=@password And [IsActive]=1