-- select [User].[UserName],[User].[ID_UserType],[User].[Code],
-- [Menu].[MenuName],[Menu].[ID_Menu_Parent],[Menu].[ID_Application],
-- [MenuEvent].[ID_MenuEvent],[MenuEvent].[MenuEventName],[MenuEvent].[MenuEventCode],[MenuEvent].[ID_Menu],
-- [Application].[ApplicationCode],[Application].[ID_Application],[Application].[IsActive],
-- [Product].[ProductCode]
-- FROM 
-- [dbo].[UserAccess] INNER JOIN [dbo].[User] ON [dbo].[UserAccess].[ID_User] = [dbo].[User].[ID_User]
-- INNER JOIN [dbo].[Menu] ON [dbo].[UserAccess].[ID_Menu] = [dbo].[Menu].[ID_Menu]
-- INNER JOIN [dbo].[MenuEvent] ON [dbo].[UserAccess].[ID_MenuEvent] = [dbo].[MenuEvent].[ID_MenuEvent]
-- INNER JOIN [dbo].[Application] ON [dbo].[Menu].[ID_Application] = [dbo].[Application].[ID_Application]
-- INNER JOIN [dbo].[Product] ON [dbo].[Product].[ID_Application] = [dbo].[Application].[ID_Application]
-- Where [dbo].[User].[ID_User]=@ID_User AND [dbo].[Application].[ApplicationCode] = 'LOS' AND [dbo].[Application].[IsActive] = 1 


-- select [User].[UserName],[User].[ID_UserType],[User].[Code],
-- [Menu].[MenuCode],[Menu].[MenuCode],[Menu].[MenuName],[Menu].[ID_Menu_Parent],[Menu].[ID_Application],
-- [MenuEvent].[ID_MenuEvent],[MenuEvent].[MenuEventName],[MenuEvent].[MenuEventCode],[MenuEvent].[ID_Menu]
-- FROM 
-- [dbo].[UserAccess] INNER JOIN [dbo].[User] ON [dbo].[UserAccess].[ID_User] = [dbo].[User].[ID_User]
-- INNER JOIN [dbo].[Menu] ON [dbo].[UserAccess].[ID_Menu] = [dbo].[Menu].[ID_Menu]
-- INNER JOIN [dbo].[MenuEvent] ON [dbo].[UserAccess].[ID_MenuEvent] = [dbo].[MenuEvent].[ID_MenuEvent]
-- Where [dbo].[User].[ID_User]= @ID_User

-- select [User].[UserName],[User].[ID_UserType],[User].[Code],
-- [Menu].[MenuName],[Menu].[ID_Menu_Parent],[Menu].[ID_Application],
-- [MenuEvent].[ID_MenuEvent],[MenuEvent].[MenuEventName],[MenuEvent].[MenuEventCode],[MenuEvent].[ID_Menu]
-- FROM 
-- [dbo].[UserAccess] INNER JOIN [dbo].[User] ON [dbo].[UserAccess].[ID_User] = [dbo].[User].[ID_User]
-- INNER JOIN [dbo].[Menu] ON [dbo].[UserAccess].[ID_Menu] = [dbo].[Menu].[ID_Menu]
-- INNER JOIN [dbo].[MenuEvent] ON [dbo].[UserAccess].[ID_MenuEvent] = [dbo].[MenuEvent].[ID_MenuEvent]
-- Where [dbo].[User].[ID_User]=@ID_User


-- select [User].[ID_User],[User].[UserName],[User].[ID_UserType],[User].[Code],
-- [Menu].[MenuName],[Menu].[ID_Menu_Parent],[Menu].[ID_Application],
-- [MenuEvent].[ID_MenuEvent],[MenuEvent].[MenuEventName],[MenuEvent].[MenuEventCode],[MenuEvent].[ID_Menu],
-- [Application].[ApplicationCode],[Application].[IsActive]
-- FROM 
-- [dbo].[UserAccess] INNER JOIN [dbo].[User] ON [dbo].[UserAccess].[ID_User] = [dbo].[User].[ID_User]
-- INNER JOIN [dbo].[Menu] ON [dbo].[UserAccess].[ID_Menu] = [dbo].[Menu].[ID_Menu]
-- INNER JOIN [dbo].[MenuEvent] ON [dbo].[UserAccess].[ID_MenuEvent] = [dbo].[MenuEvent].[ID_MenuEvent]
-- INNER JOIN [dbo].[Application] ON [dbo].[Menu].[ID_Application] = [dbo].[Application].[ID_Application]
-- Where [dbo].[User].[ID_User]=@ID_User AND [dbo].[Application].[ApplicationCode] = 'LOS' AND [dbo].[Application].[IsActive] = 1

select [User].[ID_User],[User].[UserName],[User].[ID_UserType],[User].[Code],
[Menu].[MenuName],[Menu].[ID_Menu_Parent],[Menu].[ID_Application],
[MenuEvent].[ID_MenuEvent],[MenuEvent].[MenuEventName],[MenuEvent].[MenuEventCode],[MenuEvent].[ID_Menu],
[Application].[ApplicationCode],[Application].[IsActive]
FROM 
[dbo].[UserAccess] INNER JOIN [dbo].[User] ON [dbo].[UserAccess].[ID_User] = [dbo].[User].[ID_User]
INNER JOIN [dbo].[Menu] ON [dbo].[UserAccess].[ID_Menu] = [dbo].[Menu].[ID_Menu]
INNER JOIN [dbo].[MenuEvent] ON [dbo].[UserAccess].[ID_MenuEvent] = [dbo].[MenuEvent].[ID_MenuEvent]
INNER JOIN [dbo].[Application] ON [dbo].[Menu].[ID_Application] = [dbo].[Application].[ID_Application]
Where [dbo].[User].[ID_User]=@ID_User AND [dbo].[Application].[IsActive] = 1