"use strict";
const express = require("express");
const logger = require("morgan");
const path = require("path");
const config = require("./config");
//const config1 = require('./config1');
const cors = require("cors");
const bodyParser = require("body-parser");
const jwt = require("jsonwebtoken");

const app = express();
const helmet = require("helmet");

app.use(express.json());
//app.use(bodyParser.json());
app.use(logger("dev"));
app.use(helmet());

//app.use(express.static(path.join(__dirname,'public')))
//app.get('*',(req,res)=>{
//	res.sendFile(path.join(__dirname,'public')+ '/index.html');
//})

app.use((req, res, next) => {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Credentials", true);
  res.setHeader(
    "Access-Control-Allow-Methods",
    "GET, POST, PUT, OPTIONS, PATCH, DELETE"
  );
  res.setHeader(
    "Access-Control-Allow-Headers",
    "Origin, X-Requested-With, Content-type, Authorization, x-access-token, Accept, XMLHttpRequest"
  );
  if (req.method === "OPTIONS") {
    res.status(200).end();
  } else {
    next();
  }
});

app.use(cors());

require("./routes/user")(app);

require("./routes/admin-masters/usertype")(app);
require("./routes/admin-masters/admin")(app);
require("./routes/admin-masters/application")(app);
require("./routes/admin-masters/location")(app);
require("./routes/admin-masters/role")(app);
require("./routes/admin-masters/branch")(app);
require("./routes/admin-masters/department")(app);
require("./routes/admin-masters/menu")(app);
require("./routes/admin-masters/product")(app);
require("./routes/admin-masters/menuevent")(app);

require("./routes/mappings/userAccessRights")(app);
require("./routes/mappings/userBranchDepartment")(app);
require("./routes/mappings/branchDepartmentAccess")(app);
require("./routes/mappings/userRoleMapping")(app);
require("./routes/mappings/ProductBranchMapping")(app);
require("./routes/mappings/userProductBranchMapping")(app);

const port = config.port || 9090;
app.listen(port, () => {
  console.log("app listening on url http://localhost:" + port);
});
