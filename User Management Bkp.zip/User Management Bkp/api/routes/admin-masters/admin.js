"use strict";
const adminController = require("../../controllers/admin-masters/adminController");
const jwt = require("../../shared/jwtAuth");

module.exports = (app) => {
  const url = "/api/admin/users/";

  // users crud Routes  ****************************************************************
  app.get(`${url}`, adminController.UsersList);
  app.post(`${url}id`, adminController.UsersWithID);
  app.post(`${url}toggle-state`, adminController.toggleUserState);
  app.post(`${url}create`, adminController.createUser);
  app.post(`${url}modify`, adminController.modifyUser);
  app.post(`${url}search`, adminController.searchUserLike);

  // @Helper Functions
  app.get(`${url}usertypes`, adminController.getUserTypes);
};
