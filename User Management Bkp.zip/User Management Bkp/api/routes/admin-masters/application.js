"use strict";
const applicationController = require("../../controllers/admin-masters/applicationController");

module.exports = (app) => {
  const url = "/api/admin/application/";
  app.get(`${url}`, applicationController.getApplicationList);
  app.get(`${url}:id`, applicationController.getApplicationWithID);
  app.post(`${url}create`, applicationController.createNewApplication);
  app.post(`${url}deactivate`, applicationController.toggleAppState);
  app.post(`${url}modify`, applicationController.modifyApplication);
};
