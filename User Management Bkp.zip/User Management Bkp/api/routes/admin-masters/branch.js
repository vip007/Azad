"use strict";
const branchController = require("../../controllers/admin-masters/branchController");

module.exports = (app) => {
  const url = "/api/admin/branch/";
  app.get(`${url}`, branchController.getBranchList);
  app.get(`${url}:id`, branchController.getBranchWithID);
  app.post(`${url}create`, branchController.createNewBranch);
  app.post(`${url}modify`, branchController.modifyBranch);
};
