"use strict";
const departmentController = require("../../controllers/admin-masters/departmentController");

module.exports = (app) => {
  const url = "/api/admin/department/";
  app.get(`${url}`, departmentController.getDepartmentList);
  app.get(`${url}:id`, departmentController.getDepartmentWithID);
  app.post(`${url}create`, departmentController.createNewDepartment);
  app.post(`${url}toggle-state`, departmentController.toggleDepartmentState);
  app.post(`${url}modify`, departmentController.modifyDepartment);
};
