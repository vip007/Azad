"use strict";
const locationController = require("../../controllers/admin-masters/locationController");

module.exports = (app) => {
  const url = "/api/admin/location/";
  app.get(`${url}`, locationController.getLocationList);
  app.get(`${url}:id`, locationController.getLocationWithID);
  app.post(`${url}create`, locationController.createNewLocation);
  app.post(`${url}toggle-state`, locationController.toggleLocationState);
  app.post(`${url}modify`, locationController.modifyLocation);
};
