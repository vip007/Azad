"use strict";
const menuController = require("../../controllers/admin-masters/menuController");

module.exports = (app) => {
  const url = "/api/admin/menu/";
  app.get(`${url}`, menuController.getMenuList);
  app.get(`${url}:id`, menuController.getMenuWithID);
  app.post(`${url}create`, menuController.createNewMenu);
  app.post(`${url}toggle-state`, menuController.toggleMenuState);
  app.post(`${url}modify`, menuController.modifyMenu);
};
