"use strict";
const menueventController = require("../../controllers/admin-masters/menueventController");

module.exports = (app) => {
  const url = "/api/admin/menuevent/";
  // console.log("Menu Vent");
  app.get(`${url}`, menueventController.MenuEventList);
  app.post(`${url}id`, menueventController.MenuEventWithID);
  app.post(`${url}create`, menueventController.createNewMenuEvent);
  app.post(`${url}delete`, menueventController.MenuEventRemove);
  app.post(`${url}modify`, menueventController.modifyMenuEvent);
};
