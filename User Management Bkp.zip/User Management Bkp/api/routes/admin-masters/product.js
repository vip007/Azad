"use strict";
const productController = require("../../controllers/admin-masters/productController");

module.exports = (app) => {
  const url = "/api/admin/product/";
  app.get(`${url}`, productController.ProductList);
  app.get(`${url}:id`, productController.ProductWithID);
  app.post(`${url}create`, productController.createNewProduct);
  app.post(`${url}toggle-state`, productController.ProductState);
  app.post(`${url}modify`, productController.modifyProduct);
};
