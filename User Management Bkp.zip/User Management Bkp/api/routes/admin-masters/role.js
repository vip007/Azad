"use strict";
const roleController = require("../../controllers/admin-masters/roleController");

module.exports = (app) => {
  const url = "/api/admin/role/";
  app.get(`${url}`, roleController.getRoleList);
  app.get(`${url}:id`, roleController.getRoleWithID);
  app.post(`${url}create`, roleController.createNewRole);
  app.post(`${url}toggle-state`, roleController.toggleRoleState);
  app.post(`${url}modify`, roleController.modifyRole);
};
