"use strict";
const usertypeController = require("../../controllers/admin-masters/usertypeController");
const jwt = require("../../shared/jwtAuth");

module.exports = (app) => {
  const url = "/api/admin/userstype/";
  app.get(`${url}`, usertypeController.getUsersTypeList);
  app.get(`${url}:id`, usertypeController.getUsersTypeWithID);
  app.post(`${url}toggle-state`, usertypeController.deactivateUserType);
  app.post(`${url}create`, usertypeController.createUserType);
  app.post(`${url}modify`, usertypeController.modifyUserType);
};
