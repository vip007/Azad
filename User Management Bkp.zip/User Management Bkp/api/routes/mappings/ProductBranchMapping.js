"use strict";

// ProductBranchMapping

const productBranchMappingController= require("../../controllers/mappings/productBranchMappingController");

module.exports = (app) => {
  const url = "/api/admin/mappings/product-branch-mapping/";
  app.get(`${url}`, productBranchMappingController.productBranchList);
  app.post(`${url}grant`, productBranchMappingController.grantproductBranchMap);
  app.post(`${url}revoke`, productBranchMappingController.revokeproductBranchMap);
  app.post(`${url}get-products`, productBranchMappingController.getProducts);

};