"use strict";

const branchDepartmentAccessController = require("../../controllers/mappings/branchDepartmentAccessController");

module.exports = (app) => {

  const url = "/api/admin/mappings/branch-department-access/";
  

  app.get(`${url}`, branchDepartmentAccessController.BranchDepartmentList);
  app.post(`${url}grant`, branchDepartmentAccessController.grantNewBranchDepartment); 
  app.post(`${url}revoke`, branchDepartmentAccessController.revokeBranchDepartment);

};
