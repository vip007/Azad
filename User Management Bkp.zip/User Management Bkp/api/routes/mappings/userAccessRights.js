"use strict";

const userAccessRightsContoller = require("../../controllers/mappings/userAccessRightsController");

module.exports = (app) => {
  const url = "/api/admin/mappings/user-access-rights/";
  app.get(`${url}`, userAccessRightsContoller.UsersAccessRightsList);
  //   app.get(`${url}:id`, applicationController.getApplicationWithID);
  app.post(`${url}grant`, userAccessRightsContoller.grantNewUserAccessRight);
  app.post(`${url}revoke`, userAccessRightsContoller.revokeUserAccessRight);
};
