"use strict";

const userBranchDepartmentController = require("../../controllers/mappings/userBranchDepartmentController");

module.exports = (app) => {
  const url = "/api/admin/mappings/user-branch-department/";
  app.get(`${url}`, userBranchDepartmentController.branchDeptUserList);
  app.post(`${url}grant`, userBranchDepartmentController.mapNewUserBranchDept);
  app.post(`${url}revoke`,userBranchDepartmentController.revokeNewUserBranchDept);
  app.get(`${url}branch-dept`,userBranchDepartmentController.getBranchAndDept);
};