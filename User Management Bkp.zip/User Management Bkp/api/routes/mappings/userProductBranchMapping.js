"use strict";

// userProductBranchMapping

const userProductBranchMappingController= require("../../controllers/mappings/userProductBranchMappingController");

module.exports = (app) => {
  const url = "/api/admin/mappings/user-product-branch/";
  app.get(`${url}`, userProductBranchMappingController.userProductBranchList);
  app.post(`${url}grant`, userProductBranchMappingController.grantUserProductBranchMap);
  app.get(`${url}get-product-branch-id`, userProductBranchMappingController.ProductBranchID);

  app.post(`${url}revoke`, userProductBranchMappingController.revokeUserProductBranchMap);
};

