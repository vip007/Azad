"use strict";

const userRoleController = require("../../controllers/mappings/userRoleMappingController");

module.exports = (app) => {
  const url = "/api/admin/mappings/user-role-mapping/";
  app.get(`${url}`, userRoleController.UserRoleMappingList);
  app.post(`${url}grant`, userRoleController.InsertRoleMapping);
  app.post(`${url}revoke`, userRoleController.revokeRoleMapping);
};
