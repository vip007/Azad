"use strict";
const userController = require("../controllers/userController");

module.exports = (app) => {
  const url = "/api/user/";
  app.post(`${url}signin`, userController.signInUser);
  app.post(`${url}loan-products`, userController.loanProduct);
};
