'use strict'

const bcrypt = require('bcrypt-nodejs');

module.exports = (password) => {
    return new Promise((resolve,reject)=>{
        bcrypt.genSalt(100,(err,salt)=>{
            if(err){
                reject(err);
            }
            bcrypt.hash(password,salt,null,(err,hash)=>{
                if(err){
                    reject(err);
                }else{
                    resolve(hash);
                }
            })
        })
    })
}