"use strict";

const jwt = require("jsonwebtoken");

function generateAccessToken(user) {
  return jwt.sign(user, process.env.ACCESS_TOKEN_PRIKEY, {
    algorithm: "RS256",
    expiresIn: "5m",
  });
}

function authenticateToken(req, res, next) {
  const authHeader = req.headers["authorization"];
  const token = authHeader && authHeader.split(" ")[1];

  const options = {
    expiresIn: "15m",
  };

  if (token == null) return res.sendStatus(401);
  jwt.verify(token, process.env.ACCESS_TOKEN_PUBKEY, (err, decodedToken) => {
    if (err) {
      console.log(decodedToken);
      return res.sendStatus(403);
    } else {
      //req.user = user;
      console.log(decodedToken);
      next();
    }
  });
}

module.exports = {
  generateAccessToken,
  authenticateToken,
};
