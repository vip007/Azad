import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AdminLayoutComponent } from './layout/admin-layout/admin-layout.component';
import { ErrorPageComponent } from './shared/error-page/error-page.component';
import { UsersLayoutComponent } from './layout/users-layout/users-layout.component';
import { LoginComponent } from './shared/login/login.component';

import { AuthGuard } from './services/guards/auth.guard';
import { MisLayoutComponent } from './layout/mis-layout/mis-layout.component';

const routes: Routes = [
  { path: '', redirectTo: '/admin/dashboard/master/usertype', pathMatch: 'full' },
  { path: 'error', component: ErrorPageComponent },
  { path: 'login', component: LoginComponent },
  {
    path: 'user',
    canActivate: [AuthGuard],
    component: UsersLayoutComponent,
    children: [
      {
        path: '',
        loadChildren: () =>
          import('./pages/pages.module').then((m) => m.PagesModule),
      },
    ],
  },
  {
    path: 'admin',
    canActivate: [AuthGuard],
    component: AdminLayoutComponent,
    children: [
      {
        path: '',
        loadChildren: () =>
          import('./pages/pages.module').then((m) => m.PagesModule),
      },
    ],
  },
  {
    path: 'user/mis',
    canActivate: [AuthGuard],
    component: MisLayoutComponent
  },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule { }
