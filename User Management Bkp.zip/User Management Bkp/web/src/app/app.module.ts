import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { SidebarModule } from 'ng-sidebar';
import { NgxSpinnerModule } from 'ngx-spinner';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ReactiveFormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { ToastrModule } from 'ngx-toastr';

import { AppComponent } from './app.component';

import { HeaderComponent } from './core/users/header/header.component';
import { SidebarComponent } from './core/users/sidebar/sidebar.component';
import { FooterComponent } from './core/users/footer/footer.component';

import { AdminLayoutComponent } from './layout/admin-layout/admin-layout.component';
import { ErrorPageComponent } from './shared/error-page/error-page.component';
import { LoginComponent } from './shared/login/login.component';
import { UsersLayoutComponent } from './layout/users-layout/users-layout.component';
import { AdminSidebarComponent } from './core/admin/admin-sidebar/admin-sidebar.component';
import { AdminHeaderComponent } from './core/admin/admin-header/admin-header.component';
import { UsersService } from './services/admin/table-masters/users.service';

import { NgxPaginationModule } from 'ngx-pagination';
import { AngularMultiSelectModule } from 'angular2-multiselect-dropdown';
import { MisLayoutComponent } from './layout/mis-layout/mis-layout.component';
import { AppInterceptorService } from './services/app-interceptor.service';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    SidebarComponent,
    FooterComponent,
    AdminLayoutComponent,
    ErrorPageComponent,
    LoginComponent,
    UsersLayoutComponent,
    AdminSidebarComponent,
    AdminHeaderComponent,
    MisLayoutComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    SidebarModule.forRoot(),
    HttpClientModule,
    NgxSpinnerModule,
    NgxPaginationModule,
    BrowserAnimationsModule,
    AngularMultiSelectModule,
    ReactiveFormsModule,
    ToastrModule.forRoot({
      timeOut: 3000,
      preventDuplicates: true,
    }),
  ],
  providers: [
    {
      provide: HTTP_INTERCEPTORS,
      useClass: AppInterceptorService,
      multi: true,
    }
  ],
  bootstrap: [AppComponent],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
})
export class AppModule { }
