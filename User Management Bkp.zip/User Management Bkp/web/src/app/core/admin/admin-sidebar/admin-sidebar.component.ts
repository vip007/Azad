import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-sidebar',
  templateUrl: './admin-sidebar.component.html',
  styleUrls: ['./admin-sidebar.component.css']
})
export class AdminSidebarComponent implements OnInit {

  currentUser: any;
  menuitems: any;

  constructor() { }

  ngOnInit(): void {
    this.menuitems = localStorage.getItem('currentUser')
    this.menuitems = JSON.parse(this.menuitems)

    this.currentUser = this.menuitems[0].UserName;

  }

}
