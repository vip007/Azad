import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/services/auth.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css'],
})
export class HeaderComponent implements OnInit {
  ApplicationAccess: any = localStorage.getItem('application');
  misAccess: boolean = false;
  losAccess: boolean = false;
  constructor(private router: Router, private authService: AuthService) { }

  ngOnInit(): void {
    if (this.ApplicationAccess.includes("MIS")) {
      this.misAccess = true;
    }
    if (this.ApplicationAccess.includes("LOS")) {
      this.losAccess = true;
    }
  }

  _opened: boolean = true;

  @Output() sidebarToggleEvent = new EventEmitter();

  togglesSidebar() {
    this.sidebarToggleEvent.emit((this._opened = !this._opened));
  }

  signoutUser() {
    this.authService.logout()
  }
}
