import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.css'],
})
export class SidebarComponent implements OnInit {
  currentUser: any;

  menuitems: any;
  loginMenu: any = false;
  KycMenu: any = false;
  constructor() { }

  ngOnInit(): void {
    this.menuitems = localStorage.getItem('currentUser')
    this.menuitems = JSON.parse(this.menuitems)
    //console.log(this.menuitems)
    this.currentUser = this.menuitems[0].UserName;

    this.menuitems.forEach((items: any, i: any) => {
      if (items.MenuName === "Login Detail") {
        this.loginMenu = true
      }

      if (items.MenuName === "KYC Detail") {
        this.KycMenu = true
      }
    })
  }


}
