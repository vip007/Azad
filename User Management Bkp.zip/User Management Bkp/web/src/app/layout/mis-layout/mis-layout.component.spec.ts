import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MisLayoutComponent } from './mis-layout.component';

describe('MisLayoutComponent', () => {
  let component: MisLayoutComponent;
  let fixture: ComponentFixture<MisLayoutComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MisLayoutComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MisLayoutComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
