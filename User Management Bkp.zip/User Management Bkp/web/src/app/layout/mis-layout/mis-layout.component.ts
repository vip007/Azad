import { Component, OnInit } from '@angular/core';
import { AuthService } from 'src/app/services/auth.service';

@Component({
  selector: 'app-mis-layout',
  templateUrl: './mis-layout.component.html',
  styleUrls: ['./mis-layout.component.css']
})
export class MisLayoutComponent implements OnInit {
  ApplicationAccess: any = localStorage.getItem('application');
  misAccess: boolean = false;
  losAccess: boolean = false;
  constructor(private authService: AuthService) { }

  ngOnInit(): void {
    if (this.ApplicationAccess.includes("MIS")) {
      this.misAccess = true;
    }
    if (this.ApplicationAccess.includes("LOS")) {
      this.losAccess = true;
    }
  }

  signoutUser() {
    this.authService.logout()
  }

}
