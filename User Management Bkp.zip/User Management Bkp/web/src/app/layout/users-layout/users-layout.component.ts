import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-users-layout',
  templateUrl: './users-layout.component.html',
  styleUrls: ['./users-layout.component.css']
})
export class UsersLayoutComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  _opened: boolean = true;

  // _toggleSidebar() {
  //   this._opened = !this._opened;
  // }

  toggleEvent($event: boolean) {
    this._opened = $event;
  }
}
