import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuard } from 'src/app/services/guards/auth.guard';

const routes: Routes = [
  {
    path: 'master', canActivate: [AuthGuard],
    loadChildren: () =>
      import('./table-masters/table-masters.module').then(
        (m) => m.TableMastersModule
      ),
  },
  {
    path: 'mapping', canActivate: [AuthGuard],
    loadChildren: () =>
      import('./table-mapping/table-mapping.module').then(
        (m) => m.TableMappingModule
      ),
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AdminRoutingModule { }
