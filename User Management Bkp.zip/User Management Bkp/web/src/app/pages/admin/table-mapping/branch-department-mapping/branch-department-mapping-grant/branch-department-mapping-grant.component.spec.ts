import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BranchDepartmentMappingGrantComponent } from './branch-department-mapping-grant.component';

describe('BranchDepartmentMappingGrantComponent', () => {
  let component: BranchDepartmentMappingGrantComponent;
  let fixture: ComponentFixture<BranchDepartmentMappingGrantComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BranchDepartmentMappingGrantComponent ]
    })
    .compileComponents(); 
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(BranchDepartmentMappingGrantComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
