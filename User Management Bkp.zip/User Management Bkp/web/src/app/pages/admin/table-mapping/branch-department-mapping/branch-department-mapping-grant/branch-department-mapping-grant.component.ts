import { DatePipe, Location } from '@angular/common';
import { i18nMetaToJSDoc } from '@angular/compiler/src/render3/view/i18n/meta';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { BranchDepartmentMappingService } from 'src/app/services/admin/mapping/branch-department-mapping.service';
import { BranchService } from 'src/app/services/admin/table-masters/branch.service';
import { DepartmentService } from 'src/app/services/admin/table-masters/department.service';



@Component({
  selector: 'app-branch-department-mapping-grant',
  templateUrl: './branch-department-mapping-grant.component.html',
  styleUrls: ['./branch-department-mapping-grant.component.css'],
  providers: [DatePipe]
})
export class BranchDepartmentMappingGrantComponent implements OnInit {
  UserAccessRightsFrom: any;
  DeptList: any;
  BranchList: any;
  currentUser: any;

  constructor(
    private _location: Location,
    private branchDepartmentService: BranchDepartmentMappingService,
    private fb: FormBuilder,
    private departmentService: DepartmentService,
    private branchService: BranchService,
    private toastr: ToastrService,
    private datePipe: DatePipe,
    private router: Router
  ) { }

  ngOnInit(): void {

    this.getAllDept();
    this.getAllBranch();

    this.currentUser = JSON.parse(localStorage.getItem('currentUser') as string);
    this.currentUser = this.currentUser[0].UserName;

    this.UserAccessRightsFrom = this.fb.group({
      ID_SMCBranch: ['', Validators.required],
      ID_Department: ['', Validators.required],

      CreatedOn: ['', Validators.required],
      CreatedBy: ['', Validators.required],
    })
  }

  backClicked() {
    this._location.back();
  }

  grantUserAccessRights() {
    this.UserAccessRightsFrom.value.CreatedOn = this.datePipe.transform(new Date(), 'yyyy-MM-dd');
    this.UserAccessRightsFrom.value.CreatedBy = this.currentUser
    this.branchDepartmentService.grantBranchDepartment(this.UserAccessRightsFrom.value).subscribe((res: any) => {
      if (res.status === 200) {
        this.router.navigate(['/admin/dashboard/mapping/branch-department']);
      } else {
        this.toastr.error(res.message, 'Error');

      }
    })
    console.log(this.UserAccessRightsFrom.value)
  }
  // helper functions
  getAllDept() {
    this.departmentService.getDepartmentList().subscribe((res: any) => {
      if (res.status === 200) {
        this.DeptList = res.data;
        console.log(this.DeptList)

      }
    })
  }

  getAllBranch() {
    this.branchService.getBranchList().subscribe((res: any) => {
      if (res.status === 200) {
        this.BranchList = res.data;
      }
    })
  }

}
