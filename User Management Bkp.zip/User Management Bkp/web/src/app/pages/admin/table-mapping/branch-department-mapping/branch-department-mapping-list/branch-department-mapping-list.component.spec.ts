import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BranchDepartmentMappingListComponent } from './branch-department-mapping-list.component';

describe('BranchDepartmentMappingListComponent', () => {
  let component: BranchDepartmentMappingListComponent;
  let fixture: ComponentFixture<BranchDepartmentMappingListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BranchDepartmentMappingListComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(BranchDepartmentMappingListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
