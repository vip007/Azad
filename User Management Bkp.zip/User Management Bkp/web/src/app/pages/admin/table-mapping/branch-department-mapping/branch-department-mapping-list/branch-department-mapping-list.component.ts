import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { BranchDepartmentMappingService } from 'src/app/services/admin/mapping/branch-department-mapping.service';


@Component({
  selector: 'app-branch-department-mapping-list',
  templateUrl: './branch-department-mapping-list.component.html',
  styleUrls: ['./branch-department-mapping-list.component.css']
})
export class BranchDepartmentMappingListComponent implements OnInit {

  BranchDept: any;
  p: number = 1;
  constructor(
    private router: Router,
    private branchDepartmentMapping: BranchDepartmentMappingService,
    private toastr: ToastrService
  ) { }

  ngOnInit(): void {
    this.getBranchDepartment();
  }

  grantNewMapping() {
    this.router.navigate(['/admin/dashboard/mapping/branch-department/grant']);
  }

  getBranchDepartment() {
    this.branchDepartmentMapping.getBranchDepartment().subscribe((res: any) => {
      if (res.status === 200) {
        this.BranchDept = res.data
        console.log(this.BranchDept)
      } else {
        this.toastr.error('Failed to load Branch Department Mapping List', 'Error');
      }
    })
  }

  revokeAccess(id: any) {
    this.branchDepartmentMapping.revokeAccess({ "ID_BranchDepartmentMapping": id }).subscribe((res: any) => {
      if (res.status === 200) {
        this.toastr.success('User access rights revoked', 'Success');
        this.getBranchDepartment()
      } else {
        this.toastr.error(res.message, 'Error');
      }
    })
  }


}
