import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { BranchDepartmentMappingGrantComponent } from './branch-department-mapping-grant/branch-department-mapping-grant.component';
import { BranchDepartmentMappingListComponent } from './branch-department-mapping-list/branch-department-mapping-list.component';

const routes: Routes = [
  { path: '', component:BranchDepartmentMappingListComponent  },
  { path: 'grant', component: BranchDepartmentMappingGrantComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class BranchDepartmentMappingRoutingModule { }
