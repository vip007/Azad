import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { BranchDepartmentMappingRoutingModule } from './branch-department-mapping-routing.module';
import { BranchDepartmentMappingListComponent } from './branch-department-mapping-list/branch-department-mapping-list.component';
import { BranchDepartmentMappingGrantComponent } from './branch-department-mapping-grant/branch-department-mapping-grant.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgxPaginationModule } from 'ngx-pagination';


@NgModule({
  declarations: [
    BranchDepartmentMappingListComponent,
    BranchDepartmentMappingGrantComponent
  ],
  imports: [
    CommonModule,
    BranchDepartmentMappingRoutingModule,
    ReactiveFormsModule,
    FormsModule,
    NgxPaginationModule
  ]
})
export class BranchDepartmentMappingModule { }
