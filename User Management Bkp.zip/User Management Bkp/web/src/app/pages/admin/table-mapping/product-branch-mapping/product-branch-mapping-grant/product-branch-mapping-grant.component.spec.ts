import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ProductBranchMappingGrantComponent } from './product-branch-mapping-grant.component';

describe('ProductBranchMappingGrantComponent', () => {
  let component: ProductBranchMappingGrantComponent;
  let fixture: ComponentFixture<ProductBranchMappingGrantComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ProductBranchMappingGrantComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ProductBranchMappingGrantComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
