import { DatePipe, Location } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { BranchService } from 'src/app/services/admin/table-masters/branch.service';
import { ProductBranchMappingService } from 'src/app/services/admin/mapping/product-branch-mapping.service';
import { ProductService } from 'src/app/services/admin/table-masters/product.service';

@Component({
  selector: 'app-product-branch-mapping-grant',
  templateUrl: './product-branch-mapping-grant.component.html',
  styleUrls: ['./product-branch-mapping-grant.component.css'],
  providers: [DatePipe]
})
export class ProductBranchMappingGrantComponent implements OnInit {

  MappingForm!: FormGroup;
  currentUser: any;
  branchList: any;
  productList: any;

  constructor(
    private _location: Location,
    private fb: FormBuilder,
    private toastr: ToastrService,
    private datePipe: DatePipe,
    private router: Router,
    private productService: ProductService,
    private branchService: BranchService,
    private productBranchMappingService: ProductBranchMappingService,
  ) { }

  ngOnInit(): void {
    this.currentUser = JSON.parse(localStorage.getItem('currentUser') as string);
    this.currentUser = this.currentUser[0].UserName;

    this.getAllBranchList()
    this.getAllProduct()

    this.MappingForm = this.fb.group({
      ID_Product: ['', Validators.required],
      ID_Branch: ['', Validators.required],
    })
  }

  backClicked() {
    this._location.back();
  }

  mapAccess() {
    if (this.MappingForm.valid) {
      this.MappingForm.value.CreatedOn = this.datePipe.transform(new Date(), 'yyyy-MM-dd');
      this.MappingForm.value.CreatedBy = this.currentUser

      console.log(this.MappingForm.value)
      this.productBranchMappingService.mapAccess(this.MappingForm.value).subscribe((res: any) => {
        if (res.status === 200) {
          this.toastr.success(res.message, 'Success');
          this.router.navigate(['/admin/dashboard/mapping/product-branch']);
        } else {
          this.toastr.error(res.message, 'Error');
        }
      }, (error) => {
        console.log(error)
      })

    } else {
      this.toastr.warning('All Feilds Not Selected', 'Warning');
    }
  }

  // helperFunctions
  getAllBranchList() {
    this.branchService.getBranchList().subscribe((res: any) => {
      if (res.status === 200) {
        this.branchList = res.data;
        // console.log(this.branchList)
      } else {
        this.toastr.error('Failed to load users list', 'Error');
      }
    })
  }

  getAllProduct() {
    this.productService.getProductList().subscribe((res: any) => {
      if (res.status === 200) {
        this.productList = res.data;
        // console.log("Dpt List", this.productList)
      } else {
        this.toastr.error('Failed to load users list', 'Error');
      }
    })
  }
}
