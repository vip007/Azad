import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ProductBranchMappingListComponent } from './product-branch-mapping-list.component';

describe('ProductBranchMappingListComponent', () => {
  let component: ProductBranchMappingListComponent;
  let fixture: ComponentFixture<ProductBranchMappingListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ProductBranchMappingListComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ProductBranchMappingListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
