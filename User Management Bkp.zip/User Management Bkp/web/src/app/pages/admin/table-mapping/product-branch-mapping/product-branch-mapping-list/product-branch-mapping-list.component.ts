import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { ProductBranchMappingService } from 'src/app/services/admin/mapping/product-branch-mapping.service';

@Component({
  selector: 'app-product-branch-mapping-list',
  templateUrl: './product-branch-mapping-list.component.html',
  styleUrls: ['./product-branch-mapping-list.component.css']
})
export class ProductBranchMappingListComponent implements OnInit {
  p: number = 1;
  MappingList: any;
  constructor(
    private router: Router,
    private toastr: ToastrService,
    private productBranchMappingService: ProductBranchMappingService,
  ) { }

  ngOnInit(): void {
    this.getAccessMappings()
  }

  getAccessMappings() {
    this.productBranchMappingService.getAccessMappings().subscribe((res: any) => {
      if (res.status === 200) {
        this.MappingList = res.data;
      }
    })
  }

  revokeAccess(id: number) {
    this.productBranchMappingService.revokeAccess({ "ID_ProductBranchMapping": id }).subscribe((res: any) => {
      if (res.status === 200) {
        this.toastr.success('User access rights revoked', 'Success');
        this.getAccessMappings()
      } else {
        this.toastr.error('Failed to revoke access', 'Error');
      }
    })
  }

}
