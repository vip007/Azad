import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ProductBranchMappingGrantComponent } from './product-branch-mapping-grant/product-branch-mapping-grant.component';
import { ProductBranchMappingListComponent } from './product-branch-mapping-list/product-branch-mapping-list.component';

const routes: Routes = [
  { path: '', component: ProductBranchMappingListComponent },
  { path: 'grant', component: ProductBranchMappingGrantComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ProductBranchMappingRoutingModule { }
