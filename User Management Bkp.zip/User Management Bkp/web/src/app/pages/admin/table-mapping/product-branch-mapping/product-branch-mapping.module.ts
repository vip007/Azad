import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ProductBranchMappingRoutingModule } from './product-branch-mapping-routing.module';
import { ProductBranchMappingListComponent } from './product-branch-mapping-list/product-branch-mapping-list.component';
import { ProductBranchMappingGrantComponent } from './product-branch-mapping-grant/product-branch-mapping-grant.component';

import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgxPaginationModule } from 'ngx-pagination';

@NgModule({
  declarations: [
    ProductBranchMappingListComponent,
    ProductBranchMappingGrantComponent
  ],
  imports: [
    CommonModule,
    ProductBranchMappingRoutingModule,
    ReactiveFormsModule,
    FormsModule,
    NgxPaginationModule
  ]
})
export class ProductBranchMappingModule { }
