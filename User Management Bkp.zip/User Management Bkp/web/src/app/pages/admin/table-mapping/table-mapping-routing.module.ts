import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuard } from 'src/app/services/guards/auth.guard';

const routes: Routes = [
  {
    path: 'user-access-right', canActivate: [AuthGuard],
    loadChildren: () =>
      import('./user-access-rights/user-access-rights.module').then(
        (m) => m.UserAccessRightsModule
      ),
  },
  {
    path: 'user-branch-dept', canActivate: [AuthGuard],
    loadChildren: () =>
      import('./user-branch-dept-mapping/user-branch-dept-mapping.module').then(
        (m) => m.UserBranchDeptMappingModule
      ),
  },
  {
    path: 'branch-department', canActivate: [AuthGuard],
    loadChildren: () =>
      import('./branch-department-mapping/branch-department-mapping.module').then(
        (m) => m.BranchDepartmentMappingModule
      ),
  },
  {
    path: 'user-role', canActivate: [AuthGuard],
    loadChildren: () =>
      import('./user-role-mapping/user-role-mapping.module').then(
        (m) => m.UserRoleMappingModule
      ),
  },
  {
    path: 'product-branch', canActivate: [AuthGuard],
    loadChildren: () =>
      import('./product-branch-mapping/product-branch-mapping.module').then(
        (m) => m.ProductBranchMappingModule
      ),
  },
  {
    path: 'user-product-branch', canActivate: [AuthGuard],
    loadChildren: () =>
      import('./user-product-branch-mapping/user-product-branch-mapping.module').then(
        (m) => m.UserProductBranchMappingModule
      ),
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class TableMappingRoutingModule { }
