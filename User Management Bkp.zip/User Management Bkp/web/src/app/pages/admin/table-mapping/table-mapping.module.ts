import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { TableMappingRoutingModule } from './table-mapping-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    TableMappingRoutingModule
  ]
})
export class TableMappingModule { }
