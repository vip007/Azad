import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UserAccessRightsGrantComponent } from './user-access-rights-grant.component';

describe('UserAccessRightsGrantComponent', () => {
  let component: UserAccessRightsGrantComponent;
  let fixture: ComponentFixture<UserAccessRightsGrantComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UserAccessRightsGrantComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UserAccessRightsGrantComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
