import { DatePipe, Location } from '@angular/common';
import { i18nMetaToJSDoc } from '@angular/compiler/src/render3/view/i18n/meta';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { UserAccessRightsService } from 'src/app/services/admin/mapping/user-access-rights.service';
import { MenuService } from 'src/app/services/admin/table-masters/menu.service';
import { MenuEventService } from 'src/app/services/admin/table-masters/menuevent.service';
import { UsersService } from 'src/app/services/admin/table-masters/users.service';

@Component({
  selector: 'app-user-access-rights-grant',
  templateUrl: './user-access-rights-grant.component.html',
  styleUrls: ['./user-access-rights-grant.component.css'],
  providers: [DatePipe]
})
export class UserAccessRightsGrantComponent implements OnInit {
  UserAccessRightsFrom: any;
  usersList: any;
  menuList: any;
  menuEventList: any[] = [];
  currentUser: any;
  settings: any = {}

  constructor(
    private _location: Location,
    private userAccessRightsService: UserAccessRightsService,
    private usersService: UsersService,
    private menuService: MenuService,
    private menuEventService: MenuEventService,
    private fb: FormBuilder,
    private toastr: ToastrService,
    private datePipe: DatePipe,
    private router: Router
  ) { }

  ngOnInit(): void {

    this.getAllUsers();
    this.getAllMenus();
    // this.getAllMenuEvents();
    this.settings = {
      text: "Select Menu Event",
      primaryKey: "ID_MenuEvent",
      labelKey: "MenuEventCode",
      noDataLabel: "Select a menu first to get events"
    }


    this.currentUser = JSON.parse(localStorage.getItem('currentUser') as string);
    this.currentUser = this.currentUser[0].UserName;

    this.UserAccessRightsFrom = this.fb.group({
      ID_User: ['', Validators.required],
      ID_Menu: ['', Validators.required],
      ID_MenuEvent: ['', Validators.required],
      CreatedOn: [''],
      CreatedBy: [''],
    })
  }

  backClicked() {
    this._location.back();
  }

  grantUserAccessRights() {

    if (this.UserAccessRightsFrom.valid) {
      this.UserAccessRightsFrom.value.CreatedOn = this.datePipe.transform(new Date(), 'yyyy-MM-dd');
      this.UserAccessRightsFrom.value.CreatedBy = this.currentUser

      this.UserAccessRightsFrom.value.ID_MenuEvent.forEach((item: any) => {
        this.UserAccessRightsFrom.value.ID_MenuEvent = item.ID_MenuEvent
        this.userAccessRightsService.grantUserAccessRights(this.UserAccessRightsFrom.value).subscribe((res: any) => {
          if (res.status === 200) {
            this.router.navigate(['/admin/dashboard/mapping/user-access-right']);
          } else {
            this.toastr.error(`User already has ${item.MenuEventCode} access`, 'Error');
          }
        })
      })
    } else {
      this.toastr.warning('All Feilds Not Selected', 'Warning');
    }
  }


  // Helper Functions
  getAllUsers() {
    this.usersService.getUsersListData().subscribe((res: any) => {
      if (res.status === 200) {
        this.usersList = res.data
      } else {
        this.toastr.error('Failed to load users list', 'Error');
      }
    })
  }

  getAllMenus() {
    this.menuService.getMenuList().subscribe((res: any) => {
      if (res.status === 200) {
        this.menuList = res.data
      } else {
        this.toastr.error('Failed to load menu list', 'Error');
      }
    })
  }

  getAllMenuEvents(event: any) {
    this.menuEventService.MenuEventWithID(event.value).subscribe((res: any) => {
      if (res.status === 200) {
        this.menuEventList = [];
        this.UserAccessRightsFrom.controls.ID_MenuEvent.reset()
        res.data.forEach((item: any, i: any) => {
          this.menuEventList.push({ "ID_MenuEvent": item.ID_MenuEvent, "MenuEventCode": item.MenuEventCode })
        });
      } else {
        this.toastr.warning(res.message, 'Warning');
        this.menuEventList = []
      }
    })
  }

}
