import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UserAccessRightsListComponent } from './user-access-rights-list.component';

describe('UserAccessRightsListComponent', () => {
  let component: UserAccessRightsListComponent;
  let fixture: ComponentFixture<UserAccessRightsListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UserAccessRightsListComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UserAccessRightsListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
