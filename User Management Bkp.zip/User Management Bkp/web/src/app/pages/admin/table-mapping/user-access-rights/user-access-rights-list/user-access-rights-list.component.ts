import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { UserAccessRightsService } from 'src/app/services/admin/mapping/user-access-rights.service';

@Component({
  selector: 'app-user-access-rights-list',
  templateUrl: './user-access-rights-list.component.html',
  styleUrls: ['./user-access-rights-list.component.css']
})
export class UserAccessRightsListComponent implements OnInit {

  UserAccessRights: any;
  p: number = 1;

  constructor(
    private router: Router,
    private userAccessRightsService: UserAccessRightsService,
    private toastr: ToastrService
  ) { }

  ngOnInit(): void {
    this.getUserAccessRights()
  }

  grantNewMapping() {
    this.router.navigate(['/admin/dashboard/mapping/user-access-right/grant']);
  }

  getUserAccessRights() {
    this.userAccessRightsService.getUserAccessRights().subscribe((res: any) => {
      if (res.status === 200) {
        this.UserAccessRights = res.data
        console.dir(this.UserAccessRights)
      } else {
        this.toastr.error('Failed to load User Access Rights List', 'Error');
      }
    })
  }

  revokeAccess(id: any) {
    this.userAccessRightsService.revokeAccess({ "ID_UserAccessRights": id }).subscribe((res: any) => {
      if (res.status === 200) {
        this.toastr.success('User access rights revoked', 'Success');
        this.getUserAccessRights()
      } else {
        this.toastr.error('Failed to revoke access rights', 'Error');
      }
    })
  }


}
