import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { UserAccessRightsGrantComponent } from './user-access-rights-grant/user-access-rights-grant.component';
import { UserAccessRightsListComponent } from './user-access-rights-list/user-access-rights-list.component';

const routes: Routes = [
  { path: '', component: UserAccessRightsListComponent },
  { path: 'grant', component: UserAccessRightsGrantComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class UserAccessRightsRoutingModule { }
