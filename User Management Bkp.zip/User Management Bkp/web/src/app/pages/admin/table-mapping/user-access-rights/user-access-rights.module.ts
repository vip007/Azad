import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { UserAccessRightsRoutingModule } from './user-access-rights-routing.module';
import { UserAccessRightsListComponent } from './user-access-rights-list/user-access-rights-list.component';
import { UserAccessRightsGrantComponent } from './user-access-rights-grant/user-access-rights-grant.component';

import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgxSpinnerModule } from 'ngx-spinner';
import { AngularMultiSelectModule } from 'angular2-multiselect-dropdown';
import { NgxPaginationModule } from 'ngx-pagination';

@NgModule({
  declarations: [
    UserAccessRightsListComponent,
    UserAccessRightsGrantComponent
  ],
  imports: [
    CommonModule,
    UserAccessRightsRoutingModule, FormsModule,
    ReactiveFormsModule, NgxSpinnerModule, AngularMultiSelectModule, NgxPaginationModule
  ]
})
export class UserAccessRightsModule { }
