import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UserBranchDeptMappingGrantComponent } from './user-branch-dept-mapping-grant.component';

describe('UserBranchDeptMappingGrantComponent', () => {
  let component: UserBranchDeptMappingGrantComponent;
  let fixture: ComponentFixture<UserBranchDeptMappingGrantComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UserBranchDeptMappingGrantComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UserBranchDeptMappingGrantComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
