import { DatePipe, Location } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { BranchService } from 'src/app/services/admin/table-masters/branch.service';
import { DepartmentService } from 'src/app/services/admin/table-masters/department.service';
import { UserBranchDepartmentService } from 'src/app/services/admin/mapping/user-branch-department.service';

import { UsersService } from 'src/app/services/admin/table-masters/users.service';

@Component({
  selector: 'app-user-branch-dept-mapping-grant',
  templateUrl: './user-branch-dept-mapping-grant.component.html',
  styleUrls: ['./user-branch-dept-mapping-grant.component.css'],
  providers: [DatePipe]
})
export class UserBranchDeptMappingGrantComponent implements OnInit {
  UserBranchDeptForm: any;
  currentUser: any;

  usersList: any;
  branchAndDeptList: any;


  constructor(
    private _location: Location,
    private fb: FormBuilder,
    private toastr: ToastrService,
    private datePipe: DatePipe,
    private router: Router,

    private usersService: UsersService,
    private userDeptBranchMappingService: UserBranchDepartmentService,

  ) { }

  ngOnInit(): void {

    this.currentUser = JSON.parse(localStorage.getItem('currentUser') as string);
    this.currentUser = this.currentUser[0].UserName;

    this.getAllUsers()
    this.getBranchAndDept()


    this.UserBranchDeptForm = this.fb.group({
      ID_User: ['', Validators.required],
      ID_BranchDepartmentMapping: ['', Validators.required],
      CreatedOn: [''],
      CreatedBy: [''],
    })
  }

  grantUserAccessRights() {

    if (this.UserBranchDeptForm.valid) {
      this.UserBranchDeptForm.value.CreatedOn = this.datePipe.transform(new Date(), 'yyyy-MM-dd');
      this.UserBranchDeptForm.value.CreatedBy = this.currentUser
      this.userDeptBranchMappingService.mapAccess(this.UserBranchDeptForm.value).subscribe((res: any) => {
        if (res.status === 200) {
          this.router.navigate(['/admin/dashboard/mapping/user-branch-dept']);
          this.toastr.success(res.message, 'Success');
        } else {
          this.toastr.error(res.message, 'Error');
        }
      })
    } else {
      this.toastr.warning('Form is invalid, Please select all feilds', 'Warning');
    }

  }

  // Helper Functions
  getAllUsers() {
    this.usersService.getUsersListData().subscribe((res: any) => {
      if (res.status === 200) {
        this.usersList = res.data
      } else {
        this.toastr.error('Failed to load users list', 'Error');
      }
    })
  }

  getBranchAndDept() {
    this.userDeptBranchMappingService.getBranchAndDept().subscribe((res: any) => {
      if (res.status === 200) {
        this.branchAndDeptList = res.data;
      } else {
        this.toastr.error('Failed to load users list', 'Error');
      }
    })
  }

  backClicked() {
    this._location.back();
  }

}
