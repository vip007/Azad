import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UserBranchDeptMappingListComponent } from './user-branch-dept-mapping-list.component';

describe('UserBranchDeptMappingListComponent', () => {
  let component: UserBranchDeptMappingListComponent;
  let fixture: ComponentFixture<UserBranchDeptMappingListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UserBranchDeptMappingListComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UserBranchDeptMappingListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
