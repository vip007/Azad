import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { UserBranchDepartmentService } from 'src/app/services/admin/mapping/user-branch-department.service';

@Component({
  selector: 'app-user-branch-dept-mapping-list',
  templateUrl: './user-branch-dept-mapping-list.component.html',
  styleUrls: ['./user-branch-dept-mapping-list.component.css']
})
export class UserBranchDeptMappingListComponent implements OnInit {
  UserBranchDeptList: any;
  p: number = 1;
  constructor(
    private router: Router,
    private userBranchDepartmentService: UserBranchDepartmentService,
    private toastr: ToastrService
  ) { }

  ngOnInit(): void {
    this.getAccessMappings()
  }

  revokeAccess(id: any) {
    this.userBranchDepartmentService.revokeAccess({ "ID_UserBranchDepartment": id }).subscribe((res: any) => {
      if (res.status === 200) {
        this.toastr.success('User Branch Dept rights revoked', 'Success');
        this.getAccessMappings()
      } else {
        this.toastr.error('Failed to revoke User Branch Dept rights', 'Error');
      }
    })
  }

  grantNewMapping() {
    this.router.navigate(['/admin/dashboard/mapping/user-branch-dept/grant']);
  }

  getAccessMappings() {
    this.userBranchDepartmentService.getAccessMappings().subscribe((res: any) => {
      if (res.status === 200) {
        this.UserBranchDeptList = res.data;
      }
    })
  }

}
