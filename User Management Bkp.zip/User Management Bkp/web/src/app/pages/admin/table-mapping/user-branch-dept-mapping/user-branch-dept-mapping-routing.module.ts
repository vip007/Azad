import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { UserBranchDeptMappingGrantComponent } from './user-branch-dept-mapping-grant/user-branch-dept-mapping-grant.component';
import { UserBranchDeptMappingListComponent } from './user-branch-dept-mapping-list/user-branch-dept-mapping-list.component';

const routes: Routes = [
  { path: '', component: UserBranchDeptMappingListComponent },
  { path: 'grant', component: UserBranchDeptMappingGrantComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class UserBranchDeptMappingRoutingModule { }
