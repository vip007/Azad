import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { UserBranchDeptMappingRoutingModule } from './user-branch-dept-mapping-routing.module';
import { UserBranchDeptMappingListComponent } from './user-branch-dept-mapping-list/user-branch-dept-mapping-list.component';
import { UserBranchDeptMappingGrantComponent } from './user-branch-dept-mapping-grant/user-branch-dept-mapping-grant.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { NgxPaginationModule } from 'ngx-pagination';



@NgModule({
  declarations: [
    UserBranchDeptMappingListComponent,
    UserBranchDeptMappingGrantComponent,

  ],
  imports: [
    CommonModule,
    UserBranchDeptMappingRoutingModule, FormsModule, ReactiveFormsModule, NgxPaginationModule
  ]
})
export class UserBranchDeptMappingModule { }
