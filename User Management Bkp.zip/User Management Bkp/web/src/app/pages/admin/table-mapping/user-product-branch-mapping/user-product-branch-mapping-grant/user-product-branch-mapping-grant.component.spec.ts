import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UserProductBranchMappingGrantComponent } from './user-product-branch-mapping-grant.component';

describe('UserProductBranchMappingGrantComponent', () => {
  let component: UserProductBranchMappingGrantComponent;
  let fixture: ComponentFixture<UserProductBranchMappingGrantComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UserProductBranchMappingGrantComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UserProductBranchMappingGrantComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
