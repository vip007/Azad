import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UserProductBranchMappingListComponent } from './user-product-branch-mapping-list.component';

describe('UserProductBranchMappingListComponent', () => {
  let component: UserProductBranchMappingListComponent;
  let fixture: ComponentFixture<UserProductBranchMappingListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UserProductBranchMappingListComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UserProductBranchMappingListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
