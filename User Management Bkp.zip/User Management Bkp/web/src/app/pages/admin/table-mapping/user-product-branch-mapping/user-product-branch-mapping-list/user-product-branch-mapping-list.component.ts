import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { UserProductBranchMappingService } from 'src/app/services/admin/mapping/user-product-branch-mapping.service';

@Component({
  selector: 'app-user-product-branch-mapping-list',
  templateUrl: './user-product-branch-mapping-list.component.html',
  styleUrls: ['./user-product-branch-mapping-list.component.css']
})
export class UserProductBranchMappingListComponent implements OnInit {

  MappingList: any;
  p: number = 1;
  constructor(
    private router: Router,
    private toastr: ToastrService,
    private userProductBranchMappingService: UserProductBranchMappingService,
  ) { }

  ngOnInit(): void {
    this.getAccessMappings()
  }

  getAccessMappings() {
    this.userProductBranchMappingService.getAccessMappings().subscribe((res: any) => {
      if (res.status === 200) {
        this.MappingList = res.data;
      }
    })
  }

  revokeAccess(id: number) {
    this.userProductBranchMappingService.revokeAccess({ "ID_UserProductBranchMapping": id }).subscribe((res: any) => {
      if (res.status === 200) {
        this.toastr.success('User Product Branch rights revoked', 'Success');
        this.getAccessMappings()
      } else {
        this.toastr.error('Failed to revoke User Product Branch rights', 'Error');
      }
    })
  }

}
