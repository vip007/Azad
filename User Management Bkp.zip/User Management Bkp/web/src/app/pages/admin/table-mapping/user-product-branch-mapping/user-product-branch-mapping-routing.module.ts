import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { UserProductBranchMappingGrantComponent } from './user-product-branch-mapping-grant/user-product-branch-mapping-grant.component';
import { UserProductBranchMappingListComponent } from './user-product-branch-mapping-list/user-product-branch-mapping-list.component';


const routes: Routes = [
  { path: '', component: UserProductBranchMappingListComponent },
  { path: 'grant', component: UserProductBranchMappingGrantComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class UserProductBranchMappingRoutingModule { }
