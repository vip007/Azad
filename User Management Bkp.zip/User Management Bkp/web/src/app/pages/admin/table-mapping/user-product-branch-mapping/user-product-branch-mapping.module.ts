import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { UserProductBranchMappingRoutingModule } from './user-product-branch-mapping-routing.module';
import { UserProductBranchMappingListComponent } from './user-product-branch-mapping-list/user-product-branch-mapping-list.component';
import { UserProductBranchMappingGrantComponent } from './user-product-branch-mapping-grant/user-product-branch-mapping-grant.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgxPaginationModule } from 'ngx-pagination';


@NgModule({
  declarations: [
    UserProductBranchMappingListComponent,
    UserProductBranchMappingGrantComponent
  ],
  imports: [
    CommonModule,
    UserProductBranchMappingRoutingModule, FormsModule, ReactiveFormsModule, NgxPaginationModule
  ]
})
export class UserProductBranchMappingModule { }
