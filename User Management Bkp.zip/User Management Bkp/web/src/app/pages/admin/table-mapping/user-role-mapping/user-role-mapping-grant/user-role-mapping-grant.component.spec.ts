import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UserRoleMappingGrantComponent } from './user-role-mapping-grant.component';

describe('UserRoleMappingGrantComponent', () => {
  let component: UserRoleMappingGrantComponent;
  let fixture: ComponentFixture<UserRoleMappingGrantComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UserRoleMappingGrantComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UserRoleMappingGrantComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
