import { DatePipe, Location } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { UserRoleMappingService } from 'src/app/services/admin/mapping/user-role-mapping.service';
import { RoleService } from 'src/app/services/admin/table-masters/role.service';
import { UsersService } from 'src/app/services/admin/table-masters/users.service';

@Component({
  selector: 'app-user-role-mapping-grant',
  templateUrl: './user-role-mapping-grant.component.html',
  styleUrls: ['./user-role-mapping-grant.component.css'],
  providers: [DatePipe]
})
export class UserRoleMappingGrantComponent implements OnInit {
  MappingForm!: FormGroup;
  currentUser: any;

  userList: any;
  roleList: any;

  constructor(
    private _location: Location,
    private fb: FormBuilder,
    private toastr: ToastrService,
    private datePipe: DatePipe,
    private router: Router,

    private usersService: UsersService,
    private roleService: RoleService,
    private userRoleMappingService: UserRoleMappingService

  ) { }

  ngOnInit(): void {
    this.getUsers()
    this.gerRoles()
    this.currentUser = JSON.parse(localStorage.getItem('currentUser') as string);
    this.currentUser = this.currentUser[0].UserName;

    this.MappingForm = this.fb.group({
      ID_User: ['', Validators.required],
      ID_Role: ['', Validators.required],

    })
  }

  backClicked() {
    this._location.back();
  }

  mapAccess() {
    if (this.MappingForm.valid) {
      this.MappingForm.value.CreatedOn = this.datePipe.transform(new Date(), 'yyyy-MM-dd');
      this.MappingForm.value.CreatedBy = this.currentUser
      // console.log(this.MappingForm.value)
      this.userRoleMappingService.mapAccess(this.MappingForm.value).subscribe((res: any) => {
        if (res.status === 200) {
          this.toastr.success(res.message, 'Success');
          this.router.navigate(['/admin/dashboard/mapping/user-role/']);
        } else {
          this.userList = [];
          this.toastr.error(res.message, 'Error');
        }
      }, (error) => {
        console.log(error)
      })
    } else {
      this.toastr.warning('All Feilds Not Selected', 'Warning');
    }
  }

  // Helper Functions
  getUsers() {
    this.usersService.getUsersListData().subscribe((res: any) => {
      if (res.status === 200) {
        this.userList = res.data;
        // console.log(this.userList)
      } else {
        this.userList = [];
        this.toastr.error('No Users List Found', 'Error');
      }
    }, (error) => {
      console.log(error)
    })
  }

  gerRoles() {
    this.roleService.getRoleList().subscribe((res: any) => {
      if (res.status === 200) {
        this.roleList = res.data;
        // console.log(this.roleList)
      } else {
        this.roleList = [];
        this.toastr.error('No Role List Found', 'Error');
      }
    }, (error) => {
      console.log(error)
    })
  }
}
