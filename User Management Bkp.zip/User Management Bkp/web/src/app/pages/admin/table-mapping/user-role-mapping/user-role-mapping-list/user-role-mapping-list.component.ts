import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { UserRoleMappingService } from 'src/app/services/admin/mapping/user-role-mapping.service';

@Component({
  selector: 'app-user-role-mapping-list',
  templateUrl: './user-role-mapping-list.component.html',
  styleUrls: ['./user-role-mapping-list.component.css']
})
export class UserRoleMappingListComponent implements OnInit {
  MappingList: any;
  p: number = 1;

  constructor(
    private router: Router,
    private toastr: ToastrService,
    private userRoleMappingService: UserRoleMappingService
  ) { }

  ngOnInit(): void {
    this.getAccessMappings()
  }

  getAccessMappings() {
    this.userRoleMappingService.getAccessMappings().subscribe((res: any) => {
      if (res.status === 200) {
        this.MappingList = res.data;
        console.log(this.MappingList)
      } else {
        this.MappingList = [];
        this.toastr.error('No Mapping List Found', 'Error');
      }
    }, (error) => {
      console.log(error)
    })
  }

  revokeAccess(id: number) {
    this.userRoleMappingService.revokeAccess({ "ID_UserRoleMapping": id }).subscribe((res: any) => {
      if (res.status === 200) {
        this.getAccessMappings()
      } else {
        this.toastr.error(res.message, 'Error');
      }
    }, (error) => {
      console.log(error)
    })
  }

}
