import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { UserRoleMappingGrantComponent } from './user-role-mapping-grant/user-role-mapping-grant.component';
import { UserRoleMappingListComponent } from './user-role-mapping-list/user-role-mapping-list.component';

const routes: Routes = [
  { path: '', component: UserRoleMappingListComponent },
  { path: 'grant', component: UserRoleMappingGrantComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class UserRoleMappingRoutingModule { }
