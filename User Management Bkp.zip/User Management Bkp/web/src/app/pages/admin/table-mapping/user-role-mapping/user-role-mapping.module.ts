import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { UserRoleMappingRoutingModule } from './user-role-mapping-routing.module';
import { UserRoleMappingListComponent } from './user-role-mapping-list/user-role-mapping-list.component';
import { UserRoleMappingGrantComponent } from './user-role-mapping-grant/user-role-mapping-grant.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { NgxPaginationModule } from 'ngx-pagination';

@NgModule({
  declarations: [
    UserRoleMappingListComponent,
    UserRoleMappingGrantComponent
  ],
  imports: [
    CommonModule,
    UserRoleMappingRoutingModule,
    ReactiveFormsModule,
    FormsModule,
    NgxPaginationModule
  ]
})
export class UserRoleMappingModule { }
