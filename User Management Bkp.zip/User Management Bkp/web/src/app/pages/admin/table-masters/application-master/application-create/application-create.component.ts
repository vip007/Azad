import { Location } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { DatePipe } from '@angular/common';
import { ToastrService } from 'ngx-toastr';
import { ApplicationService } from 'src/app/services/admin/table-masters/application.service';

@Component({
  selector: 'app-application-create',
  templateUrl: './application-create.component.html',
  styleUrls: ['./application-create.component.css'],
  providers: [DatePipe]
})
export class ApplicationCreateComponent implements OnInit {
  createApplicationForm!: FormGroup;
  currentUser: any;
  constructor(
    private _location: Location,
    private fb: FormBuilder,
    private toastr: ToastrService,
    private router: Router,
    private datePipe: DatePipe,
    private applicationService: ApplicationService
  ) { }

  ngOnInit(): void {
    this.currentUser = JSON.parse(localStorage.getItem('currentUser') as string);
    this.currentUser = this.currentUser[0].UserName;

    this.createApplicationForm = this.fb.group({
      ApplicationCode: ['', Validators.required],
      ApplicationName: ['', Validators.required],
      Description: ['', Validators.required],
    })
  }

  createNewApplication() {

    this.createApplicationForm.value.createdOn = this.datePipe.transform(new Date(), 'yyyy-MM-dd');
    this.createApplicationForm.value.createdby = this.currentUser
    this.applicationService.createNewApplication(this.createApplicationForm.value).subscribe((data: any) => {
      if (data.status === 200) {
        this.toastr.success(data.message, 'Success');
        this.router.navigate(['/admin/dashboard/master/applications']);
      } else {
        this.toastr.warning(data.message, 'Warning');
      }
    }, (Error) => {
      this.toastr.error(Error.message, 'Error');
    });
  }

  backClicked() {
    this._location.back();
  }


}
