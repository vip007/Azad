import { DatePipe, Location } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { ApplicationService } from 'src/app/services/admin/table-masters/application.service';

@Component({
  selector: 'app-application-edit',
  templateUrl: './application-edit.component.html',
  styleUrls: ['./application-edit.component.css'],
  providers: [DatePipe]
})
export class ApplicationEditComponent implements OnInit {
  appToModify: any;
  modifyAppForm!: any;
  currentUser: any;
  constructor(
    private _location: Location,
    private toastr: ToastrService,
    private applicationService: ApplicationService,
    private activatedroute: ActivatedRoute,
    private fb: FormBuilder,
    private datePipe: DatePipe,
    private router: Router
  ) { }

  ngOnInit(): void {
    this.getUsertoModify()
    this.currentUser = JSON.parse(localStorage.getItem('currentUser') as string);
    this.currentUser = this.currentUser[0].UserName;

    this.modifyAppForm = this.fb.group({
      ApplicationCode: ['', Validators.required],
      ApplicationName: ['', Validators.required],
      Description: ['', Validators.required],
    })
  }

  backClicked() {
    this._location.back();
  }

  modifyAppllication() {
    this.modifyAppForm.value.ModifiedOn = this.datePipe.transform(new Date(), 'yyyy-MM-dd');
    this.modifyAppForm.value.ModifiedBy = this.currentUser;
    this.modifyAppForm.value.ID_Application = this.activatedroute.snapshot.paramMap.get("id");
    this.applicationService.modifyApplicaion(this.modifyAppForm.value).subscribe((data: any) => {
      if (data.status === 200) {
        this.toastr.success(data.message, 'Success');
        this.router.navigate(['/admin/dashboard/master/applications']);
      } else {
        this.toastr.error(data.message, 'Error');
      }
    });
  }

  submitModifyAppllicationForm() {
    if (this.modifyAppForm.touched) {
      if (this.modifyAppForm.invalid) {
        this.toastr.error('Form is invalid, Please try again with all valid values', 'Error');
      } else {
        this.modifyAppllication()
      }
    } else {
      this.toastr.info('Press cancel to go back to users list', 'No changes made');
    }
  }

  getUsertoModify() {
    this.applicationService.getApplicationWithID(this.activatedroute.snapshot.paramMap.get("id")).subscribe((res: any) => {
      if (res.status === 200) {
        this.appToModify = res.data[0]
        if (this.appToModify) {
          this.modifyAppForm.setValue(
            {
              ApplicationCode: this.appToModify.ApplicationCode,
              ApplicationName: this.appToModify.ApplicationName,
              Description: this.appToModify.Description,
            }
          );
        }

      } else {
        this.toastr.error('Failed to load user', 'Error');
      }
    })
  }

}
