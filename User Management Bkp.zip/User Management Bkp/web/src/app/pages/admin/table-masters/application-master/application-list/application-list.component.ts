import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { ApplicationService } from 'src/app/services/admin/table-masters/application.service';

@Component({
  selector: 'app-application-list',
  templateUrl: './application-list.component.html',
  styleUrls: ['./application-list.component.css']
})
export class ApplicationListComponent implements OnInit {
  ApplicationList!: any;
  constructor(
    private applicationService: ApplicationService,
    private toastr: ToastrService,
    private router: Router
  ) { }

  ngOnInit(): void {
    this.getApplicationList()
  }

  getApplicationList() {
    this.applicationService.getApplicationList().subscribe((res: any) => {
      if (res.status === 200) {
        this.ApplicationList = res.data
      } else {
        this.toastr.error("Failed to load application list", 'Error');
      }
    })
  }

  modifyApplication(id: number) {
    this.router.navigate(['/admin/dashboard/master/applications/modify/' + id]);
  }


  toggleApplicationActiveState(id: number, state: number) {
    this.applicationService.toggleUserActiveState({ "ID_Application": id, "IsActive": state }).subscribe((res: any) => {
      if (res.status === 200) {
        this.getApplicationList()
      } else {
        this.toastr.error(res.message, 'Error');
      }
    });

  }

}
