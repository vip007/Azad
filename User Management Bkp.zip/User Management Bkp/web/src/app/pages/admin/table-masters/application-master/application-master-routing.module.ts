import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ApplicationCreateComponent } from './application-create/application-create.component';
import { ApplicationEditComponent } from './application-edit/application-edit.component';
import { ApplicationListComponent } from './application-list/application-list.component';

const routes: Routes = [
  { path: '', component: ApplicationListComponent },
  { path: 'create', component: ApplicationCreateComponent },
  { path: 'modify/:id', component: ApplicationEditComponent },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ApplicationMasterRoutingModule { }
