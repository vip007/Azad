import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ApplicationMasterRoutingModule } from './application-master-routing.module';
import { ApplicationListComponent } from './application-list/application-list.component';
import { ApplicationCreateComponent } from './application-create/application-create.component';

import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ApplicationEditComponent } from './application-edit/application-edit.component';


@NgModule({
  declarations: [
    ApplicationListComponent,
    ApplicationCreateComponent,
    ApplicationEditComponent
  ],
  imports: [
    CommonModule,
    ApplicationMasterRoutingModule, ReactiveFormsModule, FormsModule
  ]
})
export class ApplicationMasterModule { }
