import { DatePipe, Location } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { BranchService } from 'src/app/services/admin/table-masters/branch.service';
import { LocationService } from 'src/app/services/admin/table-masters/location.service';

@Component({
  selector: 'app-branch-create',
  templateUrl: './branch-create.component.html',
  styleUrls: ['./branch-create.component.css'],
  providers: [DatePipe]
})
export class BranchCreateComponent implements OnInit {
  createBranchForm!: FormGroup;
  locationList: any;
  currentUser: any;

  constructor(private _location: Location,
    private fb: FormBuilder,
    private toastr: ToastrService,
    private router: Router,
    private datePipe: DatePipe,
    private branchService: BranchService,
    private locationService: LocationService,
  ) { }

  ngOnInit(): void {
    this.getLocationList()

    this.currentUser = JSON.parse(localStorage.getItem('currentUser') as string);
    this.currentUser = this.currentUser[0].UserName;

    this.createBranchForm = this.fb.group({
      Code: ['', Validators.required],
      Name: ['', Validators.required],
      ID_Location: ['', Validators.required],
      Address1: ['', Validators.required],
      City: ['', Validators.required],
      PinCode: ['', Validators.required],
      ID_States: ['', Validators.required],
      Mobile: [''],
      STD: [''],
      Branch_LandLine: [''],
      Branch_EmailID: [''],
      Contact_Person: [''],
      Opening_Date: [''],
      Closing_Date: [''],
      Parent_BranchID: [''],
    })

  }

  backClicked() {
    this._location.back();
  }

  createNewBranch() {
    this.createBranchForm.value.createdOn = this.datePipe.transform(new Date(), 'yyyy-MM-dd');
    this.createBranchForm.value.createdby = this.currentUser
    this.branchService.createNewBranch(this.createBranchForm.value).subscribe((data: any) => {
      if (data.status === 200) {
        this.toastr.success(data.message, 'Success');
        this.router.navigate(['/admin/dashboard/master/branch']);
      } else {
        this.toastr.warning(data.message, 'Warning');
      }
    }, (Error) => {
      this.toastr.error(Error.message, 'Error');
    });
  }


  getLocationList() {
    this.locationService.getLocationList().subscribe((res: any) => {
      if (res.status === 200) {
        this.locationList = res.data;
      }
    })
  }

}
