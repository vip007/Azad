import { DatePipe, Location } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { BranchService } from 'src/app/services/admin/table-masters/branch.service';
import { LocationService } from 'src/app/services/admin/table-masters/location.service';

@Component({
  selector: 'app-branch-edit',
  templateUrl: './branch-edit.component.html',
  styleUrls: ['./branch-edit.component.css'],
  providers: [DatePipe]
})
export class BranchEditComponent implements OnInit {
  editBranchForm!: FormGroup;
  locationList: any;
  branchToModify: any;
  currentUser: any;
  constructor(
    private _location: Location,
    private fb: FormBuilder,
    private locationService: LocationService,
    private toastr: ToastrService,
    private router: Router,
    private datePipe: DatePipe,
    private branchService: BranchService,
    private activatedroute: ActivatedRoute
  ) { }

  ngOnInit(): void {
    this.currentUser = JSON.parse(localStorage.getItem('currentUser') as string);
    this.currentUser = this.currentUser[0].UserName;
    this.getLocationList()
    this.getBranchWithID()
    this.editBranchForm = this.fb.group({
      Code: ['', Validators.required],
      Name: ['', Validators.required],
      ID_Location: ['', Validators.required],
      Address1: ['', Validators.required],
      City: ['', Validators.required],
      PinCode: ['', Validators.required],
      ID_States: ['', Validators.required],
      Mobile: [''],
      STD: [''],
      Branch_LandLine: [''],
      Branch_EmailID: [''],
      Contact_Person: [''],
      Opening_Date: [''],
      Closing_Date: [''],
      Parent_BranchID: [''],
    })
  }

  backClicked() {
    this._location.back();
  }

  modifyBranch() {
    this.editBranchForm.value.ModifiedOn = this.datePipe.transform(new Date(), 'yyyy-MM-dd');
    this.editBranchForm.value.ModifiedBy = this.currentUser;
    this.editBranchForm.value.ID_Branch = this.activatedroute.snapshot.paramMap.get("id");
    this.branchService.modifyBranch(this.editBranchForm.value).subscribe((data: any) => {
      if (data.status === 200) {
        this.toastr.success('Branch was modified succesfully', 'Success');
        this.router.navigate(['/admin/dashboard/master/branch']);
      } else {
        this.toastr.error(data.message, 'Error');
      }
    });
  }

  submitModifyBranchForm() {
    if (this.editBranchForm.touched) {
      if (this.editBranchForm.invalid) {
        this.toastr.error('Form is invalid, Please try again with all valid values', 'Error');
      } else {
        this.modifyBranch()
      }
    } else {
      this.toastr.info('Press cancel to go back to users list', 'No changes made');
    }
  }

  getBranchWithID() {
    this.branchService.getBranchWithID(this.activatedroute.snapshot.paramMap.get("id")).subscribe((res: any) => {
      if (res.status === 200) {
        this.branchToModify = res.data[0]
        this.branchToModify.Opening_Date = this.datePipe.transform(this.branchToModify.Opening_Date, 'yyyy-MM-dd');
        this.branchToModify.Closing_Date = this.datePipe.transform(this.branchToModify.Closing_Date, 'yyyy-MM-dd');
        if (this.branchToModify) {
          this.editBranchForm.setValue(
            {
              Code: this.branchToModify.Code,
              Name: this.branchToModify.Name,
              ID_Location: this.branchToModify.ID_Location,
              Address1: this.branchToModify.Address1,
              City: this.branchToModify.City,
              PinCode: this.branchToModify.PinCode,
              ID_States: this.branchToModify.ID_States,
              Mobile: this.branchToModify.Mobile,
              STD: this.branchToModify.STD,
              Branch_LandLine: this.branchToModify.Branch_LandLine,
              Branch_EmailID: this.branchToModify.Branch_EmailID,
              Contact_Person: this.branchToModify.Contact_Person,
              Opening_Date: this.branchToModify.Opening_Date,
              Closing_Date: this.branchToModify.Closing_Date,
              Parent_BranchID: this.branchToModify.Parent_BranchID,
            }
          );
        }

      } else {
        this.toastr.error('Failed to load user', 'Error');
      }
    })
  }

  getLocationList() {
    this.locationService.getLocationList().subscribe((res: any) => {
      if (res.status === 200) {
        this.locationList = res.data;
      }
    })
  }
}
