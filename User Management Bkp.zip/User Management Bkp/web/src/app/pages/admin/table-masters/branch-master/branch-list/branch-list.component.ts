import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { BranchService } from 'src/app/services/admin/table-masters/branch.service';

@Component({
  selector: 'app-branch-list',
  templateUrl: './branch-list.component.html',
  styleUrls: ['./branch-list.component.css']
})
export class BranchListComponent implements OnInit {
  BranchList: any;
  constructor(private router: Router, private branchService: BranchService) { }

  ngOnInit(): void {
    this.getBranchList()
  }

  createNewBranch() {
    this.router.navigate(['/admin/dashboard/master/branch/create']);
  }

  getBranchList() {
    this.branchService.getBranchList().subscribe((res: any) => {
      this.BranchList = res.data
    })
  }

  modifyBranch(id: any) {
    this.router.navigate(['/admin/dashboard/master/branch/modify/' + id]);
  }
  toggleBranchActiveState(id: number, state: number) {
  }

}
