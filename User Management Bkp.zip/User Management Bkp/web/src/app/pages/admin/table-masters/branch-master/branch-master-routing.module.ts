import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { BranchCreateComponent } from './branch-create/branch-create.component';
import { BranchEditComponent } from './branch-edit/branch-edit.component';
import { BranchListComponent } from './branch-list/branch-list.component';

const routes: Routes = [
  { path: '', component: BranchListComponent },
  { path: 'create', component: BranchCreateComponent },
  { path: 'modify/:id', component: BranchEditComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class BranchMasterRoutingModule { }
