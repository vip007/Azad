import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { BranchMasterRoutingModule } from './branch-master-routing.module';
import { BranchListComponent } from './branch-list/branch-list.component';
import { BranchEditComponent } from './branch-edit/branch-edit.component';
import { BranchCreateComponent } from './branch-create/branch-create.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgxSpinnerModule } from 'ngx-spinner';


@NgModule({
  declarations: [
    BranchListComponent,
    BranchEditComponent,
    BranchCreateComponent
  ],
  imports: [
    CommonModule,
    BranchMasterRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    NgxSpinnerModule
  ]
})
export class BranchMasterModule { }
