import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DeptCreateComponent } from './dept-create.component';

describe('DeptCreateComponent', () => {
  let component: DeptCreateComponent;
  let fixture: ComponentFixture<DeptCreateComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DeptCreateComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DeptCreateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
