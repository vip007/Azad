import { DatePipe, Location } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { DepartmentService } from 'src/app/services/admin/table-masters/department.service';

@Component({
  selector: 'app-dept-create',
  templateUrl: './dept-create.component.html',
  styleUrls: ['./dept-create.component.css'],
  providers: [DatePipe]
})
export class DeptCreateComponent implements OnInit {

  createDepartmentForm!: FormGroup;
  currentUser: any;
  constructor(
    private _location: Location,
    private fb: FormBuilder,
    private datePipe: DatePipe,
    private departmentservice: DepartmentService,
    private toastr: ToastrService,
    private router: Router
  ) { }

  ngOnInit(): void {
    this.currentUser = JSON.parse(localStorage.getItem('currentUser') as string);
    this.currentUser = this.currentUser[0].UserName;

    this.createDepartmentForm = this.fb.group({
      Code: ['', Validators.required],
      Name: ['', Validators.required],
    })
  }

  addNewDepartment() {
    this.createDepartmentForm.value.createdOn = this.datePipe.transform(new Date(), 'yyyy-MM-dd');
    this.createDepartmentForm.value.createdby = this.currentUser
    this.departmentservice.createDepartment(this.createDepartmentForm.value).subscribe((res: any) => {
      if (res.status === 200) {
        this.toastr.success(res.message, 'Success');
        this.router.navigate(['/admin/dashboard/master/dept']);
      } else {
        this.toastr.warning(res.message, 'Warning');
      }
    }, (Error) => {
      this.toastr.error(Error.message, 'Error');
    });
  }

  newDepartmentSubmitHandler() {
    if (this.createDepartmentForm.valid) {
      this.addNewDepartment()
    }
  }

  backClicked() {
    this._location.back();
  }

}
