import { DatePipe, Location } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { DepartmentService } from 'src/app/services/admin/table-masters/department.service';

@Component({
  selector: 'app-dept-edit',
  templateUrl: './dept-edit.component.html',
  styleUrls: ['./dept-edit.component.css'],
  providers: [DatePipe]
})
export class DeptEditComponent implements OnInit {
  departmentToModify: any;
  departmentEditForm: any;
  currentUser: any;
  constructor(
    private _location: Location,
    private departmentService: DepartmentService,
    private toastr: ToastrService,
    private activatedroute: ActivatedRoute,
    private fb: FormBuilder,
    private datePipe: DatePipe,
    private router: Router
  ) { }

  ngOnInit(): void {
    this.currentUser = JSON.parse(localStorage.getItem('currentUser') as string);
    this.currentUser = this.currentUser[0].UserName;


    this.getDepartmenttoModify();

    this.departmentEditForm = this.fb.group({
      Code: ['', Validators.required],
      Name: ['', Validators.required],
    })
  }

  backClicked() {
    this._location.back();
  }

  getDepartmenttoModify() {
    this.departmentService.getDepartmentWithID(this.activatedroute.snapshot.paramMap.get("id")).subscribe((res: any) => {
      if (res.status === 200) {
        this.departmentToModify = res.data[0]
        if (this.departmentToModify) {
          console.log(this.departmentToModify)
          this.departmentEditForm.setValue(
            {
              Code: this.departmentToModify.Code,
              Name: this.departmentToModify.Name
            }
          );
        }
      } else {
        this.toastr.error('Failed to load user', 'Error');
      }
    })
  }

  modifyLocation() {
    this.departmentEditForm.value.ModifiedOn = this.datePipe.transform(new Date(), 'yyyy-MM-dd');
    this.departmentEditForm.value.ModifiedBy = this.currentUser
    this.departmentEditForm.value.ID_Department = this.activatedroute.snapshot.paramMap.get("id")
    this.departmentService.modifyDepartment(this.departmentEditForm.value).subscribe((res: any) => {
      if (res.status === 200) {
        this.toastr.success(res.message, 'Success');
        this.router.navigate(['/admin/dashboard/master/dept']);
      } else {
        this.toastr.warning(res.message, 'Warning');
      }
    }, (Error) => {
      this.toastr.error(Error.message, 'Error');
    });
  }

  editdepartmentSubmitHandler() {
    if (this.departmentEditForm.valid) {
      this.modifyLocation()
    }
  }
}
