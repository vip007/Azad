import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { DepartmentService } from 'src/app/services/admin/table-masters/department.service';

@Component({
  selector: 'app-dept-list',
  templateUrl: './dept-list.component.html',
  styleUrls: ['./dept-list.component.css']
})
export class DeptListComponent implements OnInit {
  DepartmentList: any;
  constructor(
    private router: Router,
    private departmentService: DepartmentService,
    private toastr: ToastrService
  ) { }

  ngOnInit(): void {
    this.getDepartmentList()
  }

  getDepartmentList() {
    this.departmentService.getDepartmentList().subscribe((res: any) => {
      this.DepartmentList = res.data
    })
  }

  createNewDepartment() {
    this.router.navigate(['/admin/dashboard/master/dept/create']);
  }

  modifyDepartment(id: any) {
    this.router.navigate(['/admin/dashboard/master/dept/modify/' + id]);
  }

  toggleDepartmentActiveState(id: number, state: number) {
    this.departmentService.toggleUserActiveState({ "ID_Department": id, "IsActive": state }).subscribe((res: any) => {
      if (res.status === 200) {
        this.getDepartmentList()
      } else {
        this.toastr.error(res.message, 'Error');
      }
    })
  }

}
