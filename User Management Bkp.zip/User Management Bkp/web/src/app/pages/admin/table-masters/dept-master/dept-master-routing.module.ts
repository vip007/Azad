import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DeptCreateComponent } from './dept-create/dept-create.component';
import { DeptEditComponent } from './dept-edit/dept-edit.component';
import { DeptListComponent } from './dept-list/dept-list.component';

const routes: Routes = [
  { path: '', component: DeptListComponent },
  { path: 'create', component: DeptCreateComponent },
  { path: 'modify/:id', component: DeptEditComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class DeptMasterRoutingModule { }
