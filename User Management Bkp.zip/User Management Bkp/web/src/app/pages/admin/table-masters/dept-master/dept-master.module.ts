import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { DeptMasterRoutingModule } from './dept-master-routing.module';
import { DeptListComponent } from './dept-list/dept-list.component';
import { DeptEditComponent } from './dept-edit/dept-edit.component';
import { DeptCreateComponent } from './dept-create/dept-create.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgxSpinnerModule } from 'ngx-spinner';


@NgModule({
  declarations: [
    DeptListComponent,
    DeptEditComponent,
    DeptCreateComponent
  ],
  imports: [
    CommonModule,
    DeptMasterRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    NgxSpinnerModule
  ]
})
export class DeptMasterModule { }
