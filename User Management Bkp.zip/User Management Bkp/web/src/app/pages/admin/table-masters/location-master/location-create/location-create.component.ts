import { DatePipe, Location } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { LocationService } from 'src/app/services/admin/table-masters/location.service';


@Component({
  selector: 'app-location-create',
  templateUrl: './location-create.component.html',
  styleUrls: ['./location-create.component.css'],
  providers: [DatePipe]
})
export class LocationCreateComponent implements OnInit {
  createLocationForm!: FormGroup;
  currentUser: any;
  constructor(
    private _location: Location,
    private fb: FormBuilder,
    private datePipe: DatePipe,
    private locationservice: LocationService,
    private toastr: ToastrService,
    private router: Router
  ) { }

  ngOnInit(): void {
    this.currentUser = JSON.parse(localStorage.getItem('currentUser') as string);
    this.currentUser = this.currentUser[0].UserName;

    this.createLocationForm = this.fb.group({
      LocationCode: ['', Validators.required],
      LocationName: ['', Validators.required],
      LoctionDescription: ['', Validators.required]
    })
  }

  addNewLocation() {
    this.createLocationForm.value.createdOn = this.datePipe.transform(new Date(), 'yyyy-MM-dd');
    this.createLocationForm.value.createdby = this.currentUser
    this.locationservice.createLocation(this.createLocationForm.value).subscribe((res: any) => {
      if (res.status === 200) {
        this.toastr.success(res.message, 'Success');
        this.router.navigate(['/admin/dashboard/master/location']);
      } else {
        this.toastr.warning(res.message, 'Warning');
      }
    }, (Error) => {
      this.toastr.error(Error.message, 'Error');
    });
  }

  newlocationSubmitHandler() {
    if (this.createLocationForm.valid) {
      this.addNewLocation()
    }
  }

  backClicked() {
    this._location.back();
  }

}
