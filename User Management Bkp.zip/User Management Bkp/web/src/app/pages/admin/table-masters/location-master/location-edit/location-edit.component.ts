import { DatePipe, Location } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { LocationService } from 'src/app/services/admin/table-masters/location.service';

@Component({
  selector: 'app-location-edit',
  templateUrl: './location-edit.component.html',
  styleUrls: ['./location-edit.component.css'],
  providers: [DatePipe]
})
export class LocationEditComponent implements OnInit {
  locationToModify: any;
  locationEditForm: any;
  currentUser: any;
  constructor(
    private _location: Location,
    private locationService: LocationService,
    private toastr: ToastrService,
    private activatedroute: ActivatedRoute,
    private fb: FormBuilder,
    private datePipe: DatePipe,
    private router: Router
  ) { }

  ngOnInit(): void {
    this.currentUser = JSON.parse(localStorage.getItem('currentUser') as string);
    this.currentUser = this.currentUser[0].UserName;


    this.getLocationtoModify();

    this.locationEditForm = this.fb.group({
      LocationCode: ['', Validators.required],
      LocationName: ['', Validators.required],
      LoctionDescription: ['', Validators.required],
    })
  }

  backClicked() {
    this._location.back();
  }

  getLocationtoModify() {
    this.locationService.getLocationWithID(this.activatedroute.snapshot.paramMap.get("id")).subscribe((res: any) => {
      if (res.status === 200) {
        this.locationToModify = res.data[0]
        if (this.locationToModify) {
          console.log(this.locationToModify)
          this.locationEditForm.setValue(
            {
              LocationCode: this.locationToModify.LocationCode,
              LocationName: this.locationToModify.LocationName,
              LoctionDescription: this.locationToModify.LoctionDescription,
            }
          );
        }
      } else {
        this.toastr.error('Failed to load user', 'Error');
      }
    })
  }

  modifyLocation() {
    this.locationEditForm.value.ModifiedOn = this.datePipe.transform(new Date(), 'yyyy-MM-dd');
    this.locationEditForm.value.ModifiedBy = this.currentUser
    this.locationEditForm.value.ID_Location = this.activatedroute.snapshot.paramMap.get("id")
    console.log(this.locationEditForm.value)
    this.locationService.modifyLocation(this.locationEditForm.value).subscribe((res: any) => {
      if (res.status === 200) {
        this.toastr.success(res.message, 'Success');
        this.router.navigate(['/admin/dashboard/master/location']);
      } else {
        this.toastr.warning(res.message, 'Warning');
      }
    }, (Error) => {
      this.toastr.error(Error.message, 'Error');
    });
  }

  editlocationSubmitHandler() {
    if (this.locationEditForm.valid) {
      this.modifyLocation()
    }
  }
}
