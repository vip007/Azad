import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { LocationService } from 'src/app/services/admin/table-masters/location.service';

@Component({
  selector: 'app-location-list',
  templateUrl: './location-list.component.html',
  styleUrls: ['./location-list.component.css']
})
export class LocationListComponent implements OnInit {
  LocationList: any;
  constructor(
    private router: Router,
    private locationService: LocationService,
    private toastr: ToastrService
  ) { }

  ngOnInit(): void {
    this.getLocationList()
  }

  getLocationList() {
    this.locationService.getLocationList().subscribe((res: any) => {
      this.LocationList = res.data
    })
  }

  createNewLocation() {
    this.router.navigate(['/admin/dashboard/master/location/create']);
  }

  modifyLocation(id: any) {
    this.router.navigate(['/admin/dashboard/master/location/modify/' + id]);
  }

  toggleLocationActiveState(id: number, state: number) {
    this.locationService.toggleUserActiveState({ "ID_Location": id, "IsActive": state }).subscribe((res: any) => {
      if (res.status === 200) {
        this.getLocationList()
      } else {
        this.toastr.error(res.message, 'Error');
      }
    })
  }

}
