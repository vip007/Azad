import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LocationCreateComponent } from './location-create/location-create.component';
import { LocationEditComponent } from './location-edit/location-edit.component';
import { LocationListComponent } from './location-list/location-list.component';

const routes: Routes = [
  { path: '', component: LocationListComponent },
  { path: 'create', component: LocationCreateComponent },
  { path: 'modify/:id', component: LocationEditComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class LocationMasterRoutingModule { }
