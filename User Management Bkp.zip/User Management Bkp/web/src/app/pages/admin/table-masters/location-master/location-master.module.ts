import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { LocationMasterRoutingModule } from './location-master-routing.module';
import { LocationListComponent } from './location-list/location-list.component';
import { LocationEditComponent } from './location-edit/location-edit.component';
import { LocationCreateComponent } from './location-create/location-create.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgxSpinnerModule } from 'ngx-spinner';


@NgModule({
  declarations: [
    LocationListComponent,
    LocationEditComponent,
    LocationCreateComponent
  ],
  imports: [
    CommonModule,
    LocationMasterRoutingModule, FormsModule,
    ReactiveFormsModule,
    NgxSpinnerModule
  ]
})
export class LocationMasterModule { }
