import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MenuEventCreateComponent } from './menu-event-create.component';

describe('MenuEventCreateComponent', () => {
  let component: MenuEventCreateComponent;
  let fixture: ComponentFixture<MenuEventCreateComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MenuEventCreateComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MenuEventCreateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
