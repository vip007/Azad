import { Location } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { DatePipe } from '@angular/common';
import { ToastrService } from 'ngx-toastr';
import { MenuEventService } from 'src/app/services/admin/table-masters/menuevent.service';
import { MenuService } from 'src/app/services/admin/table-masters/menu.service';

@Component({
  selector: 'app-menu-event-create',
  templateUrl: './menu-event-create.component.html',
  styleUrls: ['./menu-event-create.component.css'],
  providers: [DatePipe]
})
export class MenuEventCreateComponent implements OnInit {
  createMenuEvent!: FormGroup;
  currentUser: any;
  MenuList: any;
  constructor(
    private _location: Location,
    private fb: FormBuilder,
    private toastr: ToastrService,
    private router: Router,
    private datePipe: DatePipe,
    private menuEventService: MenuEventService,
    private menuService: MenuService,
  ) { }

  ngOnInit(): void {
    this.currentUser = JSON.parse(localStorage.getItem('currentUser') as string);
    this.currentUser = this.currentUser[0].UserName;

    this.getMenuList()

    this.createMenuEvent = this.fb.group({
      MenuEventCode: ['', Validators.required],
      MenuEventName: ['', Validators.required],
      Description: ['', Validators.required],
      ID_Menu: ['', Validators.required],
    })
  }

  createNewMenuEvent() {

    this.createMenuEvent.value.createdOn = this.datePipe.transform(new Date(), 'yyyy-MM-dd');
    this.createMenuEvent.value.createdby = this.currentUser
    this.menuEventService.createNewMenuEvent(this.createMenuEvent.value).subscribe((data: any) => {
      if (data.status === 200) {
        this.toastr.success(data.message, 'Success');
        this.router.navigate(['/admin/dashboard/master/menu-event']);
      } else {
        this.toastr.warning(data.message, 'Warning');
      }
    }, (Error: { message: string | undefined; }) => {
      this.toastr.error(Error.message, 'Error');
    });
  }

  backClicked() {
    this._location.back();
  }

  getMenuList() {
    this.menuService.getMenuList().subscribe((res: any) => {
      if (res.status === 200) {
        this.MenuList = res.data
      }
    })
  }



}
