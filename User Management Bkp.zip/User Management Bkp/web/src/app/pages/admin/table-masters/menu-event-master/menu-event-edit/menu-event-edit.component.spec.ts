import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MenuEventEditComponent } from './menu-event-edit.component';

describe('MenuEventEditComponent', () => {
  let component: MenuEventEditComponent;
  let fixture: ComponentFixture<MenuEventEditComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MenuEventEditComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MenuEventEditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
