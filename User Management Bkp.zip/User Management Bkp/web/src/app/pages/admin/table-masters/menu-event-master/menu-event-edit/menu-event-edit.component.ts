import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-menu-event-edit',
  templateUrl: './menu-event-edit.component.html',
  styleUrls: ['./menu-event-edit.component.css']
})
export class MenuEventEditComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
