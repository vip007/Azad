import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MenuEventListComponent } from './menu-event-list.component';

describe('MenuEventListComponent', () => {
  let component: MenuEventListComponent;
  let fixture: ComponentFixture<MenuEventListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MenuEventListComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MenuEventListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
