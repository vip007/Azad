import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { MenuEventService } from 'src/app/services/admin/table-masters/menuevent.service';

@Component({
  selector: 'app-menu-event-list',
  templateUrl: './menu-event-list.component.html',
  styleUrls: ['./menu-event-list.component.css']
})
export class MenuEventListComponent implements OnInit {
  MenuEventList!: any;
  p: number = 1;

  MenuEvents = [
    { name: 'View', value: 'View' },
    { name: 'Edit', value: 'Edit' },
    { name: 'Save', value: 'Save' },
    { name: 'Upload', value: 'Upload' },
  ]

  constructor(
    private menuEventService: MenuEventService,
    private toastr: ToastrService,
    private router: Router
  ) { }

  ngOnInit(): void {
    this.getMenuEventList()
  }

  getMenuEventList() {
    this.menuEventService.MenuEventList().subscribe((res: any) => {
      this.MenuEventList = res.data
    })
  }



  createNewMenuEvent() {
    this.router.navigate(['/admin/dashboard/master/menu-event/create']);
  }

  modifyMenuEvent(id: number) {
    this.router.navigate(['/admin/dashboard/master/menu-event/modify/' + id]);
  }

  removeMenuEvent(id: any) {
    this.menuEventService.MenuEventRemove({ "ID_MenuEvent": id }).subscribe((res: any) => {
      if (res.status === 200) {
        this.getMenuEventList()
      }
    })
  }


}
