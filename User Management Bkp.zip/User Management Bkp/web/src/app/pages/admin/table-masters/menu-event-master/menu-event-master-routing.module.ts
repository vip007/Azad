import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MenuEventCreateComponent } from './menu-event-create/menu-event-create.component';
import { MenuEventEditComponent } from './menu-event-edit/menu-event-edit.component';
import { MenuEventListComponent } from './menu-event-list/menu-event-list.component';

const routes: Routes = [
  { path: '', component: MenuEventListComponent },
  { path: 'create', component: MenuEventCreateComponent },
  { path: 'modify/:id', component: MenuEventEditComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class MenuEventMasterRoutingModule { }
