import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { MenuEventMasterRoutingModule } from './menu-event-master-routing.module';
import { MenuEventListComponent } from './menu-event-list/menu-event-list.component';
import { MenuEventEditComponent } from './menu-event-edit/menu-event-edit.component';
import { MenuEventCreateComponent } from './menu-event-create/menu-event-create.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgxPaginationModule } from 'ngx-pagination';

@NgModule({
  declarations: [
    MenuEventListComponent,
    MenuEventEditComponent,
    MenuEventCreateComponent
  ],
  imports: [
    CommonModule,
    MenuEventMasterRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    NgxPaginationModule
  ]
})
export class MenuEventMasterModule { }
