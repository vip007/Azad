import { DatePipe, Location } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { ApplicationService } from 'src/app/services/admin/table-masters/application.service';
import { MenuService } from 'src/app/services/admin/table-masters/menu.service';

@Component({
  selector: 'app-menu-create',
  templateUrl: './menu-create.component.html',
  styleUrls: ['./menu-create.component.css'],
  providers: [DatePipe]
})
export class MenuCreateComponent implements OnInit {
  createMenuForm!: FormGroup;
  currentUser: any;
  applicationList: any;
  menuList: any;
  constructor(
    private _location: Location,
    private fb: FormBuilder,
    private datePipe: DatePipe,
    private menuservice: MenuService,
    private toastr: ToastrService,
    private router: Router,
    private applicationService: ApplicationService,
  ) { }

  ngOnInit(): void {
    this.currentUser = JSON.parse(localStorage.getItem('currentUser') as string);
    this.currentUser = this.currentUser[0].UserName;

    this.getApplicationList()
    this.getMenuList()

    this.createMenuForm = this.fb.group({
      MenuCode: ['', Validators.required],
      MenuName: ['', Validators.required],
      Description: ['', Validators.required],
      ID_Application: ['', Validators.required],
      ID_Menu_Parent: [''],
    })
  }

  addNewMenu() {
    this.createMenuForm.value.createdOn = this.datePipe.transform(new Date(), 'yyyy-MM-dd');
    this.createMenuForm.value.createdby = this.currentUser

    if (this.createMenuForm.value.ID_Menu_Parent == "") {
      this.createMenuForm.value.ID_Menu_Parent = 0
    }

    this.menuservice.createMenu(this.createMenuForm.value).subscribe((res: any) => {
      if (res.status === 200) {
        this.toastr.success(res.message, 'Success');
        this.router.navigate(['/admin/dashboard/master/menu']);
      } else {
        this.toastr.warning(res.message, 'Warning');
      }
    }, (Error) => {
      this.toastr.error(Error.message, 'Error');
    });
  }

  newmenuSubmitHandler() {
    if (this.createMenuForm.valid) {
      this.addNewMenu()
    }
  }

  backClicked() {
    this._location.back();
  }

  getApplicationList() {
    this.applicationService.getApplicationList().subscribe((res: any) => {
      if (res.status === 200) {
        this.applicationList = res.data;
      }
    })
  }

  getMenuList() {
    this.menuservice.getMenuList().subscribe((res: any) => {
      if (res.status === 200) {
        this.menuList = res.data;
      }
    })
  }
}
