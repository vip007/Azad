import { DatePipe, Location } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { ApplicationService } from 'src/app/services/admin/table-masters/application.service';
import { MenuService } from 'src/app/services/admin/table-masters/menu.service';

@Component({
  selector: 'app-menu-edit',
  templateUrl: './menu-edit.component.html',
  styleUrls: ['./menu-edit.component.css'],
  providers: [DatePipe]
})
export class MenuEditComponent implements OnInit {

  menuToModify: any;
  menuEditForm: any;
  currentUser: any;
  applicationList: any;
  menuList: any;
  constructor(
    private _location: Location,
    private menuService: MenuService,
    private toastr: ToastrService,
    private activatedroute: ActivatedRoute,
    private fb: FormBuilder,
    private datePipe: DatePipe,
    private router: Router,
    private applicationService: ApplicationService,

  ) { }

  ngOnInit(): void {
    this.currentUser = JSON.parse(localStorage.getItem('currentUser') as string);
    this.currentUser = this.currentUser[0].UserName;


    this.getApplicationList()
    this.getMenuList()
    this.getMenutoModify();

    this.menuEditForm = this.fb.group({
      MenuCode: ['', Validators.required],
      MenuName: ['', Validators.required],
      Description: ['', Validators.required],
      ID_Application: ['', Validators.required],
      ID_Menu_Parent: [''],
    })
  }

  backClicked() {
    this._location.back();
  }

  getMenutoModify() {
    this.menuService.getMenuWithID(this.activatedroute.snapshot.paramMap.get("id")).subscribe((res: any) => {
      if (res.status === 200) {
        this.menuToModify = res.data[0]
        if (this.menuToModify) {
          this.menuEditForm.setValue(
            {
              MenuCode: this.menuToModify.MenuCode,
              MenuName: this.menuToModify.MenuName,
              Description: this.menuToModify.Description,
              ID_Application: this.menuToModify.ID_Application,
              ID_Menu_Parent: this.menuToModify.ID_Menu_Parent,
            }
          );
        }
      } else {
        this.toastr.error('Failed to load user', 'Error');
      }
    })
  }

  modifyMenu() {
    this.menuEditForm.value.ModifiedOn = this.datePipe.transform(new Date(), 'yyyy-MM-dd');
    this.menuEditForm.value.ModifiedBy = this.currentUser

    if (this.menuEditForm.value.ID_Menu_Parent == "") {
      this.menuEditForm.value.ID_Menu_Parent = 0
    }

    this.menuEditForm.value.ID_Menu = this.activatedroute.snapshot.paramMap.get("id")
    this.menuService.modifyMenu(this.menuEditForm.value).subscribe((res: any) => {
      if (res.status === 200) {
        this.toastr.success(res.message, 'Success');
        this.router.navigate(['/admin/dashboard/master/menu']);
      } else {
        this.toastr.warning(res.message, 'Warning');
      }
    }, (Error) => {
      this.toastr.error(Error.message, 'Error');
    });
  }

  editmenuSubmitHandler() {
    if (this.menuEditForm.valid) {
      this.modifyMenu()
    }
  }

  getApplicationList() {
    this.applicationService.getApplicationList().subscribe((res: any) => {
      if (res.status === 200) {
        this.applicationList = res.data;
      }
    })
  }

  getMenuList() {
    this.menuService.getMenuList().subscribe((res: any) => {
      if (res.status === 200) {
        this.menuList = res.data;
      }
    })
  }
}
