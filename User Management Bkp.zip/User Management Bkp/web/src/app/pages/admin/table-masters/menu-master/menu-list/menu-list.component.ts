import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { MenuService } from 'src/app/services/admin/table-masters/menu.service';

@Component({
  selector: 'app-menu-list',
  templateUrl: './menu-list.component.html',
  styleUrls: ['./menu-list.component.css']
})
export class MenuListComponent implements OnInit {
  MenuList: any;
  p: number = 1;
  constructor(
    private router: Router,
    private menuService: MenuService,
    private toastr: ToastrService
  ) { }

  ngOnInit(): void {
    this.getMenuList()
  }

  getMenuList() {
    this.menuService.getMenuList().subscribe((res: any) => {
      this.MenuList = res.data
    })
  }

  createNewMenu() {
    this.router.navigate(['/admin/dashboard/master/menu/create']);
  }

  modifyMenu(id: any) {
    this.router.navigate(['/admin/dashboard/master/menu/modify/' + id]);
  }

  toggleMenuActiveState(id: number, state: number) {
    this.menuService.toggleUserActiveState({ "ID_Menu": id, "IsActive": state }).subscribe((res: any) => {
      if (res.status === 200) {
        this.getMenuList()
      } else {
        this.toastr.error(res.message, 'Error');
      }
    })
  }
}
