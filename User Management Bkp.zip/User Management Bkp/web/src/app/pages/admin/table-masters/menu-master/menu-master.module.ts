import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { MenuMasterRoutingModule } from './menu-master-routing.module';
import { MenuListComponent } from './menu-list/menu-list.component';
import { MenuEditComponent } from './menu-edit/menu-edit.component';
import { MenuCreateComponent } from './menu-create/menu-create.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgxSpinnerModule } from 'ngx-spinner';
import { NgxPaginationModule } from 'ngx-pagination';

@NgModule({
  declarations: [
    MenuListComponent,
    MenuEditComponent,
    MenuCreateComponent
  ],
  imports: [
    CommonModule,
    MenuMasterRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    NgxSpinnerModule,
    NgxPaginationModule
  ]
})
export class MenuMasterModule { }
