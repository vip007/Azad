import { Location } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { DatePipe } from '@angular/common';
import { ToastrService } from 'ngx-toastr';
import { ProductService } from 'src/app/services/admin/table-masters/product.service';
import { ApplicationService } from 'src/app/services/admin/table-masters/application.service';

@Component({
  selector: 'app-product-create',
  templateUrl: './product-create.component.html',
  styleUrls: ['./product-create.component.css'],
  providers: [DatePipe]
})
export class ProductCreateComponent implements OnInit {
  createProductForm!: FormGroup;
  currentUser: any;
  applicationList: any;
  constructor(
    private _location: Location,
    private fb: FormBuilder,
    private toastr: ToastrService,
    private router: Router,
    private datePipe: DatePipe,
    private productService: ProductService,
    private applicationService: ApplicationService
  ) { }

  ngOnInit(): void {
    this.currentUser = JSON.parse(localStorage.getItem('currentUser') as string);
    this.currentUser = this.currentUser[0].UserName;
    this.getApplicationList()
    this.createProductForm = this.fb.group({
      ProductCode: ['', Validators.required],
      ProductName: ['', Validators.required],
      Description: ['', Validators.required],
      ID_Application: ['', Validators.required],

    })
  }

  createNewProduct() {

    this.createProductForm.value.createdOn = this.datePipe.transform(new Date(), 'yyyy-MM-dd');
    this.createProductForm.value.createdby = this.currentUser
    this.productService.createNewProduct(this.createProductForm.value).subscribe((data: any) => {
      if (data.status === 200) {
        this.toastr.success(data.message, 'Success');
        this.router.navigate(['/admin/dashboard/master/product']);
      } else {
        this.toastr.warning(data.message, 'Warning');
      }
    }, (Error: { message: string | undefined; }) => {
      this.toastr.error(Error.message, 'Error');
    });
  }

  backClicked() {
    this._location.back();
  }

  getApplicationList() {
    this.applicationService.getApplicationList().subscribe((res: any) => {
      if (res.status === 200) {
        this.applicationList = res.data;
      }
    })
  }

}
