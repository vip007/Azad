import { DatePipe, Location } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { ApplicationService } from 'src/app/services/admin/table-masters/application.service';

import { ProductService } from 'src/app/services/admin/table-masters/product.service';

@Component({
  selector: 'app-product-edit',
  templateUrl: './product-edit.component.html',
  styleUrls: ['./product-edit.component.css'],
  providers: [DatePipe]
})
export class ProductEditComponent implements OnInit {
  appToModify: any;
  modifyAppForm!: any;
  currentUser: any;
  applicationList: any;
  constructor(
    private _location: Location,
    private toastr: ToastrService,
    private productService: ProductService,
    private activatedroute: ActivatedRoute,
    private fb: FormBuilder,
    private datePipe: DatePipe,
    private router: Router,
    private applicationService: ApplicationService,
  ) { }

  ngOnInit(): void {
    this.getUsertoModify()
    this.getApplicationList()
    this.currentUser = JSON.parse(localStorage.getItem('currentUser') as string);
    this.currentUser = this.currentUser[0].UserName;

    this.modifyAppForm = this.fb.group({
      ProductCode: ['', Validators.required],
      ProductName: ['', Validators.required],
      Description: ['', Validators.required],
      ID_Application: ['', Validators.required],
    })
  }

  backClicked() {
    this._location.back();
  }

  modifyProduct() {
    this.modifyAppForm.value.ModifiedOn = this.datePipe.transform(new Date(), 'yyyy-MM-dd');
    this.modifyAppForm.value.ModifiedBy = this.currentUser;
    this.modifyAppForm.value.ID_Product = this.activatedroute.snapshot.paramMap.get("id");
    this.productService.modifyProduct(this.modifyAppForm.value).subscribe((data: any) => {
      if (data.status === 200) {
        this.toastr.success(data.message, 'Success');
        this.router.navigate(['/admin/dashboard/master/product']);

      } else {
        this.toastr.error(data.message, 'Error');
      }
    });
  }

  submitModifyProductForm() {
    if (this.modifyAppForm.touched) {
      if (this.modifyAppForm.invalid) {
        this.toastr.error('Form is invalid, Please try again with all valid values', 'Error');
      } else {
        this.modifyProduct()
      }
    } else {
      this.toastr.info('Press cancel to go back to users list', 'No changes made');
    }
  }

  getUsertoModify() {
    this.productService.ProductWithID(this.activatedroute.snapshot.paramMap.get("id")).subscribe((res: any) => {
      if (res.status === 200) {
        this.appToModify = res.data[0]
        if (this.appToModify) {
          this.modifyAppForm.setValue(
            {
              ProductCode: this.appToModify.ProductCode,
              ProductName: this.appToModify.ProductName,
              Description: this.appToModify.Description,
              ID_Application: this.appToModify.ID_Application
            }
          );
        }

      } else {
        this.toastr.error(res.message, 'Error');
      }
    })
  }

  getApplicationList() {
    this.applicationService.getApplicationList().subscribe((res: any) => {
      if (res.status === 200) {
        this.applicationList = res.data;
      }
    })
  }

}
