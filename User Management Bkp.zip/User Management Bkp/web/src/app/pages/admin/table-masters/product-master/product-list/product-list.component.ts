import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ProductService } from 'src/app/services/admin/table-masters/product.service';

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent implements OnInit {
  ProductList: any;
  p: number = 1;
  constructor(private productService: ProductService, private router: Router) {


  }

  ngOnInit(): void {
    this.getProductList();
  }
  createNewProduct() {
    this.router.navigate(['/admin/dashboard/master/product/create']);
  }
  modifyProduct(id: any) {
    this.router.navigate(['/admin/dashboard/master/product/modify/' + id]);
  }
  toggleProductActiveState(id: any, state: any) {
    this.productService.toggleProductState({ "ID_Product": id, "IsActive": state }).subscribe((res: any) => {

      if (res.status === 200) {
        this.getProductList()
      }
    })
  }

  getProductList() {
    this.productService.getProductList().subscribe((res: any) => {
      if (res.status === 200) {
        this.ProductList = res.data
      }
    })
  }

}
