import { DatePipe, Location } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { RoleService } from 'src/app/services/admin/table-masters/role.service';

@Component({
  selector: 'app-role-create',
  templateUrl: './role-create.component.html',
  styleUrls: ['./role-create.component.css'],
  providers: [DatePipe]
})
export class RoleCreateComponent implements OnInit {
  createRoleForm!: FormGroup;
  currentUser: any;
  constructor(
    private _location: Location,
    private fb: FormBuilder,
    private toastr: ToastrService,
    private router: Router,
    private roleService: RoleService,
    private datePipe: DatePipe,
  ) { }

  ngOnInit(): void {

    this.currentUser = JSON.parse(localStorage.getItem('currentUser') as string);
    this.currentUser = this.currentUser[0].UserName;

    this.createRoleForm = this.fb.group({
      Code: ['', Validators.required],
      Name: ['', Validators.required],
      Description: ['', Validators.required],
    })
  }

  backClicked() {
    this._location.back();
  }

  createNewRole() {
    if (this.createRoleForm.valid) {
      this.submitRoleForm()
    }
  }

  submitRoleForm() {
    this.createRoleForm.value.createdOn = this.datePipe.transform(new Date(), 'yyyy-MM-dd');
    this.createRoleForm.value.createdby = this.currentUser
    this.roleService.createNewRole(this.createRoleForm.value).subscribe((data: any) => {
      if (data.status === 200) {
        this.toastr.success(data.message, 'Success');
        this.router.navigate(['/admin/dashboard/master/role']);
      } else {
        this.toastr.warning(data.message, 'Warning');
      }
    }, (Error) => {
      this.toastr.error(Error.message, 'Error');
    });
  }


}
