import { DatePipe, Location } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { RoleService } from 'src/app/services/admin/table-masters/role.service';

@Component({
  selector: 'app-role-edit',
  templateUrl: './role-edit.component.html',
  styleUrls: ['./role-edit.component.css'],
  providers: [DatePipe]
})
export class RoleEditComponent implements OnInit {
  modifyRoleForm!: FormGroup
  roleToModify: any;
  currentUser: any;
  constructor(
    private _location: Location,
    private fb: FormBuilder,
    private toastr: ToastrService,
    private router: Router,
    private roleService: RoleService,
    private datePipe: DatePipe,
    private activatedroute: ActivatedRoute,
  ) { }

  ngOnInit(): void {

    this.currentUser = JSON.parse(localStorage.getItem('currentUser') as string);
    this.currentUser = this.currentUser[0].UserName;

    this.modifyRoleForm = this.fb.group({
      Code: ['', Validators.required],
      Name: ['', Validators.required],
      Description: ['', Validators.required],
    })

    this.getRoletoModify()
  }

  backClicked() {
    this._location.back();
  }

  ModifyRole() {
    this.modifyRoleForm.value.ModifiedOn = this.datePipe.transform(new Date(), 'yyyy-MM-dd');
    this.modifyRoleForm.value.ModifiedBy = this.currentUser;
    this.modifyRoleForm.value.ID_Role = this.activatedroute.snapshot.paramMap.get("id");
    this.roleService.modifyRole(this.modifyRoleForm.value).subscribe((data: any) => {
      if (data.status === 200) {
        this.toastr.success(data.message, 'Success');
        this.router.navigate(['/admin/dashboard/master/role']);
      } else {
        this.toastr.error(data.message, 'Error');
      }
    });
  }

  getRoletoModify() {
    this.roleService.getRoleWithID(this.activatedroute.snapshot.paramMap.get("id")).subscribe((res: any) => {
      if (res.status === 200) {
        this.roleToModify = res.data[0]
        if (this.roleToModify) {
          this.modifyRoleForm.setValue(
            {
              Code: this.roleToModify.Code,
              Name: this.roleToModify.Name,
              Description: this.roleToModify.Description,
            }
          );
        }

      } else {
        this.toastr.error('Failed to load user', 'Error');
      }
    })
  }

  submitModifyRoleForm() {
    if (this.modifyRoleForm.touched) {
      if (this.modifyRoleForm.invalid) {
        this.toastr.error('Form is invalid, Please try again with all valid values', 'Error');
      } else {
        this.ModifyRole()
      }
    } else {
      this.toastr.info('Press cancel to go back to users list', 'No changes made');
    }
  }

}
