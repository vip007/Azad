import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { RoleService } from 'src/app/services/admin/table-masters/role.service';

@Component({
  selector: 'app-role-list',
  templateUrl: './role-list.component.html',
  styleUrls: ['./role-list.component.css']
})
export class RoleListComponent implements OnInit {
  roleList: any;
  constructor(
    private router: Router,
    private roleService: RoleService,
  ) { }

  ngOnInit(): void {
    this.getRoleList()
  }

  createNewRole() {
    this.router.navigate(['/admin/dashboard/master/role/create']);
  }

  getRoleList() {
    this.roleService.getRoleList().subscribe((res: any) => {
      this.roleList = res.data
    })
  }

  modifyRole(id: number) {
    this.router.navigate(['/admin/dashboard/master/role/modify/' + id]);
  }

  toggleRoleActiveState(id: number, state: number) {
    this.roleService.toggleRoleActiveState({ "ID_Role": id, "IsActive": state }).subscribe((res: any) => {
      if (res.status === 200) {
        this.getRoleList()
      }
    })
  }
}
