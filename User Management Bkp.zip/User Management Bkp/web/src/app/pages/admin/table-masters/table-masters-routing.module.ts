import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuard } from 'src/app/services/guards/auth.guard';

const routes: Routes = [
  {
    path: 'users', canActivate: [AuthGuard],
    loadChildren: () =>
      import('./user-list/user-list.module').then(
        (m) => m.UserListModule
      ),
  },
  {
    path: 'applications', canActivate: [AuthGuard],
    loadChildren: () =>
      import('./application-master/application-master.module').then(
        (m) => m.ApplicationMasterModule
      ),
  },
  {
    path: 'role', canActivate: [AuthGuard],
    loadChildren: () =>
      import('./role-master/role-master.module').then(
        (m) => m.RoleMasterModule
      ),
  },
  {
    path: 'location', canActivate: [AuthGuard],
    loadChildren: () =>
      import('./location-master/location-master.module').then(
        (m) => m.LocationMasterModule
      ),
  },
  {
    path: 'branch', canActivate: [AuthGuard],
    loadChildren: () =>
      import('./branch-master/branch-master.module').then(
        (m) => m.BranchMasterModule
      ),
  },
  {
    path: 'usertype', canActivate: [AuthGuard],
    loadChildren: () =>
      import('./usertype-mater/usertype-mater.module').then(
        (m) => m.UsertypeMaterModule
      ),
  },
  {
    path: 'menu', canActivate: [AuthGuard],
    loadChildren: () =>
      import('./menu-master/menu-master.module').then(
        (m) => m.MenuMasterModule
      ),
  },
  {
    path: 'dept', canActivate: [AuthGuard],
    loadChildren: () =>
      import('./dept-master/dept-master.module').then(
        (m) => m.DeptMasterModule
      ),
  },
  {
    path: 'product', canActivate: [AuthGuard],
    loadChildren: () =>
      import('./product-master/product-master.module').then(
        (m) => m.ProductMasterModule
      ),
  },
  {
    path: 'menu-event', canActivate: [AuthGuard],
    loadChildren: () =>
      import('./menu-event-master/menu-event-master.module').then(
        (m) => m.MenuEventMasterModule
      ),
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class TableMastersRoutingModule { }
