import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { TableMastersRoutingModule } from './table-masters-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    TableMastersRoutingModule
  ]
})
export class TableMastersModule { }
