import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { UserListRoutingModule } from './user-list-routing.module';

import { UsersTableComponent } from './users-table/users-table.component';
import { UsersCreateComponent } from './users-create/users-create.component';
import { UsersModifyComponent } from './users-modify/users-modify.component';

import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgxSpinnerModule } from 'ngx-spinner';
import { NgxPaginationModule } from 'ngx-pagination';

import { Ng2SearchPipeModule } from 'ng2-search-filter';

@NgModule({
  declarations: [
    UsersTableComponent,
    UsersCreateComponent,
    UsersModifyComponent,
  ],
  imports: [
    CommonModule,
    UserListRoutingModule, FormsModule, ReactiveFormsModule, NgxSpinnerModule, NgxPaginationModule, Ng2SearchPipeModule
  ]
})
export class UserListModule { }
