import { Component, OnInit } from '@angular/core';
import { Location } from '@angular/common';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { DatePipe } from '@angular/common';
import { UsersService } from 'src/app/services/admin/table-masters/users.service';
import { ToastrService } from 'ngx-toastr';
import { Router } from '@angular/router';

@Component({
  selector: 'app-users-create',
  templateUrl: './users-create.component.html',
  styleUrls: ['./users-create.component.css'],
  providers: [DatePipe]
})
export class UsersCreateComponent implements OnInit {
  createUserForm!: FormGroup;
  usertypes: any;
  currentUser: any;


  constructor(
    private _location: Location,
    private fb: FormBuilder,
    private datePipe: DatePipe,
    private usersService: UsersService,
    private toastr: ToastrService,
    private router: Router,
  ) {
  }

  ngOnInit(): void {

    this.getUserTypes()

    this.currentUser = JSON.parse(localStorage.getItem('currentUser') as string);
    this.currentUser = this.currentUser[0].UserName;
    this.createUserForm = this.fb.group({
      username: ['', Validators.required],
      password: ['', Validators.required],
      code: ['', Validators.required],
      usertype: ['', Validators.required],
      isChecker: ['', Validators.required],
      isMaker: ['', Validators.required]
    })

  }

  get createUserFormControl() {
    return this.createUserForm.controls;
  }

  createNewUser() {
    this.createUserForm.value.createdOn = this.datePipe.transform(new Date(), 'yyyy-MM-dd');
    this.createUserForm.value.createdby = this.currentUser
    this.usersService.createNewUser(this.createUserForm.value).subscribe((data: any) => {
      if (data.status === 200) {
        this.toastr.success('User Created succesfully', 'Success');
        this.router.navigate(['/admin/dashboard/master/users']);
      } else {
        this.toastr.warning(data.message, 'Warning');
      }
    }, (Error) => {
      this.toastr.error(Error.message, 'Error');
    });
  }



  backClicked() {
    this._location.back();
  }

  getUserTypes() {
    this.usersService.getUserTypes().subscribe((res: any) => {
      if (res.status === 200) {
        this.usertypes = res.data;
      }
    })
  }

}
