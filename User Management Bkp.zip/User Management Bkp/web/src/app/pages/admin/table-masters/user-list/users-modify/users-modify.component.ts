import { Component, OnInit } from '@angular/core';
import { Location } from '@angular/common';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { DatePipe } from '@angular/common';
import { UsersService } from 'src/app/services/admin/table-masters/users.service';
import { ToastrService } from 'ngx-toastr';
import { Router } from '@angular/router';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-users-modify',
  templateUrl: './users-modify.component.html',
  styleUrls: ['./users-modify.component.css'],
  providers: [DatePipe]
})
export class UsersModifyComponent implements OnInit {
  currentUser: any;
  userToModify: any;
  modifyUserForm!: FormGroup;
  usertypes: any;

  constructor(
    private _location: Location,
    private fb: FormBuilder,
    private datePipe: DatePipe,
    private usersService: UsersService,
    private toastr: ToastrService,
    private router: Router,
    private activatedroute: ActivatedRoute
  ) {
  }

  ngOnInit(): void {

    this.currentUser = JSON.parse(localStorage.getItem('currentUser') as string);
    this.currentUser = this.currentUser[0].UserName;

    this.getUsertoModify()
    this.getUserTypes()
    this.modifyUserForm = this.fb.group({
      username: ['', Validators.required],
      password: ['', Validators.required],
      code: ['', Validators.required],
      usertype: ['', Validators.required],
      isChecker: ['', Validators.required],
      isMaker: ['', Validators.required]
    })
  }

  get modifyUserFormControl() {
    return this.modifyUserForm.controls;
  }

  modifyUser() {
    this.modifyUserForm.value.modifiedOn = this.datePipe.transform(new Date(), 'yyyy-MM-dd');
    this.modifyUserForm.value.modifiedBy = this.currentUser;
    this.modifyUserForm.value.userid = this.activatedroute.snapshot.paramMap.get("id");
    this.usersService.modifyUser(this.modifyUserForm.value).subscribe((data: any) => {
      if (data.status === 200) {
        this.toastr.success('User was modified succesfully', 'Success');
        this.router.navigate(['/admin/dashboard/master/users']);
      } else {
        this.toastr.error(data.message, 'Error');
      }
    });
  }

  getUsertoModify() {
    this.usersService.getUserWithId({ "userid": this.activatedroute.snapshot.paramMap.get("id") }).subscribe((res: any) => {
      if (res.status === 200) {
        this.userToModify = res.data[0]

        if (this.userToModify) {
          this.modifyUserForm.setValue(
            {
              username: this.userToModify.UserName,
              password: this.userToModify.UserPass,
              code: this.userToModify.Code,
              usertype: this.userToModify.ID_UserType,
              isChecker: this.userToModify.IsChecker ? 1 : 0,
              isMaker: this.userToModify.IsMaker ? 1 : 0,
            }
          );
        }

      } else {
        this.toastr.error('Failed to load user', 'Error');
      }
    })
  }

  backClicked() {
    this._location.back();
  }

  submitModifyUserForm() {
    if (this.modifyUserForm.touched) {
      if (this.modifyUserForm.invalid) {
        this.toastr.error('Form is invalid, Please try again with all valid values', 'Error');
      } else {
        this.modifyUser()
      }
    } else {
      this.toastr.info('Press cancel to go back to users list', 'No changes made');
    }
  }

  getUserTypes() {
    this.usersService.getUserTypes().subscribe((res: any) => {
      if (res.status === 200) {
        this.usertypes = res.data;
      }
    })
  }

}
