import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { ToastrService } from 'ngx-toastr';
import { UsersService } from 'src/app/services/admin/table-masters/users.service';


@Component({
  selector: 'app-users-table',
  templateUrl: './users-table.component.html',
  styleUrls: ['./users-table.component.css']
})
export class UsersTableComponent implements OnInit {
  UsersList: any = [];
  searchForm!: FormGroup;
  p: number = 1;
  searchText: any
  constructor(
    private usersService: UsersService,
    private router: Router,
    private toastr: ToastrService,
    private spinner: NgxSpinnerService,
    private fb: FormBuilder,
  ) { }

  ngOnInit(): void {
    this.spinner.show();
    this.getUsersList();

    this.searchForm = this.fb.group({
      Username: ['', Validators.required]
    })
  }

  createNewUser() {
    this.router.navigate(['/admin/dashboard/master/users/create']);
  }

  modifyUser(id: any) {
    this.router.navigate(['/admin/dashboard/master/users/modify/' + id]);
  }

  getUsersList() {
    this.usersService.getUsersListData().subscribe((res: any) => {
      this.UsersList = res.data
      this.spinner.hide();
    }, err => {
      this.toastr.error(err.message, 'Error');
      this.spinner.hide();
    });

  }

  toggleUserActiveState(id: number, state: number) {
    this.usersService.toggleUserActiveState({ "userid": id, "isActive": state }).subscribe((data: any) => {
      this.getUsersList()
    });
  }

  // searchByName() {
  //   if (this.searchForm.valid) {
  //     console.log(this.searchForm.value)
  //     this.usersService.searchUserLike(this.searchForm.value).subscribe((res: any) => {
  //       // console.log(res.data)
  //       this.UsersList = res.data
  //     });
  //   }
  //   this.searchForm.reset()
  // }


  refreshList() {
    this.getUsersList();
  }
}
