import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UsertypeCreateComponent } from './usertype-create.component';

describe('UsertypeCreateComponent', () => {
  let component: UsertypeCreateComponent;
  let fixture: ComponentFixture<UsertypeCreateComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UsertypeCreateComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UsertypeCreateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
