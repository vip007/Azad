import { DatePipe, Location } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { UsertypeService } from 'src/app/services/admin/table-masters/usertype.service';

@Component({
  selector: 'app-usertype-create',
  templateUrl: './usertype-create.component.html',
  styleUrls: ['./usertype-create.component.css'],
  providers: [DatePipe]
})
export class UsertypeCreateComponent implements OnInit {
  createUsertypeForm!: FormGroup
  currentUser: any;
  constructor(
    private _location: Location,
    private fb: FormBuilder,
    private usertypeService: UsertypeService,
    private toastr: ToastrService,
    private router: Router, private datePipe: DatePipe
  ) { }

  ngOnInit(): void {

    this.currentUser = JSON.parse(localStorage.getItem('currentUser') as string);
    this.currentUser = this.currentUser[0].UserName;

    this.createUsertypeForm = this.fb.group({
      UserType: ['', Validators.required]
    })
  }

  backClicked() {
    this._location.back();
  }

  createNewUsertype() {
    this.createUsertypeForm.value.CreatedOn = this.datePipe.transform(new Date(), 'yyyy-MM-dd');
    this.createUsertypeForm.value.CreatedBy = this.currentUser;
    this.usertypeService.createUserstype(this.createUsertypeForm.value).subscribe((res: any) => {
      if (res.status === 200) {
        this.router.navigate(['/admin/dashboard/master/usertype'])
      } else {
        this.toastr.warning(res.message, 'Warning');
      }
    })
  }

  submitNewUsertype() {
    if (this.createUsertypeForm.valid) {
      this.createNewUsertype()
    }
  }

}
