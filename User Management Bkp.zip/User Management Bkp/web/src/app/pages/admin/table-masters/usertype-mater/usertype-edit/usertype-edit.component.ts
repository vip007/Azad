import { DatePipe, Location } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { UsertypeService } from 'src/app/services/admin/table-masters/usertype.service';

@Component({
  selector: 'app-usertype-edit',
  templateUrl: './usertype-edit.component.html',
  styleUrls: ['./usertype-edit.component.css'],
  providers: [DatePipe]
})
export class UsertypeEditComponent implements OnInit {
  editUsertypeForm!: FormGroup;
  usertypeToModify: any;
  currentUser: any;
  constructor(
    private _location: Location,
    private usertypeService: UsertypeService,
    private toastr: ToastrService,
    private router: Router,
    private activatedroute: ActivatedRoute,
    private fb: FormBuilder,
    private datePipe: DatePipe,
  ) { }

  ngOnInit(): void {

    this.currentUser = JSON.parse(localStorage.getItem('currentUser') as string);
    this.currentUser = this.currentUser[0].UserName;

    this.getUsertypetoModify()

    this.editUsertypeForm = this.fb.group({
      UserType: ['', Validators.required]
    })
  }

  backClicked() {
    this._location.back();
  }

  editNewUsertype() {
    this.editUsertypeForm.value.ModifiedOn = this.datePipe.transform(new Date(), 'yyyy-MM-dd');
    this.editUsertypeForm.value.ModifiedBy = this.currentUser;
    this.editUsertypeForm.value.ID_UserType = this.activatedroute.snapshot.paramMap.get("id");
    this.usertypeService.modifyUserType(this.editUsertypeForm.value).subscribe((data: any) => {
      if (data.status === 200) {
        this.toastr.success('User was modified succesfully', 'Success');
        this.router.navigate(['/admin/dashboard/master/usertype']);
      } else {
        this.toastr.warning(data.message, 'Warning');
      }
    });
  }

  submitModifyUsertype() {
    if (this.editUsertypeForm.touched) {
      if (this.editUsertypeForm.invalid) {
        this.toastr.error('Form is invalid, Please try again with all valid values', 'Error');
      } else {
        this.editNewUsertype()
      }
    } else {
      this.toastr.info('Press cancel to go back to users list', 'No changes made');
    }
  }

  getUsertypetoModify() {
    this.usertypeService.getUserstypeWithID(this.activatedroute.snapshot.paramMap.get("id")).subscribe((res: any) => {
      if (res.status === 200) {
        this.usertypeToModify = res.data[0]
        if (this.usertypeToModify) {
          this.editUsertypeForm.setValue(
            {
              UserType: this.usertypeToModify.UserType,
            }
          );
        }

      } else {
        this.toastr.error('Failed to load user', 'Error');
      }
    })
  }

}
