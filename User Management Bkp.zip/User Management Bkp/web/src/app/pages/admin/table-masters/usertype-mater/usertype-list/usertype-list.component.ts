import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UsertypeService } from 'src/app/services/admin/table-masters/usertype.service';

@Component({
  selector: 'app-usertype-list',
  templateUrl: './usertype-list.component.html',
  styleUrls: ['./usertype-list.component.css']
})
export class UsertypeListComponent implements OnInit {
  UsertypeList: any;
  constructor(
    private router: Router,
    private usertypeService: UsertypeService,
  ) { }

  ngOnInit(): void {
    this.getUsertypeList()
  }

  createNewUsertype() {
    this.router.navigate(['/admin/dashboard/master/usertype/create']);
  }

  getUsertypeList() {
    this.usertypeService.getUserTypeList().subscribe((res: any) => {
      this.UsertypeList = res.data
    })
  }

  modifyUsertype(id: number) {
    this.router.navigate(['/admin/dashboard/master/usertype/modify/' + id]);
  }

  toggleUsertypeActiveState(id: number, state: number) {
    this.usertypeService.toggleUserTyperActiveState({ "ID_UserType": id, "IsActive": state }).subscribe((res: any) => {
      if (res.status === 200) {
        this.getUsertypeList()

      }
    })
  }
}
