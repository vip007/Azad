import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { UsertypeCreateComponent } from './usertype-create/usertype-create.component';
import { UsertypeEditComponent } from './usertype-edit/usertype-edit.component';
import { UsertypeListComponent } from './usertype-list/usertype-list.component';

const routes: Routes = [
  { path: '', component: UsertypeListComponent },
  { path: 'create', component: UsertypeCreateComponent },
  { path: 'modify/:id', component: UsertypeEditComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class UsertypeMaterRoutingModule { }
