import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { UsertypeMaterRoutingModule } from './usertype-mater-routing.module';
import { UsertypeListComponent } from './usertype-list/usertype-list.component';
import { UsertypeCreateComponent } from './usertype-create/usertype-create.component';
import { UsertypeEditComponent } from './usertype-edit/usertype-edit.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgxSpinnerModule } from 'ngx-spinner';


@NgModule({
  declarations: [
    UsertypeListComponent,
    UsertypeCreateComponent,
    UsertypeEditComponent
  ],
  imports: [
    CommonModule,
    UsertypeMaterRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    NgxSpinnerModule

  ]
})
export class UsertypeMaterModule { }
