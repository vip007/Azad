import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { FormArray, FormBuilder } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-associates-form',
  templateUrl: './associates-form.component.html',
  styleUrls: ['./associates-form.component.css']
})
export class AssociatesFormComponent implements OnInit {
  associateDetails: any;

  @Output() sendAssociateDetailsEvent = new EventEmitter<string>();


  constructor(private fb: FormBuilder, private toastr: ToastrService) { }

  ngOnInit(): void {
    this.associateDetails = this.fb.group({
      associateDetail: this.fb.array([this.createAssociateDetail()])
    })
  }

  get associateDetailsForm() {
    return this.associateDetails.get('associateDetail') as FormArray;
  }

  addAssociateDetails() {
    this.associateDetailsForm.push(this.createAssociateDetail());
  }

  createAssociateDetail() {
    return this.fb.group({
      pan: [''],
      name: [''],
      address: [''],
    })
  }

  deleteAssociateDetails(i: number) {
    const associateDetail = this.associateDetailsForm
    if (associateDetail.length > 1) {
      associateDetail.removeAt(i);
    } else {
      associateDetail.reset();
    }
  }

  associateDetailsSubmitHandler() {
    if (this.associateDetails.valid) {
      this.sendAssociateDetailsEvent.emit(this.associateDetails.value)
      this.toastr.success('Associates Details submitted succesfully', 'Success');
    }
  }

}
