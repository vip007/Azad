import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-company-details-form',
  templateUrl: './company-details-form.component.html',
  styleUrls: ['./company-details-form.component.css']
})
export class CompanyDetailsFormComponent implements OnInit {
  companyDetails!: FormGroup;

  @Output() sendCompDetailsEvent = new EventEmitter<string>();

  constructor(
    private fb: FormBuilder,
    private toastr: ToastrService
  ) { }

  ngOnInit(): void {

    this.companyDetails = this.fb.group({
      nameOfCompany: [, [Validators.required]],
      dateOfIncorporation: [, [Validators.required]],
      cityOfIncorporation: [, [Validators.required]],
      registered: [, [Validators.required]],
      regnNum: [, [Validators.required]],
      since: [, [Validators.required]],

      idProofs: this.fb.array([this.createIdProofs()]),
    });
  }


  get idProofsForms() {
    return this.companyDetails.get('idProofs') as FormArray;
  }

  addidProofs() {
    this.idProofsForms.push(this.createIdProofs())
  }

  createIdProofs() {
    return this.fb.group({
      idproof: [],
      idNumber: [],
      date: [],
      issueDate: [],
      expDate: [],
      issuingAuthority: [],
    });
  }

  deleteidProofs(i: number) {
    //this.phoneForms.removeAt(i);
    const idproof = this.idProofsForms
    if (idproof.length > 1) {
      idproof.removeAt(i);
    } else {
      idproof.reset();
    }
  }

  submitHandlerForCompanyDetails() {
    if (!this.companyDetails.valid) {
      this.sendCompDetailsEvent.emit(this.companyDetails.value)
      this.toastr.success('Company Details submitted succesfully', 'Success');
    }
  }

}
