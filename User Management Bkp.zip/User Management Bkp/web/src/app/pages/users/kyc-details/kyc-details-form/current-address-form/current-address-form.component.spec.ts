import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CurrentAddressFormComponent } from './current-address-form.component';

describe('CurrentAddressFormComponent', () => {
  let component: CurrentAddressFormComponent;
  let fixture: ComponentFixture<CurrentAddressFormComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CurrentAddressFormComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CurrentAddressFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
