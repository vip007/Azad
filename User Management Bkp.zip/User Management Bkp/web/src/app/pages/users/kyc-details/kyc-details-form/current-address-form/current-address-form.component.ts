import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-current-address-form',
  templateUrl: './current-address-form.component.html',
  styleUrls: ['./current-address-form.component.css']
})
export class CurrentAddressFormComponent implements OnInit {
  CurrentContactDetails!: FormGroup;

  @Output() sendCurrContsDetailsEvent = new EventEmitter<string>();

  constructor(private fb: FormBuilder, private toastr: ToastrService) { }

  ngOnInit(): void {
    this.CurrentContactDetails = this.fb.group({
      // Group 1
      currentPhones: this.fb.array([this.createPhone()]),
      // Group 2
      ownershipType: ['', [Validators.required]],
      addressType: ['', [Validators.required]],
      yearsAsAddress: ['', [Validators.required]],
      yearsAsCity: ['', [Validators.required]],
      pin: ['', [Validators.required]],
      city: ['', [Validators.required]],
      district: ['', [Validators.required]],
      state: ['', [Validators.required]],
      address: ['', [Validators.required]],
      nearestLandmark: ['', [Validators.required]],
      code: ['', [Validators.required]],
      landlineNumber: ['', [Validators.required]],
      ext: ['', [Validators.required]],
      // Group 3
      currentDocuments: this.fb.array([this.createDocument()]),
    });
  }

  get phoneForms() {
    return this.CurrentContactDetails.get('currentPhones') as FormArray;
  }

  addPhone() {
    this.phoneForms.push(this.createPhone());
  }

  createPhone() {
    return this.fb.group({
      phoneNo: ['', [Validators.required]],
      isPhoneDefault: [false],
      email: ['', [Validators.required]],
      isEmailDefault: [false],
    })
  }

  deletePhone(i: number) {
    //this.phoneForms.removeAt(i);
    const phone = this.CurrentContactDetails.get('currentPhones') as FormArray;
    if (phone.length > 1) {
      phone.removeAt(i);
    } else {
      phone.reset();
    }
  }

  get currentDocumentsForm() {
    return this.CurrentContactDetails.get('currentDocuments') as FormArray;
  }

  addDocument() {
    this.currentDocumentsForm.push(this.createDocument());
  }

  createDocument() {
    return this.fb.group({
      idType: ['', [Validators.required]],
      idNumber: ['', [Validators.required]],
      dated: ['', [Validators.required]],
      issuingDated: ['', [Validators.required]],
      expdated: ['', [Validators.required]],
      issuingAuthority: ['', [Validators.required]],
    })
  }

  deleteDocument(i: number) {
    const document = this.CurrentContactDetails.get(
      'currentDocuments'
    ) as FormArray;
    if (document.length > 1) {
      document.removeAt(i);
    } else {
      document.reset();
    }
  }

  CurrentContactDetailssubmitHandler() {
    if (!this.CurrentContactDetails.valid) {
      this.sendCurrContsDetailsEvent.emit(this.CurrentContactDetails.value)
      this.toastr.success('Current Address submitted succesfully', 'Success');
    }
  }

}
