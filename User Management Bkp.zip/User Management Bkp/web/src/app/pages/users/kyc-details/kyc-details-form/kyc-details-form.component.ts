import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, FormArray, Validators } from '@angular/forms';
import { Location } from '@angular/common';
import { SharedDataService } from 'src/app/services/shared-data.service';
import { DataService } from 'src/app/services/data.service';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-kyc-details-form',
  templateUrl: './kyc-details-form.component.html',
  styleUrls: ['./kyc-details-form.component.css'],
})
export class KycDetailsFormComponent implements OnInit {

  companyDetails!: any;
  CurrentContactDetails!: any;
  PermanentContactDetails!: any;
  OtherContactDetails!: any;
  associateDetails!: any;
  constructor(
    private fb: FormBuilder,
    private _location: Location,
    private sharedDataService: SharedDataService,
    private dataService: DataService,
    private toastr: ToastrService
  ) { }
  ngOnInit() { }

  receivecontactDetails($event: any) {
    this.companyDetails = $event;
    console.log(this.companyDetails)
  }

  receiveAssociateDetails($event: any) {
    this.associateDetails = $event;
    console.log(this.associateDetails)
  }

  receiveCurrContactsDetails($event: any) {
    this.CurrentContactDetails = $event;
    console.log(this.CurrentContactDetails)
  }

  receivePermaContactsDetails($event: any) {
    this.PermanentContactDetails = $event;
    console.log(this.PermanentContactDetails)
  }

  receiveOtherContactsDetails($event: any) {
    this.OtherContactDetails = $event;
    console.log(this.OtherContactDetails)
  }

  // Back Button
  backClicked() {
    this._location.back();
  }

  // tabs for Associate/Relative Details
  tabIndex = -1;
  onTabClick(index: any) {
    this.tabIndex = index;
    console.log(this.tabIndex)
  }

}
