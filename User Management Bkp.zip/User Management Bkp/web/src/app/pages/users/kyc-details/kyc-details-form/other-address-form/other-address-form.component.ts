import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-other-address-form',
  templateUrl: './other-address-form.component.html',
  styleUrls: ['./other-address-form.component.css']
})
export class OtherAddressFormComponent implements OnInit {
  OtherAddressesDetails!: FormGroup;

  @Output() sendOtherContsDetailsEvent = new EventEmitter<string>();

  constructor(
    private fb: FormBuilder,
    private toastr: ToastrService
  ) { }

  ngOnInit(): void {
    this.OtherAddressesDetails = this.fb.group({
      otherAddress: this.fb.array([]),
    });
  }

  get otherAddressForm() {
    return this.OtherAddressesDetails.get('otherAddress') as FormArray;
  }

  addotherAddress() {
    this.otherAddressForm.push(this.createOtherAddress());
  }

  createOtherAddress() {
    return this.fb.group({
      ownershipType: ['', [Validators.required]],
      addressType: ['', [Validators.required]],
      yearsAsAddress: ['', [Validators.required]],
      yearsAsCity: ['', [Validators.required]],
      pin: ['', [Validators.required]],
      city: ['', [Validators.required]],
      district: ['', [Validators.required]],
      state: ['', [Validators.required]],
      address: ['', [Validators.required]],
      nearestLandmark: ['', [Validators.required]],
      code: ['', [Validators.required]],
      landlineNumber: ['', [Validators.required]],
      ext: ['', [Validators.required]],
    })
  }

  removeOtherAddress(i: number) {
    const document = this.OtherAddressesDetails.get(
      'otherAddress'
    ) as FormArray;
    document.removeAt(i);
  }

  OtherAddressesDetailssubmitHandler() {
    if (!this.OtherAddressesDetails.valid) {
      this.sendOtherContsDetailsEvent.emit(this.OtherAddressesDetails.value)
      this.toastr.success('Other Addresses submitted succesfully', 'Success');
    }
  }

}
