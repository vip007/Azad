import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PermaAddressFormComponent } from './perma-address-form.component';

describe('PermaAddressFormComponent', () => {
  let component: PermaAddressFormComponent;
  let fixture: ComponentFixture<PermaAddressFormComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PermaAddressFormComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PermaAddressFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
