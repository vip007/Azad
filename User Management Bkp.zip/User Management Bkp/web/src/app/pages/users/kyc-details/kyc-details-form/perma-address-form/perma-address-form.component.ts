import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-perma-address-form',
  templateUrl: './perma-address-form.component.html',
  styleUrls: ['./perma-address-form.component.css']
})
export class PermaAddressFormComponent implements OnInit {
  PermanentContactDetails!: FormGroup;

  @Output() sendCPermaContsDetailsEvent = new EventEmitter<string>();

  constructor(private fb: FormBuilder, private toastr: ToastrService) { }

  ngOnInit(): void {
    this.PermanentContactDetails = this.fb.group({
      // Group 1
      ownershipType: ['', [Validators.required]],
      addressType: ['', [Validators.required]],
      yearsAsAddress: ['', [Validators.required]],
      yearsAsCity: ['', [Validators.required]],
      pin: ['', [Validators.required]],
      city: ['', [Validators.required]],
      district: ['', [Validators.required]],
      state: ['', [Validators.required]],
      address: ['', [Validators.required]],
      nearestLandmark: ['', [Validators.required]],
      code: ['', [Validators.required]],
      landlineNumber: ['', [Validators.required]],
      ext: ['', [Validators.required]],
      // Group 2
      permanentAddDocuments: this.fb.array([this.createPermanentDocuments()]),
    });
  }

  get permanentDocumentsForm() {
    return this.PermanentContactDetails.get(
      'permanentAddDocuments'
    ) as FormArray;
  }

  addPermanentAddDocument() {
    this.permanentDocumentsForm.push(this.createPermanentDocuments());
  }

  createPermanentDocuments() {
    return this.fb.group({
      idType: ['', [Validators.required]],
      idNumber: ['', [Validators.required]],
      dated: ['', [Validators.required]],
      issuingDated: ['', [Validators.required]],
      expdated: ['', [Validators.required]],
      issuingAuthority: ['', [Validators.required]],
    })
  }

  deletePermanentAddDocument(i: number) {
    const document = this.PermanentContactDetails.get(
      'permanentAddDocuments'
    ) as FormArray;
    if (document.length > 1) {
      document.removeAt(i);
    } else {
      document.reset();
    }
  }

  PermanentContactDetailssubmitHandler() {
    if (!this.PermanentContactDetails.valid) {
      this.sendCPermaContsDetailsEvent.emit(this.PermanentContactDetails.value)
      this.toastr.success('Permanent/Registered Address submitted succesfully', 'Success');
    }
  }

}
