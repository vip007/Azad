import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { KycDetailsFormComponent } from './kyc-details-form/kyc-details-form.component';
import { KycDetailsTableComponent } from './kyc-details-table/kyc-details-table.component';

const routes: Routes = [
  { path: '', component: KycDetailsTableComponent },
  { path: 'view-data', component: KycDetailsFormComponent },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class KycDetailsRoutingModule {}
