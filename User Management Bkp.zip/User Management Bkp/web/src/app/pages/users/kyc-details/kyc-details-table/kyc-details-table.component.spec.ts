import { ComponentFixture, TestBed } from '@angular/core/testing';

import { KycDetailsTableComponent } from './kyc-details-table.component';

describe('KycDetailsTableComponent', () => {
  let component: KycDetailsTableComponent;
  let fixture: ComponentFixture<KycDetailsTableComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ KycDetailsTableComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(KycDetailsTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
