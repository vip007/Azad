import { Component, OnInit } from '@angular/core';
import { DataService } from 'src/app/services/data.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { SharedDataService } from 'src/app/services/shared-data.service';
import { AuthService } from 'src/app/services/auth.service';

@Component({
  selector: 'app-kyc-details-table',
  templateUrl: './kyc-details-table.component.html',
  styleUrls: ['./kyc-details-table.component.css'],
})
export class KycDetailsTableComponent implements OnInit {
  KycDetailsDatas: any;
  newKycDetailsDatas: any = [];
  loanProductData: any;
  loanProduct: any = [];
  username: any;
  authBranches: any;
  authBranchesArray: string[] = [];

  constructor(
    private dataService: DataService,
    private spinner: NgxSpinnerService,
    private sharedDataService: SharedDataService,
    private authService: AuthService,
  ) { }

  ngOnInit(): void {
    this.spinner.show();
    this.username = localStorage.getItem('currentUser')
    this.username = JSON.parse(this.username)
    this.getAuthorizedBranches()
    this.getAuthorizedProducts(this.username[0].ID_User)
    setTimeout(() => {
      if (this.loanProduct) {
        this.getKycDetailsTableData();
      }
    }, 500);
  }

  getKycDetailsTableData() {
    this.dataService
      .getLoginData().subscribe((res: any) => {
        this.KycDetailsDatas = res
        this.KycDetailsDatas.forEach((item: any, i: any) => {
          if (this.loanProduct.includes(item.loanProductType) && this.authBranchesArray.includes(item.branch) && item.status == 1) {
            this.newKycDetailsDatas.push(item);
          }
        })
        this.spinner.hide();
      });
  }

  getAuthorizedProducts(id: any) {
    this.authService.getUserProducts({ "ID_User": id }).subscribe((res: any) => {
      this.loanProductData = res['data']
      this.loanProductData.forEach((item: any, i: any) => {
        this.loanProduct.push(item.ProductCode)
      })
    });
  }

  getAuthorizedBranches() {
    this.authBranches = localStorage.getItem('branch')
    this.authBranches = JSON.parse(this.authBranches)
    //console.log(this.authBranches)
    this.authBranches.forEach((item: any, i: any) => {
      let branch: string = `${item.LocationName}-${item.Name}`
      this.authBranchesArray.push(branch)
      console.log(this.authBranchesArray)
    })
  }

  userEdit(_user: any, i: any) {
    console.log(_user, i);
    this.sharedDataService.setLoginDataWithID(_user);
  }
}
