import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { KycDetailsRoutingModule } from './kyc-details-routing.module';
import { KycDetailsTableComponent } from './kyc-details-table/kyc-details-table.component';
import { KycDetailsFormComponent } from './kyc-details-form/kyc-details-form.component';

import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgxSpinnerModule } from 'ngx-spinner';
import { CompanyDetailsFormComponent } from './kyc-details-form/company-details-form/company-details-form.component';
import { AssociatesFormComponent } from './kyc-details-form/associates-form/associates-form.component';
import { PermaAddressFormComponent } from './kyc-details-form/perma-address-form/perma-address-form.component';
import { OtherAddressFormComponent } from './kyc-details-form/other-address-form/other-address-form.component';
import { CurrentAddressFormComponent } from './kyc-details-form/current-address-form/current-address-form.component';

@NgModule({
  declarations: [KycDetailsTableComponent, KycDetailsFormComponent, CompanyDetailsFormComponent, AssociatesFormComponent, PermaAddressFormComponent, OtherAddressFormComponent, CurrentAddressFormComponent],
  imports: [
    CommonModule,
    KycDetailsRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    NgxSpinnerModule,
  ],
})
export class KycDetailsModule { }
