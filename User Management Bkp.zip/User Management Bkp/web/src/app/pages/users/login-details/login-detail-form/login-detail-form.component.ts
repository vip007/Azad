import { Component, OnInit } from '@angular/core';
import { Location } from '@angular/common';
import { SharedDataService } from 'src/app/services/shared-data.service';
import { DataService } from 'src/app/services/data.service';
import { FormBuilder, FormGroup, FormArray, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-login-detail-form',
  templateUrl: './login-detail-form.component.html',
  styleUrls: ['./login-detail-form.component.css'],
})
export class LoginDetailFormComponent implements OnInit {
  loginDetailsDatas: any;
  editEnabled: boolean = false;
  loginDetailsForm!: FormGroup;

  buttonPermisionEdit: any = false;
  buttonPermisionSave: any = false;
  buttonPermisionView: any = false;
  buttonPermisionUpload: any = false;
  buttonAuth: any;

  appId = localStorage.getItem('applicaitonId')

  constructor(
    private fb: FormBuilder,
    private _location: Location,
    private sharedDataService: SharedDataService,
    private dataService: DataService,
    private router: Router,
    private toastr: ToastrService
  ) { }

  ngOnInit(): void {
    this.loginDetailsDatas = this.sharedDataService.getLoginDataWithID();

    this.loginDetailsForm = this.fb.group({
      applicationNo: [this.loginDetailsDatas.applicationNo],
      applicationDate: [this.loginDetailsDatas.applicationDate],
      borrowerPan: [this.loginDetailsDatas.borrowerPan],
      contactNo: [this.loginDetailsDatas.contactNo],
      branch: [this.loginDetailsDatas.branch],
      salesOfficial: [this.loginDetailsDatas.salesOfficial],
      source: [this.loginDetailsDatas.source],
      DSA: [this.loginDetailsDatas.DSA],
      loanProductType: [this.loginDetailsDatas.loanProductType],
      loanPurpose: [this.loginDetailsDatas.loanPurpose],
      loanAmount: [this.loginDetailsDatas.loanAmount],
      tenure: [this.loginDetailsDatas.tenure],
      intrest: [this.loginDetailsDatas.intrest],
      applicationStatus: [this.loginDetailsDatas.applicationStatus],
      remarks: [this.loginDetailsDatas.remarks],
      approvalRemarks: [this.loginDetailsDatas.approvalRemarks],
      status: [1],
    });


    this.buttonAuth = localStorage.getItem('currentUser')
    this.buttonAuth = JSON.parse(this.buttonAuth)

    this.buttonAuth.forEach((items: any, i: any) => {
      if (items.MenuName === "Login Detail") {

        items.MenuEventName.forEach((items: any, i: any) => {
          if (items == "Edit") {
            this.buttonPermisionEdit = true
          }
          if (items == "Save") {
            this.buttonPermisionSave = true;
          }
          if (items == "View") {
            this.buttonPermisionView = true;
          }
          if (items == "Upload") {
            this.buttonPermisionUpload = true;
          }
        })
      }
    })
  }

  backClicked() {
    this._location.back();
  }

  enableEditMode() {
    this.editEnabled = !this.editEnabled;
  }

  loginDetailsSubmitHandler() {

    let id = this.loginDetailsDatas.id;

    this.dataService.patchLoginData(this.loginDetailsForm.value, id);
    this.buttonAuth.forEach((items: any, i: any) => {
      if (items.MenuName === "KYC Detail") {
        this.router.navigate(['/user/los/kyc-details']);
      } else {
        this.router.navigate(['/user/los/login-details']);
      }
    })
    this.toastr.success('Your Application is submitted succesfully', 'Success');

  }

}
