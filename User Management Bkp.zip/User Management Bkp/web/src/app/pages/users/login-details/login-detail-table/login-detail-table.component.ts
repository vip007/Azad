import { Component, OnInit } from '@angular/core';
import { DataService } from '../../../../services/data.service';
import { SharedDataService } from '../../../../services/shared-data.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { AuthService } from 'src/app/services/auth.service';

@Component({
  selector: 'app-login-detail-table',
  templateUrl: './login-detail-table.component.html',
  styleUrls: ['./login-detail-table.component.css'],
})
export class LoginDetailTableComponent implements OnInit {
  newloginDetailsDatas: any = []
  loginDetailsDatas: any;
  loanProductData: any;
  loanProduct: any = [];
  username: any;
  authBranches: any;
  authBranchesArray: string[] = [];

  constructor(
    private dataService: DataService,
    private sharedDataService: SharedDataService,
    private spinner: NgxSpinnerService,
    private authService: AuthService,
  ) { }

  ngOnInit(): void {

    this.username = localStorage.getItem('currentUser')
    this.username = JSON.parse(this.username)
    this.spinner.show();
    this.getAuthorizedProducts(this.username[0].ID_User)
    this.getAuthorizedBranches()

    setTimeout(() => {
      if (this.loanProduct) {
        this.getloginDetailsTableData();
      }
    }, 500);
  }

  /**
   * Gets and Formats data from JSON Server to display on the table
   */
  getloginDetailsTableData() {
    this.dataService
      .getLoginData().subscribe((res: any) => {
        this.loginDetailsDatas = res
        this.loginDetailsDatas.forEach((item: any, i: any) => {
          if (this.loanProduct.includes(item.loanProductType) && this.authBranchesArray.includes(item.branch) && item.status == 0) {
            this.newloginDetailsDatas.push(item);
          }
        })
        this.spinner.hide();
      });
  }

  /**
   * This Function gets the "Product Codes" the use has access to
   */
  getAuthorizedProducts(id: any) {
    this.authService.getUserProducts({ "ID_User": id }).subscribe((res: any) => {
      this.loanProductData = res['data']
      this.loanProductData.forEach((item: any, i: any) => {
        this.loanProduct.push(item.ProductCode);
      })
    });
  }

  /**
   * Fetches the branch the user has access to with the help of data stored in local storage
   */
  getAuthorizedBranches() {
    this.authBranches = localStorage.getItem('branch')
    this.authBranches = JSON.parse(this.authBranches)
    this.authBranches.forEach((item: any, i: any) => {
      let branch: string = `${item.LocationName}-${item.Name}`
      this.authBranchesArray.push("branch", branch)
    })
  }

  userEdit(_user: any, i: any) {
    this.sharedDataService.setLoginDataWithID(_user);
  }
}
