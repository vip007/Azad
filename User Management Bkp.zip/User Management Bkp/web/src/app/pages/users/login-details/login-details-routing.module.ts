import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { LoginDetailFormComponent } from './login-detail-form/login-detail-form.component';
import { LoginDetailTableComponent } from './login-detail-table/login-detail-table.component';

const routes: Routes = [
  { path: '', component: LoginDetailTableComponent },
  { path: 'view-data', component: LoginDetailFormComponent },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class LoginDetailsRoutingModule { }
