import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NgxSpinnerModule } from 'ngx-spinner';
import { LoginDetailsRoutingModule } from './login-details-routing.module';
import { ReactiveFormsModule } from '@angular/forms';

import { LoginDetailFormComponent } from './login-detail-form/login-detail-form.component';
import { LoginDetailTableComponent } from './login-detail-table/login-detail-table.component';


@NgModule({
  declarations: [LoginDetailFormComponent, LoginDetailTableComponent],
  imports: [
    CommonModule,
    LoginDetailsRoutingModule,
    ReactiveFormsModule,
    NgxSpinnerModule,
  ],
})
export class LoginDetailsModule { }
