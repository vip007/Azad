import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { DataService } from '../../../services/data.service';
import { ToastrService } from 'ngx-toastr';
import { AuthService } from 'src/app/services/auth.service';

@Component({
  selector: 'app-new-application',
  templateUrl: './new-application.component.html',
  styleUrls: ['./new-application.component.css'],
})
export class NewApplicationComponent implements OnInit {
  newApplicationForm!: FormGroup;
  newApplicationFormSubmit: boolean = false;
  buttonAuth: any;
  applicaitonId: any;
  currentDate: any = new Date()
  username: any;
  branch: any;

  loanProduct = [

    {
      name: "AHA",
      value:
        [{
          name: "AFFORDABLE HOUSING - APPLICATION FINANCING",
        }]
    },

    {
      name: "BSL",
      value: [{
        name: "BUSINESS LOAN (UNSECURED)"
      }]
    },

    {
      name: "CDL",
      value:
        [{
          name: "CONSUMER DURABLE LOAN",
        }]
    },

    {
      name: "MEQ",
      value: [{
        name: "MEDICAL EQUIPMENT LOAN",
      },
      {
        name: "MACHINERY/EQUIPMENT LOAN",
      }]
    },

    {
      name: "LMS",
      value: [
        {
          name: "IPO FINANCING(RETAIL)",
        },
        {
          name: "PROMOTER FUNDING",
        },
        {
          name: "LOAN AGAINST COMMODITIES",
        },
        {
          name: "LOAN AGAINST SECURITIES",
        },
        {
          name: "ESOP FUNDING",
        },
        {
          name: "IPO (HNI/CORP APP) FINANCING",
        }

      ]
    },

    {
      name: "LAP",
      value: [{
        name: "LOAN AGAINST PROPERTY",
      }, {
        name: "LEASE RENTAL DISCOUNTING",
      }, {
        name: "BUILDER/DEVELOPER FINANCE",
      }, {
        name: "EDI (EDUCATION INST.)",
      }, {
        name: "PROJECT FUNDING",
      }, {
        name: "SMC EMPLOYEE LAP",
      }]
    },

    {
      name: "PSL",
      value:
        [{
          name: "EMPLOYEE PL",
        },
        {
          name: "PERSONAL LOAN",
        }]
    },

    {
      name: "RFN",
      value: [{
        name: "NBFC FINANCING",
      }, {
        name: "RECEIVABLE FINANCING",
      }, {
        name: "CREDIT CARD RECEIVABLE",
      }]
    },

    {
      name: "VEH",
      value: [{
        name: "EMPLOYEE PL",
      }]
    },

    {
      name: "OTH",
      value: [{
        name: "OTHER",
      }]
    }]
  loanProductOptions: any

  loanProductData: any;
  constructor(
    private router: Router,
    private fb: FormBuilder,
    private dataService: DataService,
    private toastr: ToastrService,
    private authService: AuthService
  ) { }

  ngOnInit(): void {

    this.loginNumber()


    //this.currentDate = new Date()
    this.username = localStorage.getItem('currentUser')
    this.username = JSON.parse(this.username)

    this.branch = localStorage.getItem('branch')
    this.branch = JSON.parse(this.branch)

    // this.getUserLoanProducts(this.username[0].ID_User)

    this.username = this.username[0].UserName

    this.newApplicationForm = this.fb.group({
      applicationNo: ['', [Validators.required]],
      applicationDate: ['', [Validators.required]],
      borrowerPan: ['', [Validators.required]],
      doi: ['', [Validators.required]],
      contactNo: ['', [Validators.required]],
      branch: ['', [Validators.required]],
      salesOfficial: ['', [Validators.required]],
      channel: ['', [Validators.required]],
      source: ['', [Validators.required]],
      loanProductType: ['', [Validators.required]],
      loanProduct: ['', [Validators.required]],
      loanApplicationType: ['', [Validators.required]],
      loanPurpose: ['', [Validators.required]],
      loanAmount: ['', [Validators.required]],
      tenure: ['', [Validators.required]],
      intrest: ['', [Validators.required]],
      // TODO: Add upload file in form
      remarks: [''],
      status: [0],
      applicationStatus: ["Login"],
      // *For Other Forms
      AssociateDetails: [],
      CurrentContactDetails: [],
      PermanentContactDetails: [],
      OtherAddressesDetails: [],
      companyDetails: [],
    });
  }

  newApplicationSubmitHandler() {
    this.newApplicationFormSubmit = true;
    if (this.newApplicationForm.valid) {
      this.buttonAuth = localStorage.getItem('currentUser')
      this.buttonAuth = JSON.parse(this.buttonAuth)

      let branch = this.newApplicationForm.value.branch.split('-')
      branch.pop();
      const fixedBranch = branch.join('-');
      this.newApplicationForm.value.branch = fixedBranch
      this.dataService.postLoginData(this.newApplicationForm.value);
      this.buttonAuth.forEach((items: any, i: any) => {
        if (items.MenuName === "Login Detail") {
          this.router.navigate(['/user/los/login-details']);
        } else {
          this.toastr.success('Your Loan Application submitted succesfully', 'Success');
          this.newApplicationForm.reset()
        }
      })
    }

  }

  get newApplicationFormControl() {
    return this.newApplicationForm.controls;
  }

  cancelNewApplication() {
    this.newApplicationForm.reset();
  }

  /**
   * Generates Random Login Number in form
   */
  loginNumber() {
    this.applicaitonId = Math.floor(100000 + Math.random() * 900000);
    localStorage.setItem('applicaitonId', this.applicaitonId)
  }

  /**
   * Event Occurs when user select the "Branch" formControlName
   * Splits the branch string into a Array and gets the ID at the last index
   * The value of the ID is sent to getUserLoanProducts() function after converting to INTEGER
   */
  getProductByBranch(event: any) {
    let branch = event.target.value
    branch = branch.split("-").pop()
    // console.log("event.target.value", event.target.value)
    // console.log("branch", branch)
    this.getUserLoanProducts(parseInt(branch))
  }

  /**
   * Gets the loanProducts w.r.t the id recieved
   */
  getUserLoanProducts(id: any) {
    this.authService.getUserLoanProducts({ "ID_Branch": id }).subscribe((res: any) => {
      if (res.status === 200) {
        this.loanProductData = res['data']
      } else {
        this.toastr.error(res.message, 'Error');
      }
    });
  }

  /**
   * This Event is triggered when "loanProductType" formControlName changes
   */
  onChange(event: any) {
    this.loanProduct.forEach((item: any, i: any) => {
      if (item.name == event.target.value) {
        this.loanProductOptions = item.value;
      }
    })
  }
}
