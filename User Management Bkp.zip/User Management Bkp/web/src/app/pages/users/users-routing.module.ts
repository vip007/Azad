import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuard } from 'src/app/services/guards/auth.guard';
import { NewApplicationComponent } from './new-application/new-application.component';

const routes: Routes = [
  {
    path: '',

    children: [
      { path: 'new-application', canActivate: [AuthGuard], component: NewApplicationComponent },
      {
        path: 'kyc-details', canActivate: [AuthGuard],
        loadChildren: () =>
          import('./kyc-details/kyc-details.module').then(
            (m) => m.KycDetailsModule
          ),
      },
      {
        path: 'login-details', canActivate: [AuthGuard],
        loadChildren: () =>
          import('./login-details/login-details.module').then(
            (m) => m.LoginDetailsModule
          ),
      },
    ],
  },
];


@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class UsersRoutingModule { }
