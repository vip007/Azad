import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpInterceptor, HttpRequest } from '@angular/common/http';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class BranchDepartmentMappingService {
  constructor(private httpClient: HttpClient) { }

  grantBranchDepartment(data: any) {
    let url = environment.API_SERVER_URL + 'api/admin/mappings/branch-department-access/grant'
    return this.httpClient.post(url, data);
  }
 
  getBranchDepartment() {
    let url = environment.API_SERVER_URL + 'api/admin/mappings/branch-department-access/'
    return this.httpClient.get(url);
  }

  revokeAccess(data: any) {
    let url = environment.API_SERVER_URL + 'api/admin/mappings/branch-department-access/revoke'
    return this.httpClient.post(url, data);
  }

}
