import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class ProductBranchMappingService {
  constructor(private httpClient: HttpClient) { }

  mapAccess(data: any) {
    let url = environment.API_SERVER_URL + 'api/admin/mappings/product-branch-mapping/grant'
    return this.httpClient.post(url, data);
  }

  getAccessMappings() {
    let url = environment.API_SERVER_URL + 'api/admin/mappings/product-branch-mapping'
    return this.httpClient.get(url);
  }

  revokeAccess(data: any) {
    let url = environment.API_SERVER_URL + 'api/admin/mappings/product-branch-mapping/revoke'
    return this.httpClient.post(url, data);
  }
}
