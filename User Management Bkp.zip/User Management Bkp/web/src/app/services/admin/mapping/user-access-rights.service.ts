import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpInterceptor, HttpRequest } from '@angular/common/http';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class UserAccessRightsService {
  constructor(private httpClient: HttpClient) { }

  grantUserAccessRights(data: any) {
    let url = environment.API_SERVER_URL + 'api/admin/mappings/user-access-rights/grant'
    return this.httpClient.post(url, data);
  }

  getUserAccessRights() {
    let url = environment.API_SERVER_URL + 'api/admin/mappings/user-access-rights/'
    return this.httpClient.get(url);
  }

  revokeAccess(data: any) {
    let url = environment.API_SERVER_URL + 'api/admin/mappings/user-access-rights/revoke'
    return this.httpClient.post(url, data);
  }

}
