import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpInterceptor, HttpRequest } from '@angular/common/http';
import { environment } from 'src/environments/environment';
@Injectable({
  providedIn: 'root'
})
export class UserBranchDepartmentService {

  constructor(private httpClient: HttpClient) { }

  mapAccess(data: any) {
    let url = environment.API_SERVER_URL + 'api/admin/mappings/user-branch-department/grant'
    return this.httpClient.post(url, data);
  }

  getAccessMappings() {
    let url = environment.API_SERVER_URL + 'api/admin/mappings/user-branch-department/'
    return this.httpClient.get(url);
  }

  revokeAccess(data: any) {
    let url = environment.API_SERVER_URL + 'api/admin/mappings/user-branch-department/revoke'
    return this.httpClient.post(url, data);
  }

  getBranchAndDept() {
    let url = environment.API_SERVER_URL + 'api/admin/mappings/user-branch-department/branch-dept'
    return this.httpClient.get(url);
  }
}
