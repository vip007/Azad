import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpInterceptor, HttpRequest } from '@angular/common/http';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class UserDeptBranchMappingService {

  constructor(private httpClient: HttpClient) { }

  mapAccess(data: any) {
    let url = environment.API_SERVER_URL + 'api/admin/mappings/user-branch-dept-mapping/grant'
    return this.httpClient.post(url, data);
  }

  getAccessMappings() {
    let url = environment.API_SERVER_URL + 'api/admin/mappings/user-branch-dept-mapping/'
    return this.httpClient.get(url);
  }

  revokeAccess(data: any) {
    let url = environment.API_SERVER_URL + 'api/admin/mappings/user-branch-dept-mapping/revoke'
    return this.httpClient.post(url, data);
  }
}
