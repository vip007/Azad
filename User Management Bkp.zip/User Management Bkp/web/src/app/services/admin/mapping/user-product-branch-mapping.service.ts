import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
@Injectable({
  providedIn: 'root'
})
export class UserProductBranchMappingService {
  constructor(private httpClient: HttpClient) { }

  mapAccess(data: any) {
    let url = environment.API_SERVER_URL + 'api/admin/mappings/user-product-branch/grant'
    return this.httpClient.post(url, data);
  }

  getAccessMappings() {
    let url = environment.API_SERVER_URL + 'api/admin/mappings/user-product-branch'
    return this.httpClient.get(url);
  }

  getProductBranchID() {
    let url = environment.API_SERVER_URL + 'api/admin/mappings/user-product-branch/get-product-branch-id'
    return this.httpClient.get(url);
  }

  revokeAccess(data: any) {
    let url = environment.API_SERVER_URL + 'api/admin/mappings/user-product-branch/revoke'
    return this.httpClient.post(url, data);
  }
}
