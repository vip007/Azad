import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpInterceptor, HttpRequest } from '@angular/common/http';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class ApplicationService {

  constructor(private httpClient: HttpClient) { }

  getApplicationWithID(id: any) {
    let url = environment.API_SERVER_URL + 'api/admin/application/' + id;
    return this.httpClient.get(url);
  }

  createNewApplication(data: any) {
    let url = environment.API_SERVER_URL + 'api/admin/application/create'
    return this.httpClient.post(url, data);
  }

  getApplicationList() {
    let url = environment.API_SERVER_URL + 'api/admin/application/'
    return this.httpClient.get(url);
  }

  toggleUserActiveState(data: any) {
    let url = environment.API_SERVER_URL + 'api/admin/application/deactivate'
    return this.httpClient.post(url, data);
  }

  modifyApplicaion(data: any) {
    let url = environment.API_SERVER_URL + 'api/admin/application/modify'
    return this.httpClient.post(url, data);
  }
}
