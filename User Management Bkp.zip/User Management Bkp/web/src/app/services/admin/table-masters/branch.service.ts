import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class BranchService {
  constructor(private httpClient: HttpClient) { }


  getBranchWithID(id: any) {
    let url = environment.API_SERVER_URL + 'api/admin/branch/' + id;
    return this.httpClient.get(url);
  }

  createNewBranch(data: any) {
    let url = environment.API_SERVER_URL + 'api/admin/branch/create'
    return this.httpClient.post(url, data);
  }

  getBranchList() {
    let url = environment.API_SERVER_URL + 'api/admin/branch/'
    return this.httpClient.get(url);
  }

  modifyBranch(data: any) {
    let url = environment.API_SERVER_URL + 'api/admin/branch/modify'
    return this.httpClient.post(url, data);
  }
}
