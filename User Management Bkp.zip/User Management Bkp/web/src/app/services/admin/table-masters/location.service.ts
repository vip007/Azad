import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpInterceptor, HttpRequest } from '@angular/common/http';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class LocationService {

  constructor(private httpClient: HttpClient) { }


  getLocationWithID(id: any) {
    let url = environment.API_SERVER_URL + 'api/admin/location/' + id;
    return this.httpClient.get(url);
  }

  createLocation(data: any) {
    let url = environment.API_SERVER_URL + 'api/admin/location/create'
    return this.httpClient.post(url, data);
  }

  getLocationList() {
    let url = environment.API_SERVER_URL + 'api/admin/location/'
    return this.httpClient.get(url);
  }

  toggleUserActiveState(data: any) {
    let url = environment.API_SERVER_URL + 'api/admin/location/toggle-state'
    return this.httpClient.post(url, data);
  }

  modifyLocation(data: any) {
    let url = environment.API_SERVER_URL + 'api/admin/location/modify'
    return this.httpClient.post(url, data);
  }
}
