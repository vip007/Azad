import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpInterceptor, HttpRequest } from '@angular/common/http';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class MenuService {

  constructor(private httpClient: HttpClient) { }


  getMenuWithID(id: any) {
    let url = environment.API_SERVER_URL + 'api/admin/menu/' + id;
    return this.httpClient.get(url);
  }

  createMenu(data: any) {
    let url = environment.API_SERVER_URL + 'api/admin/menu/create'
    return this.httpClient.post(url, data);
  }

  getMenuList() {
    let url = environment.API_SERVER_URL + 'api/admin/menu/'
    return this.httpClient.get(url);
  }

  toggleUserActiveState(data: any) {
    let url = environment.API_SERVER_URL + 'api/admin/menu/toggle-state'
    return this.httpClient.post(url, data);
  }

  modifyMenu(data: any) {
    let url = environment.API_SERVER_URL + 'api/admin/menu/modify'
    return this.httpClient.post(url, data);
  }
}
