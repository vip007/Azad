import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpInterceptor, HttpRequest } from '@angular/common/http';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class MenuEventService implements HttpInterceptor {
  createMenuEvent(value: any) {
    throw new Error('Method not implemented.');
  }

  constructor(private httpClient: HttpClient) {

  }

  intercept(req: any, next: any) {
    let httpOptions = req.clone({
      setHeaders: {
        Authorization: "Bearer " + JSON.parse(localStorage.getItem('accessToken') as string)
      }
    })
    return next.handle(httpOptions)
  }

  MenuEventList() {
    let url = environment.API_SERVER_URL + 'api/admin/menuevent'
    return this.httpClient.get(url);
  }

  MenuEventWithID(id: any) {
    console.log(id)
    let url = environment.API_SERVER_URL + 'api/admin/menuevent/id'
    return this.httpClient.post(url, { "ID_MenuEvent": id })
  }

  createNewMenuEvent(data: any) {
    let url = environment.API_SERVER_URL + 'api/admin/menuevent/create'
    return this.httpClient.post(url, data);
  }

  modifyMenuEvent(data: any) {
    let url = environment.API_SERVER_URL + 'api/admin/menuevent/modify'
    return this.httpClient.post(url, data);
  }

  MenuEventRemove(data: any) {
    let url = environment.API_SERVER_URL + 'api/admin/menuevent/delete'
    return this.httpClient.post(url, data);
  }


}


//environment.API_SERVER_URL
