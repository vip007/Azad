import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpInterceptor, HttpRequest } from '@angular/common/http';
import { environment } from 'src/environments/environment';


@Injectable({
  providedIn: 'root'
})
export class ProductService {
  

  constructor(private httpClient: HttpClient) { }

  ProductWithID(id: any) {
    let url = environment.API_SERVER_URL + 'api/admin/product/' + id;
    return this.httpClient.get(url);
  }

  createNewProduct(data: any) {
    let url = environment.API_SERVER_URL + 'api/admin/product/create'
    return this.httpClient.post(url, data);
  }

  getProductList() {
    let url = environment.API_SERVER_URL + 'api/admin/product/'
    return this.httpClient.get(url);
  }

  toggleProductState(data: any) {
    let url = environment.API_SERVER_URL + 'api/admin/product/toggle-state'
    return this.httpClient.post(url, data);
  }

  modifyProduct(data: any) {
    let url = environment.API_SERVER_URL + 'api/admin/product/modify'
    return this.httpClient.post(url, data);
  }
}
