import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpInterceptor, HttpRequest } from '@angular/common/http';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class RoleService {

  constructor(private httpClient: HttpClient) { }

  getRoleWithID(id: any) {
    let url = environment.API_SERVER_URL + 'api/admin/role/' + id;
    return this.httpClient.get(url);
  }

  createNewRole(data: any) {
    let url = environment.API_SERVER_URL + 'api/admin/role/create'
    return this.httpClient.post(url, data);
  }

  getRoleList() {
    let url = environment.API_SERVER_URL + 'api/admin/role/'
    return this.httpClient.get(url);
  }

  toggleRoleActiveState(data: any) {
    let url = environment.API_SERVER_URL + 'api/admin/role/toggle-state'
    return this.httpClient.post(url, data);
  }

  modifyRole(data: any) {
    let url = environment.API_SERVER_URL + 'api/admin/role/modify'
    return this.httpClient.post(url, data);
  }
}
