import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class UsersService {

  constructor(private httpClient: HttpClient) {

  }

  getUsersListData() {
    let url = environment.API_SERVER_URL + 'api/admin/users'
    return this.httpClient.get(url);
  }

  getUserWithId(id: any) {
    let url = environment.API_SERVER_URL + 'api/admin/users/id'
    return this.httpClient.post(url, id)
  }

  createNewUser(data: any) {
    let url = environment.API_SERVER_URL + 'api/admin/users/create'
    return this.httpClient.post(url, data);
  }

  modifyUser(data: any) {
    let url = environment.API_SERVER_URL + 'api/admin/users/modify'
    return this.httpClient.post(url, data);
  }

  toggleUserActiveState(id: any) {
    let url = environment.API_SERVER_URL + 'api/admin/users/toggle-state'
    return this.httpClient.post(url, id);
  }

  // Helper Functions
  getUserTypes() {
    let url = environment.API_SERVER_URL + 'api/admin/users/usertypes'
    return this.httpClient.get(url);
  }

  searchUserLike(data: any) {
    console.log(data)
    let url = environment.API_SERVER_URL + 'api/admin/users/search'
    return this.httpClient.post(url, data)
  }
}


//environment.API_SERVER_URL
