import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpInterceptor, HttpRequest } from '@angular/common/http';
import { environment } from 'src/environments/environment';
@Injectable({
  providedIn: 'root'
})
export class UsertypeService {

  constructor(private httpClient: HttpClient) { }


  getUserstypeWithID(id: any) {
    let url = environment.API_SERVER_URL + 'api/admin/userstype/' + id;
    return this.httpClient.get(url);
  }

  createUserstype(data: any) {
    let url = environment.API_SERVER_URL + 'api/admin/userstype/create'
    return this.httpClient.post(url, data);
  }

  getUserTypeList() {
    let url = environment.API_SERVER_URL + 'api/admin/userstype/'
    return this.httpClient.get(url);
  }

  toggleUserTyperActiveState(data: any) {
    let url = environment.API_SERVER_URL + 'api/admin/userstype/toggle-state'
    return this.httpClient.post(url, data);
  }

  modifyUserType(data: any) {
    let url = environment.API_SERVER_URL + 'api/admin/userstype/modify'
    return this.httpClient.post(url, data);
  }
}
