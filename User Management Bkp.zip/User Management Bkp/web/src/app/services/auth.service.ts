import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { Router } from '@angular/router';


@Injectable({
  providedIn: 'root',
})
export class AuthService {
  headers = new HttpHeaders()
    .set('Content-Type', 'application/json')
    .set('Accept', 'application/json')

  httpOptions = {
    headers: this.headers,
  };

  constructor(private httpClient: HttpClient, private router: Router) { }

  login(credentials: { username: any; password: any; }) {
    return this.httpClient.post(environment.API_SERVER_URL + 'api/user/signin', credentials, this.httpOptions);
  }

  logout() {
    localStorage.clear();
    this.router.navigate(['/login']);
  }

  // @Description:    Helper Functions
  getUserLoanProducts(data: any) {
    //console.log("data", data)
    return this.httpClient.post(environment.API_SERVER_URL + 'api/user/loan-products', data, this.httpOptions);
  }

  getUserProducts(data: any) {
    //console.log("data", data)
    return this.httpClient.post(environment.API_SERVER_URL + 'api/admin/mappings/product-branch-mapping/get-products', data, this.httpOptions);
  }

}


