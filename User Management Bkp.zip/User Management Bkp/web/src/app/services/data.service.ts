import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root',
})
export class DataService {
  headers = new HttpHeaders()
    .set('Content-Type', 'application/json')
    .set('Accept', 'application/json');
  httpOptions = {
    headers: this.headers,
  };
  constructor(private httpClient: HttpClient) { }

  /*
  *
  * @description: Functions for New Details Screen
  */
  getUserLoanProducts(data: any) {
    return this.httpClient.post('http://localhost:5000/api/user/loan-products', data)
  }


  /*
   *
   * @description: Functions for Login Details Screen
   */
  getLoginData() {
    return this.httpClient
      .get(environment.API_URL + 'loginDetailsData', this.httpOptions);
  }

  getLoginDataWithId(id: any) {
    return this.httpClient
      .get(environment.API_URL + 'loginDetailsData' + id, this.httpOptions);
  }

  postLoginData(data: any) {
    return this.httpClient
      .post(environment.API_URL + 'loginDetailsData', data, this.httpOptions)
      .subscribe((res) => {
        //console.log(res);
      });
  }

  patchLoginData(data: any, id: any) {
    return this.httpClient
      .patch(environment.API_URL + 'loginDetailsData' + "/" + id, data, this.httpOptions)
      .subscribe((res) => {
        //console.log(res);
      });
  }

  /*
   *
   * @description: Functions for KYC Details Screen
   */
  getKYCDetailsData() {
    return this.httpClient
      .get(environment.API_URL + 'kycDetailsData', this.httpOptions);
  }

  postKYCDetailsData(data: any) {
    return this.httpClient
      .post(environment.API_URL + 'kycDetailsData', data, this.httpOptions)
      .subscribe((res) => {
        //console.log(res);
      });
  }
}
