import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class SharedDataService {
  LoginData!: any;
  constructor() { }

  setLoginDataWithID(data: any) {
    this.LoginData = data;
  }

  getLoginDataWithID() {
    return this.LoginData;
  }
}
