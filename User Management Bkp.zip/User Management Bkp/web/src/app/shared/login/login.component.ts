import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthService } from '../../services/auth.service';
import { HttpResponse } from '@angular/common/http';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
})
export class LoginComponent implements OnInit {
  loginForm!: FormGroup;
  loginFormSubmitted: boolean = false;
  loginData!: Object;

  currentUser: any;

  constructor(
    private router: Router,
    private authService: AuthService,
    private route: ActivatedRoute
  ) { }

  ngOnInit(): void {
    this.newloginForm();
  }

  newloginForm() {
    this.loginForm = new FormGroup({
      username: new FormControl(null, [
        Validators.required,
        Validators.minLength(3),
      ]),
      password: new FormControl(null, [
        Validators.required,
        Validators.minLength(6),
      ]),
    });
  }

  get loginFormControl() {
    return this.loginForm.controls;
  }

  loginSubmitHandler() {
    this.loginFormSubmitted = true;
    if (this.loginFormSubmitted && this.loginForm.valid) {
      this.authService
        .login({
          username: this.loginForm.value.username,
          password: this.loginForm.value.password,
        })
        .subscribe((res: any) => {
          if (res.status === 200) {
            localStorage.setItem('currentUser', JSON.stringify(res['data'].userdata));
            localStorage.setItem('accessToken', JSON.stringify(res['data'].accessToken));
            localStorage.setItem('branch', JSON.stringify(res['data'].branch));


            this.currentUser = JSON.parse(localStorage.getItem('currentUser') as string);
            this.currentUser = this.currentUser;

            // This peice of code checks user has access to which application
            if (this.currentUser) {
              const application = new Set()
              this.currentUser.forEach((item: any, i: any) => {
                application.add(item.ApplicationCode)
              })
              let applicationAccess = [...application];
              // console.log(array)
              localStorage.setItem('application', JSON.stringify(applicationAccess));
              if (application.has("MIS")) {
                this.router.navigate(['/user/mis']);
              } else {
                this.router.navigate(['/user/los/new-application']);
              }
            }
          } else {
            localStorage.setItem('message', res.message)
            this.router.navigate(['/error']);
          }
        });
    }
  }
}
